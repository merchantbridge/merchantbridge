-- ============================================================
-- MerchantBridge database setup (Supabase / Postgres)
-- Run this whole file once in Supabase → SQL Editor → New query → Run.
-- It is safe to run again: it replaces functions and policies.
-- ============================================================

-- 1. Tables ---------------------------------------------------

-- Every record the app stores is one JSON document in one collection:
--   merchants/<user id>   a store's profile, applications, saved briefs,
--                         notifications, messages, testimonials, email outbox
--   opportunities/<id>    briefs the team publishes
--   reviews/<id>          reviews shown on the public website
--   notes/<merchant id>   private team notes + upsell pipeline (team only)
--   team/<user id>        team roles: admin | manager | specialist
--   settings/config       matching rules, email templates, digest settings
--   audit/<id>            log of team actions (team only)
--   posts/<id>            Journal articles (public read, team write)
--   contact/<id>          Contact page messages (anyone can send, team reads)
create table if not exists public.documents (
  collection  text        not null,
  id          text        not null,
  data        jsonb       not null default '{}'::jsonb,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  primary key (collection, id)
);
alter table public.documents replica identity full;   -- so realtime sends deletes too
create index if not exists documents_collection_created on public.documents (collection, created_at);

-- One row per signed-in person. Created automatically on first sign-in.
-- access: 'owner' or 'editor' = MerchantBridge team; empty = merchant.
create table if not exists public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  email       text,
  name        text,
  access      text check (access in ('owner', 'editor')),
  created_at  timestamptz not null default now()
);

-- 2. Helper functions ----------------------------------------

-- Is the current user on the MerchantBridge team?
-- True for profiles with access owner/editor, or anyone added as an active
-- teammate from the app's Settings → Team members.
create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and (
    exists (select 1 from public.profiles where id = auth.uid() and access in ('owner', 'editor'))
    or exists (
      select 1 from public.documents
      where collection = 'team' and id = auth.uid()::text
        and coalesce(data->>'active', 'true') <> 'false'
    )
  );
$$;

-- Is the current user an admin (owner with admin role)?
-- Only admins can access the team side of the application.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and (
    exists (select 1 from public.profiles where id = auth.uid() and access = 'owner')
    and (
      not exists (select 1 from public.documents where collection = 'team' and id = auth.uid()::text)
      or exists (
        select 1 from public.documents
        where collection = 'team' and id = auth.uid()::text
          and coalesce(data->>'role', 'admin') = 'admin'
      )
    )
  );
$$;

-- Deep-merge two JSON objects (nested objects merge, everything else replaces).
create or replace function public.jsonb_deep_merge(a jsonb, b jsonb)
returns jsonb language plpgsql immutable as $$
declare
  k text; v jsonb; r jsonb := coalesce(a, '{}'::jsonb);
begin
  if b is null then return r; end if;
  for k, v in select * from jsonb_each(b) loop
    if jsonb_typeof(v) = 'object' and jsonb_typeof(r->k) = 'object' then
      r := jsonb_set(r, array[k], public.jsonb_deep_merge(r->k, v));
    else
      r := r || jsonb_build_object(k, v);
    end if;
  end loop;
  return r;
end $$;

-- Merge a patch into an existing document. Runs with the caller's rights,
-- so row level security still applies.
create or replace function public.doc_update(p_collection text, p_id text, p_patch jsonb)
returns void language plpgsql security invoker set search_path = public as $$
begin
  update public.documents
     set data = public.jsonb_deep_merge(data, p_patch), updated_at = now()
   where collection = p_collection and id = p_id;
  if not found then
    raise exception 'document not found or not allowed' using errcode = 'P0002';
  end if;
end $$;

-- New sign-up → profile row.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Merchants can edit their own profile but can never approve themselves.
-- Review fields are kept as they were unless the team makes the change.
-- The one thing a merchant may do: resubmit (resubmit/rejected → pending).
create or replace function public.protect_merchant_fields()
returns trigger language plpgsql security definer set search_path = public as $$
declare k text;
begin
  if new.collection <> 'merchants' or public.is_staff() then return new; end if;

  if tg_op = 'INSERT' then
    new.data := (new.data - 'demo' - 'feedback' - 'reviewedAt' - 'reviewedBy')
                || jsonb_build_object('status', 'pending', 'pushed', '{}'::jsonb);
    return new;
  end if;

  if not (coalesce(old.data->>'status', '') in ('resubmit', 'rejected') and new.data->>'status' = 'pending') then
    new.data := jsonb_set(new.data, '{status}', coalesce(old.data->'status', '"pending"'::jsonb));
    new.data := jsonb_set(new.data, '{feedback}', coalesce(old.data->'feedback', '""'::jsonb));
  end if;
  foreach k in array array['reviewedAt', 'reviewedBy', 'pushed', 'demo'] loop
    if old.data ? k then new.data := jsonb_set(new.data, array[k], old.data->k);
    else new.data := new.data - k; end if;
  end loop;
  return new;
end $$;
drop trigger if exists protect_merchant_fields on public.documents;
create trigger protect_merchant_fields before insert or update on public.documents
  for each row execute function public.protect_merchant_fields();

-- 3. Row level security --------------------------------------

alter table public.documents enable row level security;
alter table public.profiles  enable row level security;

drop policy if exists docs_read   on public.documents;
drop policy if exists docs_insert on public.documents;
drop policy if exists docs_update on public.documents;
drop policy if exists docs_delete on public.documents;

-- Read: merchants see only their own record; notes, audit and team are
-- admin-only; opportunities, reviews and settings are public (the website
-- shows live briefs and reviews to visitors who aren't signed in).
create policy docs_read on public.documents for select using (
  case collection
    when 'merchants' then public.is_staff() or id = auth.uid()::text
    when 'notes'     then public.is_admin()
    when 'audit'     then public.is_admin()
    when 'team'      then public.is_admin()
    when 'contact'   then public.is_admin()
    else true
  end
);
-- Write: a merchant writes only their own record; anyone (even signed out) can
-- send a contact message up to 20 KB; everything else is admin-only.
create policy docs_insert on public.documents for insert with check (
  case collection
    when 'merchants' then public.is_staff() or id = auth.uid()::text
    when 'contact'   then public.is_admin() or (octet_length(data::text) < 20000 and coalesce(data->>'status', 'new') = 'new')
    else public.is_admin()
  end
);
create policy docs_update on public.documents for update
  using (
    case collection
      when 'merchants' then public.is_staff() or id = auth.uid()::text
      else public.is_admin()
    end
  )
  with check (
    case collection
      when 'merchants' then public.is_staff() or id = auth.uid()::text
      else public.is_admin()
    end
  );
create policy docs_delete on public.documents for delete using (public.is_admin());

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select using (id = auth.uid() or public.is_staff());
-- No insert/update policies on profiles: rows come from the sign-up trigger,
-- and team access is granted in SQL (see README) or from Settings → Team members.

-- 4. Realtime (live updates) ---------------------------------
do $$ begin
  alter publication supabase_realtime add table public.documents;
exception when duplicate_object then null; end $$;

-- 5. File uploads (supplier profile documents) ---------------
insert into storage.buckets (id, name, public)
values ('uploads', 'uploads', true)
on conflict (id) do nothing;

drop policy if exists "uploads: signed-in users add to own folder" on storage.objects;
create policy "uploads: signed-in users add to own folder" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'uploads' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "uploads: team can delete" on storage.objects;
create policy "uploads: admins can delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'uploads' and public.is_admin());

-- ============================================================
-- AFTER RUNNING: make yourself the owner (use the email you sign in with)
--   update public.profiles set access = 'owner' where email = 'you@example.com';
-- ============================================================
