// MerchantBridge configuration
// ------------------------------------------------------------
// Paste your Supabase project URL and anon (public) key below.
// Find them in Supabase: Project Settings → API.
//
// Leave them empty to run in DEMO MODE: everything works, but data is
// saved only in the current browser and you are signed in as a demo admin.

window.MB_CONFIG = {
  SUPABASE_URL: "",       // e.g. "https://abcdefghijk.supabase.co"
  SUPABASE_ANON_KEY: "",  // the long "anon public" key (safe to expose in the browser)
  STORAGE_BUCKET: "uploads"
};
