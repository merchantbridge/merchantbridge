/*
 * MerchantBridge backend layer
 * ------------------------------------------------------------
 * The app (app.js) talks to a small document-store API through
 * `claude.use("db" | "user" | "assets" | "downloads")`. This file provides
 * that API on top of Supabase:
 *
 *   db        → table public.documents (collection, id, data jsonb) + realtime
 *   user      → Supabase Auth (email magic link) + public.profiles
 *   assets    → Supabase Storage bucket (default "uploads")
 *   downloads → browser file download
 *
 * With no keys in config.js it runs in DEMO MODE (browser-only storage,
 * signed in as a demo admin) so the site can be tried before setup.
 *
 * Access rules live in the database (supabase/schema.sql, row level
 * security). This file never decides who may read or write what.
 */
(function () {
  "use strict";
  const cfg = window.MB_CONFIG || {};
  const DEMO = !cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY || !window.supabase;
  const BUCKET = cfg.STORAGE_BUCKET || "uploads";

  /* ---------- helpers ---------- */
  const isObj = v => v && typeof v === "object" && !Array.isArray(v);
  const clone = v => (v == null ? v : JSON.parse(JSON.stringify(v)));
  function deepMerge(a, b) {
    const out = { ...(isObj(a) ? a : {}) };
    for (const k of Object.keys(b || {})) out[k] = isObj(b[k]) && isObj(out[k]) ? deepMerge(out[k], b[k]) : clone(b[k]);
    return out;
  }
  const genId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  function splitPath(path) {
    const parts = String(path).split("/");
    if (parts.length % 2) throw new TypeError("Document path needs an even number of segments: " + path);
    const id = parts.pop();
    return [parts.join("/"), id];
  }
  function dbError(e) {
    const msg = (e && (e.message || e.error_description)) || String(e);
    const code = e && e.code;
    const out = new Error(msg);
    out.code = code === "42501" || code === "P0002" || /row-level security|permission|not found/i.test(msg) ? "invalid_argument" : "unavailable";
    return out;
  }
  const docSnap = (id, data) => ({ id, exists: data != null, data: () => (data == null ? undefined : data), metadata: { fromCache: false, hasPendingWrites: false } });
  const querySnap = rows => {
    const docs = rows.map(r => docSnap(r.id, r.data));
    return { docs, size: docs.length, empty: !docs.length, docChanges: () => [], metadata: { fromCache: false, hasPendingWrites: false } };
  };

  /* ---------- stores ---------- */
  let sb = null;
  let store;

  if (DEMO) {
    const KEY = "mb_demo_db_v1";
    let mem = {};
    try { mem = JSON.parse(localStorage.getItem(KEY) || "{}"); } catch (e) { mem = {}; }
    const save = () => { try { localStorage.setItem(KEY, JSON.stringify(mem)); } catch (e) {} };
    store = {
      async get(c, id) { return clone(mem[c]?.[id]?.data ?? null); },
      async list(c) { return Object.entries(mem[c] || {}).map(([id, r]) => ({ id, data: clone(r.data), created_at: r.created_at })); },
      async put(c, id, data) { mem[c] = mem[c] || {}; mem[c][id] = { data: clone(data), created_at: mem[c][id]?.created_at || new Date().toISOString() }; save(); },
      async merge(c, id, patch) { const r = mem[c]?.[id]; if (!r) { const e = new Error("document not found"); e.code = "P0002"; throw dbError(e); } r.data = deepMerge(r.data, patch); save(); },
      async del(c, id) { if (mem[c]) delete mem[c][id]; save(); },
      async insert(c, id, data) { return this.put(c, id, data); }
    };
    window.addEventListener("storage", e => { if (e.key === KEY) { try { mem = JSON.parse(e.newValue || "{}"); } catch (x) {} notifyAll(); } });
  } else {
    sb = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
    const T = "documents";
    store = {
      async get(c, id) {
        const { data, error } = await sb.from(T).select("data").eq("collection", c).eq("id", id).maybeSingle();
        if (error) throw dbError(error);
        return data ? data.data : null;
      },
      async list(c) {
        const out = [];
        for (let from = 0; ; from += 1000) {
          const { data, error } = await sb.from(T).select("id,data,created_at").eq("collection", c).order("created_at", { ascending: true }).range(from, from + 999);
          if (error) throw dbError(error);
          out.push(...data);
          if (data.length < 1000) break;
        }
        return out;
      },
      async put(c, id, data) {
        const { error } = await sb.from(T).upsert({ collection: c, id, data, updated_at: new Date().toISOString() }, { onConflict: "collection,id" });
        if (error) throw dbError(error);
      },
      async merge(c, id, patch) {
        const { error } = await sb.rpc("doc_update", { p_collection: c, p_id: id, p_patch: patch });
        if (error) throw dbError(error);
      },
      async del(c, id) {
        const { error } = await sb.from(T).delete().eq("collection", c).eq("id", id);
        if (error) throw dbError(error);
      },
      // Plain insert (no upsert): used for new records such as contact messages,
      // which visitors may create but never read or change.
      async insert(c, id, data) {
        const { error } = await sb.from(T).insert({ collection: c, id, data });
        if (error) throw dbError(error);
      }
    };
  }

  /* ---------- live listeners ---------- */
  const listeners = new Set();
  function addListener(l) { listeners.add(l); l.run(); return () => { listeners.delete(l); clearTimeout(l.t); }; }
  function notify(c, id) {
    for (const l of listeners) {
      if (l.c !== c || (l.id != null && l.id !== id)) continue;
      clearTimeout(l.t);
      l.t = setTimeout(l.run, 120);
    }
  }
  function notifyAll() { for (const l of listeners) { clearTimeout(l.t); l.t = setTimeout(l.run, 120); } }
  if (sb) {
    sb.channel("mb-documents")
      .on("postgres_changes", { event: "*", schema: "public", table: "documents" }, p => {
        const r = p.new && p.new.collection ? p.new : p.old || {};
        if (r.collection) notify(r.collection, r.id); else notifyAll();
      })
      .subscribe();
    // Safety net: refresh every 60s in case a realtime event is missed.
    setInterval(() => { if (document.visibilityState === "visible") notifyAll(); }, 60000);
  }

  /* ---------- db namespace ---------- */
  function docRef(c, id) {
    return {
      id, path: c + "/" + id,
      async get() { return docSnap(id, await store.get(c, id)); },
      async set(data) { await store.put(c, id, data); notify(c, id); },
      async update(data) { await store.merge(c, id, data); notify(c, id); },
      async delete() { await store.del(c, id); notify(c, id); },
      onSnapshot(next, err) {
        const l = { c, id, run: async () => { try { next(docSnap(id, await store.get(c, id))); } catch (e) { err && err(e); } } };
        return addListener(l);
      },
      collection(sub) { return query(c + "/" + id + "/" + sub, {}); }
    };
  }
  function shape(rows, o) {
    let r = rows.slice();
    if (o.f) {
      const dir = o.d === "desc" ? -1 : 1;
      r.sort((a, b) => { const A = a.data?.[o.f], B = b.data?.[o.f]; return A === B ? 0 : A == null ? 1 : B == null ? -1 : A > B ? dir : -dir; });
    }
    if (o.n) r = r.slice(0, o.n);
    return r;
  }
  function query(c, o) {
    return {
      path: c,
      where() { return query(c, o); },
      orderBy(f, d) { return query(c, { ...o, f, d: d || "asc" }); },
      limit(n) { return query(c, { ...o, n }); },
      doc(id) { return docRef(c, id || genId()); },
      async add(data) { const id = genId(); await store.insert(c, id, data); notify(c, id); return docRef(c, id); },
      async get() { return querySnap(shape(await store.list(c), o)); },
      onSnapshot(next, err) {
        const l = { c, id: null, run: async () => { try { next(querySnap(shape(await store.list(c), o))); } catch (e) { err && err(e); } } };
        return addListener(l);
      }
    };
  }
  const db = {
    doc(path) { const [c, id] = splitPath(path); return docRef(c, id); },
    collection(path) { return query(path, {}); }
  };

  /* ---------- auth + user namespace ---------- */
  let uid = null, email = null, profile = null, staff = false;
  async function loadUser() {
    if (DEMO) {
      uid = "demo-admin"; email = "demo@merchantbridge.local";
      profile = { id: uid, name: "Demo Admin", access: "owner" }; staff = true;
      return;
    }
    const { data } = await sb.auth.getSession();
    const s = data && data.session;
    if (!s) return;
    uid = s.user.id; email = s.user.email;
    const p = await sb.from("profiles").select("id,name,email,access").eq("id", uid).maybeSingle();
    profile = p.data || { id: uid, name: (email || "").split("@")[0], access: null };
    const st = await sb.rpc("is_staff");
    staff = !!st.data;
  }
  const user = {
    async id() { return uid; },
    async isOwner() { return profile?.access === "owner"; },
    async canEdit() { return staff; },
    async isAdmin() {
      if (!staff) return false;
      if (profile?.access !== "owner") return false;
      // Demo mode does NOT grant admin access - restrict team side even in demo
      if (DEMO) return false;
      const { data } = await sb.from("documents").select("data").eq("collection", "team").eq("id", uid).maybeSingle();
      const teamData = data?.data;
      return !teamData || teamData.role === "admin";
    },
    async can() { return uid ? true : false; },
    async name() { return profile?.name || ""; },
    async email() { return email; },
    async avatarUrl() { return null; },
    async me() { return { id: uid, name: profile?.name || "", email, guest: false }; },
    async profiles(ids) {
      const out = {};
      (ids || []).forEach(id => { out[id] = { id, name: "" }; });
      if (DEMO) { if (out[uid]) out[uid].name = profile.name; return out; }
      const list = (ids || []).filter(id => /^[0-9a-f-]{36}$/i.test(id));
      if (!list.length) return out;
      const { data } = await sb.from("profiles").select("id,name,email").in("id", list);
      (data || []).forEach(p => { out[p.id] = { id: p.id, name: p.name || p.email || "" }; });
      return out;
    },
    async search(q) {
      if (DEMO) return [];
      let qb = sb.from("profiles").select("id,name,email").limit(10);
      if (q) qb = qb.or(`name.ilike.%${q.replace(/[%,()]/g, "")}%,email.ilike.%${q.replace(/[%,()]/g, "")}%`);
      const { data } = await qb;
      return (data || []).map(p => ({ id: p.id, name: p.name || p.email, email: p.email }));
    }
  };

  /* ---------- assets (file uploads) ---------- */
  const assets = {
    async upload(blob) {
      if (DEMO) {
        const url = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; fr.readAsDataURL(blob); });
        return { id: genId(), url, sizeBytes: blob.size, contentType: blob.type };
      }
      const safe = (blob.name || "file").replace(/[^\w.\-]+/g, "_").slice(-80);
      const path = `${uid}/${Date.now()}-${safe}`;
      const { error } = await sb.storage.from(BUCKET).upload(path, blob, { contentType: blob.type || undefined, upsert: false });
      if (error) throw dbError(error);
      const { data } = sb.storage.from(BUCKET).getPublicUrl(path);
      return { id: path, url: data.publicUrl, sizeBytes: blob.size, contentType: blob.type };
    },
    async list() { return { assets: [], usage: {} }; },
    async delete(id) { if (!DEMO) await sb.storage.from(BUCKET).remove([id]); }
  };

  /* ---------- downloads ---------- */
  const downloads = {
    async save({ filename, data }) {
      const blob = data instanceof Blob ? data : new Blob([data], { type: "text/plain;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob); a.download = filename || "download";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      return { saved: true };
    }
  };

  /* ---------- sign in / sign out (used by app.js) ---------- */
  const INTENT = "mb_intent";
  const auth = {
    demo: DEMO,
    intent() { try { return localStorage.getItem(INTENT); } catch (e) { return null; } },
    clearIntent() { try { localStorage.removeItem(INTENT); } catch (e) {} },
    prompt(intent) {
      if (DEMO) { window.toast && toast("Demo mode: you're signed in as Demo Admin"); return; }
      try { localStorage.setItem(INTENT, intent || "signin"); } catch (e) {}
      const apply = intent === "apply";
      openModal(`<div class="modal-head"><div><span class="eyebrow">${apply ? "Join MerchantBridge" : "Sign in"}</span><h2>${apply ? "Start with your email" : "Welcome back"}</h2></div>${closeBtn()}</div>
        <p class="muted">${apply ? "We'll email you a secure link. Open it and your application starts right away. No password needed." : "Enter your email and we'll send you a secure sign-in link. No password needed."}</p>
        <form id="mb-auth" class="stack" onsubmit="event.preventDefault();MB.auth.send()">
          <div class="field"><label for="mb-email">Email</label><input id="mb-email" type="email" required autocomplete="email" placeholder="you@yourbrand.com"></div>
          <p class="err" id="mb-auth-err" hidden></p>
          <div class="row between"><button type="button" class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" id="mb-auth-btn" type="submit">Email me a link</button></div>
        </form>`);
    },
    async send() {
      const el = document.getElementById("mb-email"), btn = document.getElementById("mb-auth-btn"), err = document.getElementById("mb-auth-err");
      const addr = (el.value || "").trim();
      if (!addr) return;
      btn.disabled = true; btn.textContent = "Sending…"; err.hidden = true;
      const { error } = await sb.auth.signInWithOtp({ email: addr, options: { emailRedirectTo: location.origin + location.pathname } });
      if (error) { err.textContent = "We couldn't send the link: " + error.message; err.hidden = false; btn.disabled = false; btn.textContent = "Email me a link"; return; }
      document.getElementById("mb-auth").outerHTML = `<div class="notice accent"><b>Check your inbox.</b> We sent a sign-in link to ${addr.replace(/</g, "&lt;")}. Open it on this device to continue.</div><div class="row" style="justify-content:flex-end"><button class="btn" onclick="closeModal()">Close</button></div>`;
    },
    async signOut() {
      if (DEMO) { window.toast && toast("Demo mode has no sign out. Clear demo data in Settings."); return; }
      await sb.auth.signOut();
      location.reload();
    }
  };

  /* ---------- boot ---------- */
  const ready = loadUser().catch(e => { console.error("MerchantBridge: could not load the signed-in user", e); });
  if (sb) {
    sb.auth.onAuthStateChange((event, session) => {
      const next = session ? session.user.id : null;
      ready.then(() => { if (next !== uid && (event === "SIGNED_IN" || event === "SIGNED_OUT")) location.reload(); });
    });
  }
  window.MB = { auth, demo: DEMO, supabase: sb };
  window.claude = {
    async use(name) {
      await ready;
      if (name === "db") return db;
      if (name === "user") return user;
      if (name === "assets") return uid ? assets : null;
      if (name === "downloads") return downloads;
      return null;
    }
  };

  if (DEMO) {
    document.addEventListener("DOMContentLoaded", () => {
      const b = document.createElement("div");
      b.setAttribute("role", "note");
      b.style.cssText = "position:fixed;left:max(12px,env(safe-area-inset-left,0px));bottom:calc(env(safe-area-inset-bottom,0px) + 12px);z-index:40;background:#0F172A;color:#fff;font:600 12px/1.3 Figtree,Arial,sans-serif;padding:8px 12px;border-radius:999px;opacity:.9;pointer-events:none";
      b.textContent = "Demo mode · data saved in this browser only · add Supabase keys in config.js";
      document.body.appendChild(b);
    });
  }
})();
