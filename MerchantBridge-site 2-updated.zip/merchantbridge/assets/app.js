/* ============ constants ============ */
const CATEGORIES=["Skincare","Apparel","Jewelry","Candles","Home goods","Food and beverage","Pet products","Other"];
const TYPES=["Corporate Gifting","Bulk Buyers","Wholesale","Retail Listing","Corporate Procurement","Distributors","Employee Rewards","Hospitality","Events","Brand Partnership","UGC Campaign","Product Sourcing"];
const MARKETS=["US","UK","Europe","Australia","Canada","Worldwide"];
const REVENUE=["Under $1k","$1k–$5k","$5k–$10k","$10k–$50k","$50k+"];
const VOLUME=["Under 50 orders","50–200 orders","200–1,000 orders","1,000+ orders"];
const CHANNELS=["Own website","Shopify","Etsy","Amazon","Wholesale","Retail","Other"];
const PLATFORMS=[["Shopify","Connect your Shopify store"],["WooCommerce","Add details by hand"],["BigCommerce","Add details by hand"],["Magento","Add details by hand"],["Wix","Add details by hand"],["Etsy / other site","Add details by hand"]];
const APP_STATUS=["Applied","In conversation","Deal closed","Not successful"];
const SPEC_STAGES=["Not contacted","In conversation","Service agreed","Completed"];
const SERVICES=["Supplier profile","Website / product pages","Branding","Content & photography","Ads","AI video","Social media"];
const SOURCES=["LinkedIn","Industry publication","Platform outreach","Direct brand contact","RangeMe","Supplier portal","Marketplace","Other"];
const ROLES={admin:"Admin",manager:"Manager",specialist:"Specialist"};
const ROLE_PAGES={admin:["overview","queue","merchants","opps","sourcing","upsell","library","journal","inbox","outbox","settings"],manager:["overview","queue","merchants","opps","sourcing","upsell","library","journal","inbox","outbox"],specialist:["upsell","merchants","library"]};
const DEFAULT_TEMPLATES={
 approved:{label:"Profile approved",trigger:"Team approves a profile",subject:"You're in, {{name}} — welcome to MerchantBridge",body:"Hi {{name}},\n\nGood news: {{store}} is approved. Your opportunity feed is now live and matched to what you sell, where you ship and what you can customise.\n\nNext steps:\n1. Log in and look at your first matches.\n2. Fill in any gaps in your profile — complete profiles get more matches.\n3. When you apply somewhere, tap \"I applied\" so you can track it.\n\nWe're glad you're here.\nThe MerchantBridge team"},
 resubmit:{label:"Resubmission requested",trigger:"Team requests changes",subject:"A few tweaks and you're in, {{name}}",body:"Hi {{name}},\n\nThanks for applying with {{store}}. We'd love to get you matched, and a couple of changes will make your profile much stronger:\n\n{{feedback}}\n\nUpdate your profile and resubmit whenever you're ready — we'll take a second look within 48 hours.\n\nThe MerchantBridge team"},
 rejected:{label:"Profile not approved",trigger:"Team rejects a profile",subject:"About your MerchantBridge application",body:"Hi {{name}},\n\nThank you for applying with {{store}}. We aren't able to approve the profile right now, and we want to be clear about why:\n\n{{feedback}}\n\nThings change fast in e-commerce. You're welcome to apply again once that's different.\n\nThe MerchantBridge team"},
 digest:{label:"Weekly digest",trigger:"Every week on the digest day",subject:"{{count}} new opportunities for {{store}} this week",body:"Hi {{name}},\n\nHere's what matched your profile this week:\n\n{{list}}\n\nOpen your feed to see the full details and apply directly with each source.\n\nThe MerchantBridge team"},
 dealClosed:{label:"Deal closed",trigger:"Merchant marks a deal as closed",subject:"Congratulations, {{name}}!",body:"Hi {{name}},\n\nYou closed a deal on \"{{opportunity}}\". That's a real milestone for {{store}} and we're proud to have played a small part.\n\nIf you'd like help fulfilling, presenting or growing from here, just reply.\n\nThe MerchantBridge team"},
 expansion:{label:"Case study request",trigger:"Team requests a fuller story",subject:"Could we tell your story, {{name}}?",body:"Hi {{name}},\n\nYour note about MerchantBridge meant a lot to us. Would you be open to sharing a bit more — where {{store}} was before, what you found here and what changed? It helps other independent brands see what's possible.\n\nA few lines is plenty. Thank you!\nThe MerchantBridge team"},
 boost:{label:"Time-sensitive opportunity",trigger:"Team boosts an opportunity",subject:"Act fast: {{opportunity}}",body:"Hi {{name}},\n\nA time-sensitive opportunity just matched {{store}}: \"{{opportunity}}\". These tend to fill quickly, so take a look today.\n\nThe MerchantBridge team"}
};
const DEFAULT_SETTINGS={rules:{approvedOnly:true,category:true,market:true,custom:true,capacity:true},digestDay:"Monday",digestTime:"09:00",weeklyTarget:50,leaderboard:true,templates:{},notify:{newMatch:true,statusEmail:true,boostEmail:true}};
const PROFILE_FIELDS=[["fullName","Full name"],["businessName","Business name"],["storeUrl","Store URL"],["category","Product category"],["description","Business description"],["targetMarket","Target market"],["aov","Average order value"],["orderVolume","Monthly order volume"],["customBranding","Custom branding answer"],["markets","Shipping markets"],["revenue","Monthly revenue range"],["channels","Sales channels"],["supplierDoc","Supplier profile document"]];

/* ============ icons ============ */
const I={
 bell:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>',
 ext:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17 17 7M8 7h9v9"/></svg>',
 bookmark:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>',
 check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
 user:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>',
 bolt:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 3 14h9l-1 8 10-12h-9z"/></svg>',
 msg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
 clock:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
 star:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="m12 2 3 7 7 .6-5.3 4.7 1.6 7.2L12 17.8 5.7 21.5l1.6-7.2L2 9.6 9 9z"/></svg>',
 plus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
 x:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>',
 doc:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/></svg>',
 flag:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 22V4s1-1 4-1 5 2 8 2 4-1 4-1v11s-1 1-4 1-5-2-8-2-4 1-4 1"/></svg>',
 phone:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>',
 pin:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg>',
 mail:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>'
};

/* ============ state ============ */
const S={ready:false,db:null,user:null,assets:null,downloads:null,uid:null,meName:"",isOwner:false,canEdit:false,isAdmin:false,
  mode:"merchant",view:"dashboard",teamView:"overview",previewId:null,
  me:null,meLoaded:false,reviews:{},posts:{},contact:{},page:null,postsLoaded:false,merchants:{},opps:{},notes:{},team:{},audit:[],settings:null,profiles:{},
  draft:{},wizard:1,ui:{feedTab:"feed",oppFilter:"live",mSearch:"",mStatus:"",mSort:"createdAt",mDir:"desc",selected:{},libTab:"pending",bell:false,detail:null,detailTab:"profile"}};

/* ============ helpers ============ */
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const gid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const nowIso=()=>new Date().toISOString();
const ts=v=>v?new Date(v).getTime():0;
const DAY=864e5;
function fmtDate(v){if(!v)return"—";const d=new Date(v);return d.toLocaleDateString(undefined,{day:"numeric",month:"short",year:d.getFullYear()!==new Date().getFullYear()?"numeric":undefined})}
function ago(v){if(!v)return"—";const s=(Date.now()-ts(v))/1e3;if(s<60)return"just now";if(s<3600)return Math.floor(s/60)+"m ago";if(s<86400)return Math.floor(s/3600)+"h ago";const d=Math.floor(s/86400);return d<30?d+"d ago":fmtDate(v)}
function waitText(v){const h=(Date.now()-ts(v))/36e5;if(h<1)return"under 1h";if(h<48)return Math.floor(h)+"h";return Math.floor(h/24)+"d"}
function weekStart(d=new Date()){const x=new Date(d);x.setHours(0,0,0,0);const day=(x.getDay()+6)%7;x.setDate(x.getDate()-day);return x}
function monthStart(){const x=new Date();x.setHours(0,0,0,0);x.setDate(1);return x}
function todayStr(){const d=new Date();return d.toISOString().slice(0,10)}
function plusDays(n){const d=new Date(Date.now()+n*DAY);return d.toISOString().slice(0,10)}
function toast(t){const el=document.getElementById("toast");el.innerHTML='<div class="toast" role="status">'+esc(t)+'</div>';clearTimeout(toast._t);toast._t=setTimeout(()=>el.innerHTML="",2600)}
function fill(tpl,vars){return String(tpl||"").replace(/\{\{(\w+)\}\}/g,(_,k)=>vars[k]??"")}
function settings(){const s=S.settings||{};return{...DEFAULT_SETTINGS,...s,rules:{...DEFAULT_SETTINGS.rules,...(s.rules||{})},notify:{...DEFAULT_SETTINGS.notify,...(s.notify||{})},templates:Object.fromEntries(Object.keys(DEFAULT_TEMPLATES).map(k=>[k,{...DEFAULT_TEMPLATES[k],...((s.templates||{})[k]||{})}]))}}
function firstName(m){return (m?.fullName||"").trim().split(/\s+/)[0]||"there"}
function shortName(m){const p=(m?.fullName||"").trim().split(/\s+/);return p.length>1?p[0]+" "+p[p.length-1][0]+".":(p[0]||"Merchant")}
function nameOf(id){if(!id)return"Someone";if(id===S.uid)return S.meName||"You";return S.profiles[id]?.name||"Teammate"}
function myRole(){if(!S.canEdit)return null;if(S.isOwner)return"admin";return S.team[S.uid]?.role||"manager"}
const vals=o=>Object.entries(o||{}).map(([id,v])=>({id,...v}));

/* ============ data writes (one at a time per document) ============ */
const chains={};
function queue(path,fn){const p=(chains[path]||Promise.resolve()).catch(()=>{}).then(fn);chains[path]=p;return p.catch(e=>{console.error(e);toast(e?.code==="quota_exceeded"?"Storage is full — remove old records to continue.":e?.code==="invalid_argument"?"You don't have permission to change that.":"Couldn't save — check your connection and try again.");throw e})}
const setDoc=(path,data)=>queue(path,()=>S.db.doc(path).set(data));
const updDoc=(path,data)=>queue(path,()=>S.db.doc(path).update(data));
const delDoc=(path)=>queue(path,()=>S.db.doc(path).delete());
async function upsert(path,data){const snap=await S.db.doc(path).get();return snap.exists?updDoc(path,data):setDoc(path,data)}
function audit(text){if(!S.canEdit)return;const id=gid();setDoc("audit/"+id,{text,by:S.uid,at:nowIso()}).catch(()=>{})}
function notifyMerchant(mid,text,kind="info"){const id=gid();return updDoc("merchants/"+mid,{notifications:{[id]:{text,kind,at:nowIso(),read:false}}})}
function queueEmail(mid,key,extra={}){const m=S.merchants[mid]||(S.me?.id===mid?S.me:null);const t=settings().templates[key];const vars={name:firstName(m),store:m?.businessName||"your store",...extra};const id=gid();return updDoc("merchants/"+mid,{emails:{[id]:{template:key,to:m?.email||"",subject:fill(t.subject,vars),body:fill(t.body,vars),at:nowIso(),sent:false}}})}

/* ============ matching ============ */
function oppEnd(o){const cap=Math.max(ts(o.createdAt),ts(o.restoredAt))+30*DAY;return o.expiry?Math.min(new Date(o.expiry+"T23:59:59").getTime(),cap):cap}
function oppState(o){if(!o||o.status==="archived")return"archived";const end=oppEnd(o);if(Date.now()>end)return"archived";if(end-Date.now()<48*36e5)return"expiring";return"live"}
function matches(m,o,ignoreState){const r=settings().rules;if(!m||!o)return false;if(!ignoreState&&oppState(o)==="archived")return false;if(r.approvedOnly&&m.status!=="approved")return false;if(m.pushed?.[o.id])return true;
 if(r.category&&(o.categories||[]).length&&!(o.categories||[]).includes(m.category))return false;
 if(r.market&&(o.markets||[]).length){const mk=m.markets||[];if(!mk.includes("Worldwide")&&!(o.markets||[]).some(x=>mk.includes(x)||x==="Worldwide"))return false}
 if(r.custom&&o.requiresCustom&&m.customBranding!==true)return false;
 if(r.capacity&&o.minVolume&&VOLUME.indexOf(m.orderVolume)<VOLUME.indexOf(o.minVolume))return false;
 return true}
function sortOpps(list){return list.sort((a,b)=>(b.priority==="featured")-(a.priority==="featured")||ts(b.createdAt)-ts(a.createdAt))}
function feedFor(m){return sortOpps(vals(S.opps).filter(o=>matches(m,o)))}
function completion(m){const done=PROFILE_FIELDS.filter(([k])=>{const v=m?.[k];if(k==="supplierDoc")return v&&v.status&&v.status!=="none";if(k==="customBranding")return v===true||v===false;return Array.isArray(v)?v.length>0:!!String(v??"").trim()});return{pct:Math.round(done.length/PROFILE_FIELDS.length*100),missing:PROFILE_FIELDS.filter(f=>!done.includes(f))}}

/* ============ boot ============ */
async function boot(){
  try{
    const [db,user]=await Promise.all([claude.use("db"),claude.use("user")]);
    S.db=db;S.user=user;
    if(!db){S.canWrite=false;S.mode="site";S.postsLoaded=true;routeFromHash();S.ready=true;S.meLoaded=true;render();return}
    if(user){S.uid=await user.id();S.isOwner=await user.isOwner();S.canEdit=await user.canEdit();S.isAdmin=await user.isAdmin();S.meName=await user.name()}
    S.canWrite=!!S.uid&&(user?await user.can("data.write"):null)!==false;
    if(!S.canWrite&&!S.canEdit)S.mode="site";
    claude.use("assets").then(a=>{S.assets=a;render()});
    claude.use("downloads").then(d=>{S.downloads=d});
    if(S.isAdmin){S.mode="team"}
    subscribe();
  }catch(e){console.error(e);document.getElementById("app").innerHTML='<div class="loading"><div><h2>Something went wrong</h2><p class="muted">Reload the page to try again.</p></div></div>'}
}
function subscribe(){
  const db=S.db;
  db.collection("opportunities").onSnapshot(s=>{S.opps=Object.fromEntries(s.docs.map(d=>[d.id,{id:d.id,...d.data()}]));render()},err);
  db.collection("posts").onSnapshot(s=>{S.posts=Object.fromEntries(s.docs.map(d=>[d.id,{id:d.id,...d.data()}]));S.postsLoaded=true;render()},err);
  db.collection("reviews").onSnapshot(s=>{S.reviews=Object.fromEntries(s.docs.map(d=>[d.id,d.data()]));render()},err);
  db.doc("settings/config").onSnapshot(s=>{S.settings=s.exists?s.data():null;render()},err);
  if(S.uid){db.doc("merchants/"+S.uid).onSnapshot(s=>{S.me=s.exists?{id:s.id,...s.data()}:null;const first=!S.meLoaded;S.meLoaded=true;if(first&&window.MB?.auth){const it=MB.auth.intent();MB.auth.clearIntent();if(it==="apply"&&!S.me&&!S.isAdmin){S.mode="merchant";S.draft={started:true,platform:"",markets:[],channels:[]};S.wizard=1}else if(it==="signin"&&S.me){S.mode="merchant";S.view="dashboard"}}if(first&&S.me&&!S.isAdmin&&Date.now()-ts(S.me.lastSeen)>36e5)updDoc("merchants/"+S.uid,{lastSeen:nowIso()}).catch(()=>{});render()},err)}else S.meLoaded=true;
  if(S.isAdmin){
    db.collection("merchants").onSnapshot(s=>{S.merchants=Object.fromEntries(s.docs.map(d=>[d.id,{id:d.id,...d.data()}]));render()},err);
    db.collection("contact").onSnapshot(s=>{S.contact=Object.fromEntries(s.docs.map(d=>[d.id,d.data()]));render()},err);
    db.collection("notes").onSnapshot(s=>{S.notes=Object.fromEntries(s.docs.map(d=>[d.id,d.data()]));render()},err);
    db.collection("team").onSnapshot(s=>{S.team=Object.fromEntries(s.docs.map(d=>[d.id,d.data()]));loadProfiles(Object.keys(S.team));render()},err);
    db.collection("audit").orderBy("at","desc").limit(150).onSnapshot(s=>{S.audit=s.docs.map(d=>({id:d.id,...d.data()}));loadProfiles(S.audit.map(a=>a.by));render()},err);
  }
  routeFromHash();
  S.ready=true;render();
}
function err(e){console.error(e);if(e?.code!=="revoked")toast("Live updates paused — reload to reconnect.")}
async function loadProfiles(ids){if(!S.user)return;const need=[...new Set(ids.filter(id=>id&&!(id in S.profiles)))];if(!need.length)return;need.forEach(id=>S.profiles[id]={name:""});try{const p=await S.user.profiles(need);Object.assign(S.profiles,p||{});render()}catch(e){}}

/* ============ render core ============ */
let pendingRender=false;
function isTyping(){const a=document.activeElement;return a&&document.getElementById("app").contains(a)&&/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)&&a.type!=="checkbox"&&a.type!=="radio"}
document.addEventListener("focusout",()=>setTimeout(()=>{if(pendingRender&&!isTyping()){pendingRender=false;render()}},0));
function render(force){
  if(!S.ready||!S.meLoaded)return;
  renderTop();
  if(!force&&isTyping()){pendingRender=true;return}
  const app=document.getElementById("app");const y=window.scrollY;
  document.title=pageTitle();
  app.innerHTML=showSite()?(S.page?subPage():sitePage()):S.mode==="team"&&S.isAdmin?teamShell():merchantShell();
  if(force!=="keepScroll")window.scrollTo(0,y);
}
function go(mode,view){if(mode)clearPage();if(mode&&mode!==S.mode)S.justSubmitted=false;if(mode)S.mode=mode;if(view){if(S.mode==="team")S.teamView=view;else S.view=view}S.ui.bell=false;render(true);window.scrollTo(0,0)}
function renderTop(){
  const t=document.getElementById("topbar");
  const m=activeMerchant();
  const unread=m?vals(m.notifications).filter(n=>!n.read).length+derivedAlerts(m).length:0;
  let right="";let mid="";
  const site=showSite();
  if(site)mid+=`<div class="toplinks">${[["types","Opportunities"],["how","How it works"],["help","How we help"],["reviews","Reviews"],["faq","FAQ"]].map(([id,l])=>`<button onclick="jump('${id}')">${l}</button>`).join("")}</div>`;
  if(S.isAdmin){right+=`<div class="seg" role="group" aria-label="Switch view"><button aria-pressed="${S.mode==="site"}" onclick="go('site')">Website</button><button aria-pressed="${S.mode==="merchant"}" onclick="go('merchant')">Merchant</button><button aria-pressed="${S.mode==="team"}" onclick="go('team')">Team</button></div>`}
  if(site)right+=`${S.me||!S.isAdmin?`<button class="signin" onclick="signIn()">${S.me?"My dashboard":"Sign in"}</button>`:""}<button class="btn primary join" onclick="startApply()">Join MerchantBridge</button>`;
  if(S.uid&&window.MB?.auth&&!MB.demo&&!site)right+=`<button class="signin" onclick="MB.auth.signOut()">Sign out</button>`;
  if(S.mode==="merchant"&&m&&m.status==="approved"){right+=`<div style="position:relative"><button class="iconbtn" aria-label="Notifications" onclick="S.ui.bell=!S.ui.bell;renderTop()">${I.bell}${unread?`<span class="dot num">${unread}</span>`:""}</button>${S.ui.bell?bellPanel(m):""}</div>`}
  t.innerHTML=t.querySelector(".brand").outerHTML+'<div class="top-mid">'+mid+'</div><div class="top-right">'+right+'</div>';
}

/* ============ MERCHANT SIDE ============ */
function activeMerchant(){if(S.canEdit&&S.mode==="merchant"){if(S.previewId&&S.merchants[S.previewId])return S.merchants[S.previewId];return S.me}return S.me}
function mPath(){const m=activeMerchant();return m?"merchants/"+m.id:"merchants/"+S.uid}
function previewBar(){if(!S.canEdit)return"";const list=vals(S.merchants).sort((a,b)=>(a.businessName||"").localeCompare(b.businessName||""));return `<div class="notice info row between"><span><b>Team preview.</b> You're seeing the merchant side. Pick a merchant to see exactly what they see.</span><select id="pv" style="width:auto;max-width:100%" onchange="S.previewId=this.value||null;render(true)"><option value="">Your own merchant account</option>${list.map(m=>`<option value="${esc(m.id)}" ${S.previewId===m.id?"selected":""}>${esc(m.businessName||m.fullName||"Unnamed")}${m.demo?" (sample)":""}</option>`).join("")}</select></div>`}
function merchantShell(){
  const m=activeMerchant();
  if(S.justSubmitted&&(!m||m.status==="pending")&&!S.previewId)return `<div class="shell solo"><main>${confirmScreen()}</main></div>`;
  S.justSubmitted=false;
  if(!m)return `<div class="shell solo"><main>${previewBar()}${onboarding()}</main></div>`;
  if(m.status==="pending")return `<div class="shell solo"><main>${previewBar()}${holding(m)}</main></div>`;
  if(m.status==="resubmit"||m.status==="rejected"){if(S.draft.editing)return `<div class="shell solo"><main>${previewBar()}${profileForm(m,true)}</main></div>`;return `<div class="shell solo"><main>${previewBar()}${feedbackScreen(m)}</main></div>`}
  const feed=feedFor(m);const apps=vals(m.applications);
  const nav=[["dashboard","Dashboard"],["feed","Opportunities",feed.length],["apps","Applications",apps.length],["profile","My profile"],["inbox","Inbox",vals(m.notifications).filter(n=>!n.read).length||""]];
  const views={dashboard:mDashboard,feed:mFeed,apps:mApps,profile:mProfile,inbox:mInbox};
  return `<div class="shell"><nav class="nav" aria-label="Merchant">${nav.map(([k,l,c])=>`<button aria-current="${S.view===k?"page":"false"}" onclick="go(null,'${k}')">${l}${c?`<span class="count num">${c}</span>`:""}</button>`).join("")}</nav><main>${previewBar()}${(views[S.view]||mDashboard)(m,feed)}</main></div>`;
}
function wizSteps(){return `<div class="wizard-steps">${["Your store","Your profile","Review"].map((l,i)=>`<span class="${S.wizard===i+1?"on":S.wizard>i+1?"done":""}">${i+1}. ${l}</span>`).join("")}</div>`}
function onboarding(){
  const d=S.draft;
  if(S.wizard===1)return `<div class="stack" style="gap:18px;max-width:860px">${wizSteps()}<div><h1>Where do you sell today?</h1><p class="muted">Shopify stores connect in a click. Everyone else adds a few details by hand.</p></div>
  <div class="platforms">${PLATFORMS.map(([p,s])=>`<button class="platform" aria-pressed="${d.platform===p}" onclick="S.draft.platform='${p}';render(true)"><b>${p}</b><span class="small muted">${s}</span></button>`).join("")}</div>
  ${d.platform?`<div class="card stack">${d.platform==="Shopify"?`<div class="field"><label for="f-shop">Your Shopify store address</label><input id="f-shop" type="text" placeholder="yourstore.myshopify.com" value="${esc(d.storeUrl||"")}" oninput="S.draft.storeUrl=this.value"><span class="hint">We'll pull your store name, catalogue size and order range when the Shopify connection goes live. For now we verify it by hand during review.</span></div>`:`<div class="field"><label for="f-url">Your store website</label><input id="f-url" type="url" placeholder="https://yourbrand.com" value="${esc(d.storeUrl||"")}" oninput="S.draft.storeUrl=this.value"></div>`}
  <div class="row between"><button class="btn ghost" onclick="S.draft={};if(S.canEdit)S.mode='site';render(true);scrollTo(0,0)">Back</button><button class="btn primary" onclick="if(!(S.draft.storeUrl||'').trim()){toast('Add your store address to continue');return}S.wizard=2;render(true);scrollTo(0,0)">Continue</button></div></div>`:""}</div>`;
  if(S.wizard===2)return profileForm(d,false);
  return confirmScreen();
}
function bindDraft(target){return `oninput="const t=event.target;if(t.name&&!/^(radio|checkbox|file)$/.test(t.type))${target}[t.name]=t.value"`}
function profileForm(src,resubmitting){
  const d=S.draft;const isWizard=!resubmitting&&!S.draft.editingApproved;
  if(!d._init){Object.assign(d,JSON.parse(JSON.stringify({fullName:"",businessName:"",category:"",description:"",targetMarket:"",aov:"",orderVolume:"",customBranding:null,markets:[],revenue:"",channels:[],email:"",...pick(src)})));d._init=true}
  const words=(d.description||"").trim().split(/\s+/).filter(Boolean).length;
  const chk=(name,list)=>`<div class="checks">${list.map(v=>`<label class="chk"><input type="checkbox" ${(d[name]||[]).includes(v)?"checked":""} onchange="toggleArr('${name}','${v}',this.checked)"> ${v}</label>`).join("")}</div>`;
  const opt=(list,cur)=>`<option value="">Choose…</option>`+list.map(v=>`<option ${cur===v?"selected":""}>${v}</option>`).join("");
  return `<div class="stack" style="gap:18px;max-width:860px">${isWizard?wizSteps():""}
  <div><h1>${resubmitting?"Update your profile":S.draft.editingApproved?"Edit your profile":"Tell us about your business"}</h1><p class="muted">${resubmitting?"Make the changes from our feedback, then resubmit. We'll take a second look within 48 hours.":"The more complete this is, the better your matches."}</p></div>
  ${resubmitting&&src.feedback?`<div class="notice"><b>Our feedback:</b> ${esc(src.feedback)}</div>`:""}
  <form class="card formgrid" onsubmit="event.preventDefault();submitProfile(${resubmitting})" ${bindDraft("S.draft")}>
    <div class="field"><label for="p-fn">Full name</label><input id="p-fn" name="fullName" type="text" required value="${esc(d.fullName)}"></div>
    <div class="field"><label for="p-bn">Business name</label><input id="p-bn" name="businessName" type="text" required value="${esc(d.businessName)}"></div>
    <div class="field"><label for="p-em">Email for updates</label><input id="p-em" name="email" type="email" required value="${esc(d.email)}"></div>
    <div class="field" id="fld-category"><label for="p-cat">Product category</label><select id="p-cat" name="category" required>${opt(CATEGORIES,d.category)}</select></div>
    <div class="field full" id="fld-description"><label for="p-desc">What you sell, in a few lines</label><textarea id="p-desc" name="description" maxlength="1200" oninput="document.getElementById('wc').textContent=this.value.trim().split(/\\s+/).filter(Boolean).length">${esc(d.description)}</textarea><span class="hint"><span id="wc" class="num">${words}</span> / 150 words</span></div>
    <div class="field full" id="fld-targetMarket"><label for="p-tm">Who your customers are</label><input id="p-tm" name="targetMarket" type="text" placeholder="e.g. Women 25–45 who buy clean skincare gifts" value="${esc(d.targetMarket)}"></div>
    <div class="field" id="fld-aov"><label for="p-aov">Average order value</label><input id="p-aov" name="aov" type="text" placeholder="e.g. $45" value="${esc(d.aov)}"></div>
    <div class="field" id="fld-orderVolume"><label for="p-vol">Monthly orders (rough range)</label><select id="p-vol" name="orderVolume">${opt(VOLUME,d.orderVolume)}</select></div>
    <div class="field" id="fld-revenue"><label for="p-rev">Monthly revenue range</label><select id="p-rev" name="revenue">${opt(REVENUE,d.revenue)}</select></div>
    <div class="field" id="fld-customBranding"><span class="flabel">Can you do custom branding or packaging?</span><div class="checks"><label class="chk"><input type="radio" name="cb" ${d.customBranding===true?"checked":""} onchange="S.draft.customBranding=true"> Yes</label><label class="chk"><input type="radio" name="cb" ${d.customBranding===false?"checked":""} onchange="S.draft.customBranding=false"> No</label></div></div>
    <div class="field full" id="fld-markets"><span class="flabel">Markets you ship to</span>${chk("markets",MARKETS)}</div>
    <div class="field full" id="fld-channels"><span class="flabel">Where you sell now</span>${chk("channels",CHANNELS)}</div>
    <div class="field full" id="fld-supplierDoc"><span class="flabel">Supplier profile document <span class="faint">(optional)</span></span>${S.assets?`<input type="file" id="p-file" accept=".pdf,.png,.jpg,.jpeg,.txt" onchange="S.draft._file=this.files[0]||null"><span class="hint">PDF or image. Don't have one? We'll connect you to someone that will prepare it for you at no cost.</span>`:`<span class="hint">Don't have one? We'll connect you to someone that will prepare it for you at no cost. ${src?.supplierDoc?.status&&src.supplierDoc.status!=="none"?"Current status: "+esc(docStatus(src.supplierDoc.status)):""}</span>`}</div>
    ${isWizard?`<p class="full small muted">By submitting, you agree to our <a href="#terms" onclick="legalModal('terms');return false">Terms of Service</a> and <a href="#privacy" onclick="legalModal('privacy');return false">Privacy Policy</a>.</p>`:""}
    <div class="full row between"><button type="button" class="btn ghost" onclick="${isWizard?"S.wizard=1;render(true)":"S.draft={};render(true)"}">${isWizard?"Back":"Cancel"}</button><button class="btn primary" type="submit">${resubmitting?"Resubmit for review":S.draft.editingApproved?"Save changes":"Submit application"}</button></div>
  </form></div>`;
}
function pick(m){if(!m)return{};const o={};["fullName","businessName","category","description","targetMarket","aov","orderVolume","customBranding","markets","revenue","channels","email","storeUrl","platform"].forEach(k=>{if(m[k]!==undefined)o[k]=m[k]});return o}
function toggleArr(name,v,on){const a=new Set(S.draft[name]||[]);on?a.add(v):a.delete(v);S.draft[name]=[...a]}
async function uploadDoc(file){if(!file||!S.assets)return null;try{const r=await S.assets.upload(file);return{status:"uploaded",assetId:r.id,url:r.url,name:file.name,at:nowIso()}}catch(e){toast("Couldn't upload the document — you can add it later from your profile.");return null}}
async function submitProfile(resubmitting){
  const d=S.draft;const words=(d.description||"").trim().split(/\s+/).filter(Boolean).length;
  if(!d.fullName||!d.businessName||!d.category||!d.email){toast("Fill in your name, business, email and category.");return}
  if(words>150){toast("Keep the description to 150 words or fewer.");return}
  const body=pick(d);const doc=d._file?await uploadDoc(d._file):null;
  const m=activeMerchant();const path=mPath();
  if(S.draft.editingApproved){
    const keyChanged=["category","orderVolume","revenue"].filter(k=>m[k]!==body[k]);
    const patch={...body};if(doc)patch.supplierDoc=doc;if(keyChanged.length)patch.keyChange={fields:keyChanged,at:nowIso(),seen:false};
    await updDoc(path,patch);S.draft={};toast("Profile saved");render(true);return}
  if(resubmitting){await updDoc(path,{...body,...(doc?{supplierDoc:doc}:{}),status:"pending",resubmission:true,submittedAt:nowIso(),feedback:""});S.draft={};toast("Resubmitted — we'll review it within 48 hours");render(true);return}
  const t=nowIso();
  await setDoc(path,{...body,platform:d.platform,storeUrl:d.storeUrl,status:"pending",resubmission:false,createdAt:t,submittedAt:t,lastSeen:t,supplierDoc:doc||{status:"none"},saved:{},pushed:{},applications:{},notifications:{},messages:{},testimonials:{},emails:{}});
  S.justSubmitted=true;S.wizard=1;S.draft={};render(true);scrollTo(0,0);
}
function confirmScreen(){return `<div class="hero" style="grid-template-columns:minmax(0,1fr)"><div class="stack" style="gap:16px;max-width:620px"><span class="ico ok" style="width:44px;height:44px">${I.check}</span><h1>Your profile is with our team.</h1><p style="font-size:17px" class="muted">A real person on the MerchantBridge team will read it within 48 hours. Once you're approved, your feed fills with opportunities picked for what you sell and where you ship, and we'll email you the moment it's ready.</p><p class="muted">While you wait, think about which kinds of buyers you'd love to work with. That's the conversation we'll have next.</p><div><button class="btn primary" onclick="S.justSubmitted=false;render(true)">See my application status</button></div></div></div>`}
function holding(m){return `<div class="hero" style="grid-template-columns:minmax(0,1fr)"><div class="stack" style="gap:14px;max-width:640px"><span class="pill warn" style="align-self:flex-start">${I.clock} Under review${m.resubmission?" · second look":""}</span><h1>Thanks, ${esc(firstName(m))}. We're reviewing ${esc(m.businessName||"your store")}.</h1><p class="muted" style="font-size:17px">You submitted ${ago(m.submittedAt)}. Reviews usually finish within 48 hours, and you'll get an email as soon as your feed is live.</p></div></div><div class="card"><h3 style="margin-bottom:12px">What you sent us</h3>${profileKV(m)}</div>`}
function feedbackScreen(m){const rej=m.status==="rejected";return `<div class="hero" style="grid-template-columns:minmax(0,1fr)"><div class="stack" style="gap:14px;max-width:660px"><span class="pill ${rej?"bad":"warn"}" style="align-self:flex-start">${rej?"Not approved":"Changes requested"}</span><h1>${rej?"We can't approve this profile yet.":"A few changes and you're in."}</h1><div class="quote">${esc(m.feedback||"Our team will be in touch with details.")}</div><div class="row"><button class="btn primary" onclick="S.draft={editing:true};render(true)">Update and resubmit</button></div></div></div>`}
function docStatus(s){return{none:"Not uploaded",preparing:"Being prepared by our team",uploaded:"Uploaded",approved:"Uploaded and approved"}[s]||"Not uploaded"}
function profileKV(m){const rows=[["Business",m.businessName],["Name",m.fullName],["Email",m.email],["Store",(m.platform?m.platform+" · ":"")+(m.storeUrl||"")],["Category",m.category],["About",m.description],["Customers",m.targetMarket],["Average order",m.aov],["Monthly orders",m.orderVolume],["Monthly revenue",m.revenue],["Custom branding",m.customBranding===true?"Yes":m.customBranding===false?"No":""],["Ships to",(m.markets||[]).join(", ")],["Sells on",(m.channels||[]).join(", ")]];return `<dl class="kv">${rows.map(([k,v])=>`<dt>${k}</dt><dd>${v?esc(v):'<span class="faint">Not added</span>'}</dd>`).join("")}</dl>`}

function oppCard(o,m,opts={}){
  const st=oppState(o);const saved=m?.saved?.[o.id];const applied=vals(m?.applications).some(a=>a.oppId===o.id);
  return `<article class="opp ${o.priority==="featured"?"featured":""}"><div class="row between"><div class="row"><span class="pill accent">${esc(o.type)}</span>${o.priority==="featured"?'<span class="pill">Featured</span>':""}${st==="expiring"?'<span class="pill warn">Closes soon</span>':""}${o.demo?'<span class="pill demo">Sample</span>':""}</div><span class="small faint">${ago(o.createdAt)}</span></div>
  <h3>${esc(o.title)}</h3><p class="muted small">${esc(o.description)}</p>
  ${(o.requirements||[]).filter(Boolean).length?`<ul>${o.requirements.filter(Boolean).map(r=>`<li>${esc(r)}</li>`).join("")}</ul>`:""}
  ${o.expiry?`<span class="small faint">Deadline ${fmtDate(o.expiry+"T12:00:00")}</span>`:""}
  ${opts.readonly?"":`<div class="acts"><a class="btn primary sm" href="${esc(o.sourceUrl||"#")}" target="_blank" rel="noopener">View opportunity ${I.ext}</a><button class="btn sm" aria-pressed="${!!saved}" onclick="toggleSave('${o.id}')">${I.bookmark} ${saved?"Saved":"Save"}</button><button class="btn sm" ${applied?"disabled":""} onclick="markApplied('${o.id}')">${I.check} ${applied?"Applied":"I applied"}</button></div>`}</article>`;
}
async function toggleSave(oid){const m=activeMerchant();await updDoc(mPath(),{saved:{[oid]:!m.saved?.[oid]}});toast(m.saved?.[oid]?"Removed from saved":"Saved for later")}
async function markApplied(oid){const o=S.opps[oid];if(!o)return;const id=gid();await updDoc(mPath(),{applications:{[id]:{oppId:oid,title:o.title,type:o.type,status:"Applied",notes:"",appliedAt:nowIso(),updatedAt:nowIso()}}});toast("Added to your applications")}
function derivedAlerts(m){if(!m||m.status!=="approved")return[];const out=[];vals(S.opps).forEach(o=>{if(m.saved?.[o.id]&&oppState(o)==="expiring")out.push({text:`"${o.title}" closes within 48 hours`,kind:"warn",at:new Date(oppEnd(o)).toISOString()})});vals(m.applications).forEach(a=>{if((a.status==="Applied"||a.status==="In conversation")&&Date.now()-ts(a.updatedAt)>14*DAY)out.push({text:`Any news on "${a.title}"? Update its status so we can help.`,kind:"info",at:a.updatedAt,app:true})});return out}
function bellPanel(m){const list=[...derivedAlerts(m),...vals(m.notifications)].sort((a,b)=>ts(b.at)-ts(a.at)).slice(0,12);return `<div class="card panel-pop" role="dialog" aria-label="Notifications"><div class="card-head"><h3>Notifications</h3>${vals(m.notifications).some(n=>!n.read)?`<button class="btn ghost sm" onclick="markAllRead()">Mark all read</button>`:""}</div>${list.length?list.map(notifRow).join(""):'<p class="muted small">Nothing new yet.</p>'}<button class="btn sm" style="margin-top:10px;width:100%" onclick="go(null,'inbox')">Open inbox</button></div>`}
function notifRow(n){const ic={ok:"ok",warn:"warn",bad:"bad",info:"info",match:""}[n.kind]??"";return `<div class="li"><span class="ico ${ic}">${n.kind==="msg"?I.msg:n.kind==="match"?I.bolt:I.bell}</span><div class="grow"><p class="small" style="${n.read===false?"font-weight:600":""}">${esc(n.text)}</p><span class="small faint">${ago(n.at)}</span></div></div>`}
async function markAllRead(){const m=activeMerchant();const patch={};vals(m.notifications).forEach(n=>{if(!n.read)patch[n.id]={read:true}});await updDoc(mPath(),{notifications:patch});renderTop()}

function mDashboard(m,feed){
  const c=completion(m);const apps=vals(m.applications).sort((a,b)=>ts(b.updatedAt)-ts(a.updatedAt));
  const notes=[...derivedAlerts(m),...vals(m.notifications)].sort((a,b)=>ts(b.at)-ts(a.at)).slice(0,5);
  return `<div class="page-head"><div><span class="eyebrow">Welcome back</span><h1>Hi ${esc(firstName(m))}, here's what's new for ${esc(m.businessName)}.</h1></div></div>
  <section class="stack"><div class="row between"><h2>Latest matches</h2><button class="btn sm" onclick="go(null,'feed')">View all ${feed.length}</button></div>
  ${feed.length?`<div class="opp-grid">${feed.slice(0,3).map(o=>oppCard(o,m)).join("")}</div>`:emptyFeed()}</section>
  <div class="grid g2">
   <section class="card"><div class="card-head"><h3>Profile strength</h3><span class="num" style="font-weight:700">${c.pct}%</span></div><div class="bar ${c.pct===100?"ok":""}"><i style="width:${c.pct}%"></i></div><p class="small muted" style="margin-top:10px">${c.pct===100?"Your profile is complete — you're getting every match you qualify for.":"Incomplete profiles get fewer matches. Finish these:"}</p>${c.missing.length?`<div class="row" style="margin-top:10px">${c.missing.map(([k,l])=>`<button class="btn sm" onclick="editField('${k}')">${l}</button>`).join("")}</div>`:""}</section>
   <section class="card"><div class="card-head"><h3>Your applications</h3><button class="btn ghost sm" onclick="go(null,'apps')">Open tracker</button></div>${apps.length?apps.slice(0,4).map(a=>`<div class="li"><div class="grow"><p style="font-weight:600">${esc(a.title)}</p><span class="small faint">${esc(a.type)} · applied ${fmtDate(a.appliedAt)}</span></div>${statusPill(a.status)}</div>`).join(""):'<p class="muted small">When you apply to an opportunity, tap "I applied" and it shows up here.</p>'}</section>
  </div>
  <section class="card"><div class="card-head"><h3>Updates</h3><button class="btn ghost sm" onclick="go(null,'inbox')">Inbox</button></div>${notes.length?notes.map(notifRow).join(""):'<p class="muted small">Updates from our team, new matches and messages will appear here.</p>'}</section>`;
}
function editField(k){if(k==="supplierDoc"){S.view="profile";render(true);setTimeout(()=>document.getElementById("supplier")?.scrollIntoView({behavior:"smooth"}),50);return}S.view="profile";S.draft={editingApproved:true};render(true);setTimeout(()=>{const el=document.getElementById("fld-"+k);el?.scrollIntoView({behavior:"smooth",block:"center"});el?.querySelector("input,select,textarea")?.focus()},60)}
function statusPill(s){return `<span class="pill ${s==="Deal closed"?"ok":s==="Not successful"?"bad":s==="In conversation"?"info":"warn"}">${esc(s)}</span>`}
function emptyFeed(){return `<div class="empty"><span class="ico">${I.bolt}</span><h3>We're actively sourcing opportunities in your category.</h3><p class="small">Check back soon. We add new ones every week and we'll notify you the moment something matches.</p></div>`}
function mFeed(m,feed){
  const tab=S.ui.feedTab;let list=feed;
  if(tab==="saved")list=sortOpps(vals(S.opps).filter(o=>m.saved?.[o.id]&&oppState(o)!=="archived"));
  if(tab==="archive")list=sortOpps(vals(S.opps).filter(o=>oppState(o)==="archived"&&(m.saved?.[o.id]||matches(m,o,true)))).slice(0,40);
  return `<div class="page-head"><div><h1>Opportunities</h1><p class="muted">Matched to your category, capacity, shipping markets and customisation. Each one links to the original source, so you apply directly.</p></div></div>
  <div class="tabs" role="tablist">${[["feed","For you"],["saved","Saved"],["archive","Archive"]].map(([k,l])=>`<button role="tab" aria-selected="${tab===k}" onclick="S.ui.feedTab='${k}';render(true)">${l}</button>`).join("")}</div>
  ${list.length?`<div class="opp-grid">${list.map(o=>oppCard(o,m,{readonly:tab==="archive"})).join("")}</div>`:tab==="feed"?emptyFeed():`<div class="empty"><p>${tab==="saved"?"Save opportunities to come back to them here.":"Expired opportunities move here after 30 days."}</p></div>`}`;
}
function mApps(m){
  const apps=vals(m.applications).sort((a,b)=>ts(b.appliedAt)-ts(a.appliedAt));
  return `<div class="page-head"><div><h1>Application tracker</h1><p class="muted">Keep each one up to date as the conversation moves. Only you and our team see this.</p></div></div>
  ${apps.length?`<div class="tablewrap"><table><thead><tr><th>Opportunity</th><th>Applied</th><th>Status</th><th style="min-width:240px">Notes</th></tr></thead><tbody>${apps.map(a=>`<tr><td><b>${esc(a.title)}</b><div class="sub">${esc(a.type)}</div></td><td class="num">${fmtDate(a.appliedAt)}</td><td><select id="st-${a.id}" style="width:auto" onchange="setAppStatus('${a.id}',this.value)">${APP_STATUS.map(s=>`<option ${a.status===s?"selected":""}>${s}</option>`).join("")}</select></td><td><input id="nt-${a.id}" type="text" placeholder="Who you spoke to, next steps…" value="${esc(a.notes)}" onchange="setAppNote('${a.id}',this.value)"></td></tr>`).join("")}</tbody></table></div>`:`<div class="empty"><h3>No applications yet</h3><p class="small">Open an opportunity, apply with the source, then tap "I applied".</p><button class="btn primary sm" onclick="go(null,'feed')">Browse opportunities</button></div>`}`;
}
async function setAppStatus(id,status){const m=activeMerchant();const a=m.applications[id];await updDoc(mPath(),{applications:{[id]:{status,updatedAt:nowIso()}}});toast("Status updated");if(status==="Deal closed"&&a.status!=="Deal closed"){queueEmail(m.id,"dealClosed",{opportunity:a.title}).catch(()=>{});notifyMerchant(m.id,`Congratulations on closing "${a.title}"!`,"ok").catch(()=>{});testimonialModal(a)}}
async function setAppNote(id,notes){await updDoc(mPath(),{applications:{[id]:{notes,updatedAt:nowIso()}}});toast("Note saved")}
function testimonialModal(a){openModal(`<div class="modal-head"><div><span class="eyebrow">Congratulations</span><h2>You closed "${esc(a.title)}"!</h2></div>${closeBtn()}</div><p class="muted">Would you share a line or two about your experience? It helps other independent brands find us. Our team reviews every note before it's used anywhere.</p><div class="field"><span class="flabel">Your rating</span><div class="checks">${[5,4,3,2,1].map(n=>`<label class="chk"><input type="radio" name="rt" value="${n}" ${n===5?"checked":""}> ${n} ★</label>`).join("")}</div></div><div class="field"><label for="t-text">Your words</label><textarea id="t-text" placeholder="What changed for your store?"></textarea></div><div class="row between"><button class="btn ghost" onclick="closeModal()">Maybe later</button><button class="btn primary" onclick="submitTestimonial('${esc(a.title)}')">Share testimonial</button></div>`)}
async function submitTestimonial(title){const text=document.getElementById("t-text").value.trim();if(!text){toast("Write a few words first");return}const rating=+document.querySelector('input[name=rt]:checked').value;const id=gid();await updDoc(mPath(),{testimonials:{[id]:{text,rating,oppTitle:title,at:nowIso(),status:"pending"}}});closeModal();toast("Thank you — our team will review it")}
function mProfile(m){
  if(S.draft.editingApproved)return profileForm(m,false);
  const c=completion(m);const sd=m.supplierDoc||{status:"none"};
  return `<div class="page-head"><div><h1>${esc(m.businessName)}</h1><p class="muted">This is your profile as our team sees it. Keep it current for better matches.</p></div><button class="btn primary" onclick="S.draft={editingApproved:true};render(true)">Edit profile</button></div>
  <div class="card"><div class="card-head"><div class="row"><span class="pill accent">${esc(m.category||"No category")}</span><span class="pill ok">Approved</span></div><span class="small muted">Profile ${c.pct}% complete</span></div>${profileKV(m)}</div>
  <div class="card" id="supplier"><div class="card-head"><h3>Supplier profile document</h3><span class="pill ${sd.status==="approved"?"ok":sd.status==="none"?"":"warn"}">${docStatus(sd.status)}</span></div>
  ${sd.url?`<p class="small">On file: <a href="${esc(sd.url)}" target="_blank" rel="noopener">${esc(sd.name||"Supplier profile")}</a> · added ${fmtDate(sd.at)}</p>`:`<p class="muted small">Buyers trust suppliers with a clean one-page profile. Don't have one? We'll connect you to someone that will prepare it for you at no cost.</p>`}
  <div class="row" style="margin-top:12px">${S.assets?`<label class="btn sm">${I.doc} ${sd.url?"Replace document":"Upload document"}<input type="file" hidden accept=".pdf,.png,.jpg,.jpeg,.txt" onchange="replaceDoc(this.files[0])"></label>`:""}${sd.status==="none"?`<button class="btn primary sm" onclick="askSpecialist()">Connect me with someone to prepare one</button>`:""}<button class="btn ghost sm" onclick="messageTeamModal()">${I.msg} Message the team</button></div></div>`;
}
async function replaceDoc(f){const d=await uploadDoc(f);if(d){await updDoc(mPath(),{supplierDoc:d});toast("Document uploaded")}}
async function askSpecialist(){const id=gid();await updDoc(mPath(),{supplierDoc:{status:"preparing"},messages:{[id]:{from:"merchant",text:"Hi! I'd like help preparing a supplier profile document.",at:nowIso()}}});toast("Request sent — our specialist will reach out")}
function messageTeamModal(){openModal(`<div class="modal-head"><h2>Message the MerchantBridge team</h2>${closeBtn()}</div><textarea id="mt-text" placeholder="How can we help?"></textarea><div class="row between"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="sendMerchantMsg()">Send message</button></div>`)}
async function sendMerchantMsg(){const t=document.getElementById("mt-text").value.trim();if(!t)return;const id=gid();await updDoc(mPath(),{messages:{[id]:{from:"merchant",text:t,at:nowIso()}}});closeModal();toast("Message sent")}
function mInbox(m){
  const items=[...derivedAlerts(m),...vals(m.notifications)].sort((a,b)=>ts(b.at)-ts(a.at));
  const msgs=vals(m.messages).sort((a,b)=>ts(a.at)-ts(b.at));
  return `<div class="page-head"><div><h1>Inbox</h1><p class="muted">Updates, new matches and messages from your specialist.</p></div><div class="row"><button class="btn sm" onclick="markAllRead()">Mark all read</button><button class="btn primary sm" onclick="messageTeamModal()">${I.msg} New message</button></div></div>
  <div class="grid g2"><section class="card"><h3 style="margin-bottom:6px">Notifications</h3>${items.length?items.map(notifRow).join(""):'<p class="muted small">Nothing yet.</p>'}</section>
  <section class="card"><h3 style="margin-bottom:6px">Messages with our team</h3>${msgs.length?msgs.map(x=>`<div class="li"><span class="ico ${x.from==="team"?"":"info"}">${x.from==="team"?I.msg:I.user}</span><div class="grow"><p class="small"><b>${x.from==="team"?"MerchantBridge":"You"}</b> · <span class="faint">${ago(x.at)}</span></p><p class="small" style="white-space:pre-wrap">${esc(x.text)}</p></div></div>`).join(""):'<p class="muted small">No messages yet. Questions about an opportunity or your profile? Send us a note.</p>'}</section></div>`;
}


/* ============ PUBLIC LANDING PAGE ============ */
function signIn(){if(!S.uid&&window.MB?.auth){MB.auth.prompt("signin");return}if(S.me){clearPage();S.mode="merchant";S.view="dashboard";S.draft={};render(true);scrollTo(0,0);return}openModal(`<div class="modal-head"><div><span class="eyebrow">Sign in</span><h2>Welcome back</h2></div>${closeBtn()}</div><p class="muted">${S.uid?"We couldn't find a MerchantBridge profile for this account yet. Join to create one — it takes about five minutes.":"Merchant sign in opens when the new site goes live on demerchantbridge.com. New here? Join to apply."}</p><div class="row between"><button class="btn ghost" onclick="closeModal()">Close</button><button class="btn primary" onclick="closeModal();startApply()">Join MerchantBridge</button></div>`)}
addEventListener("scroll",()=>{document.getElementById("top")?.classList.toggle("scrolled",scrollY>12)},{passive:true});

const TYPE_INFO={"Corporate Gifting":"Holiday and milestone gifting programs for companies buying at scale.","Bulk Buyers":"Buyers who want large quantities direct from your store.","Wholesale":"Accounts that stock and resell your products.","Retail Listing":"Shops that want to carry your brand in store or online.","Corporate Procurement":"Procurement teams sourcing vendors for recurring needs.","Distributors":"Partners who take your products into new regions and channels.","Employee Rewards":"Recognition platforms that feature merchandise for staff.","Hospitality":"Hotels, airlines and venues sourcing amenities and guest gifts.","Events":"Conferences and trade shows sourcing branded merchandise.","Brand Partnership":"Brands looking to co-create, bundle or cross-promote.","UGC Campaign":"Campaigns that pay for content made with your products.","Product Sourcing":"Buyers searching for a specific product they can't find."};
function showSite(){if(S.justSubmitted)return false;if(S.page)return true;if(S.mode==="site")return true;if(S.mode==="team"&&S.canEdit)return false;return !activeMerchant()&&!S.draft.started}
function startApply(){if(!S.uid&&window.MB?.auth){MB.auth.prompt("apply");return}if(!S.canWrite&&!S.canEdit){openModal(`<div class="modal-head"><div><span class="eyebrow">Preview</span><h2>Applications open when the site goes live</h2></div>${closeBtn()}</div><p class="muted">You're viewing a preview of the new MerchantBridge. Applying needs a signed-in account with access to this preview. Once it's live on demerchantbridge.com, anyone can apply.</p><div class="row" style="justify-content:flex-end"><button class="btn primary" onclick="closeModal()">Got it</button></div>`);return}clearPage();S.mode="merchant";S.previewId=null;S.draft={started:true,platform:"",markets:[],channels:[]};S.wizard=1;S.ui.bell=false;render(true);window.scrollTo(0,0)}
function jump(id){if(S.page){clearPage();S.mode="site";render(true);requestAnimationFrame(()=>document.getElementById(id)?.scrollIntoView());return}document.getElementById(id)?.scrollIntoView({behavior:matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth"})}

const EXAMPLE_BRIEFS=[["Corporate Gifting","Holiday gift boxes for a 400-person tech team","US"],["Hospitality","Boutique hotel group sourcing room fragrance","US"],["Wholesale","Gift shop chain adding winter candles","US & Canada"],["Retail Listing","Sydney concept store reviewing new jewelry brands","Australia"],["Employee Rewards","Rewards platform adding premium pet products","US"],["Events","Trade show organiser sourcing branded tote bags","Canada"],["Bulk Buyers","Spa chain buying skincare minis in bulk","US"],["Product Sourcing","Buyer looking for vegan lip balm with custom labels","UK"]];
function liveTicker(){
  const live=sortOpps(vals(S.opps).filter(o=>oppState(o)!=="archived")).slice(0,14);
  const real=live.length>=3;
  const items=real?live.map(o=>({type:o.type,title:o.title,where:(o.markets||[]).join(", ")||"Any market",when:ago(o.createdAt),closing:oppState(o)==="expiring",demo:o.demo})):EXAMPLE_BRIEFS.map(([type,title,where])=>({type,title,where,when:"",example:true}));
  const card=(b,hidden)=>`<button class="brief" ${hidden?'tabindex="-1" aria-hidden="true"':""} onclick="startApply()"><div class="row between"><span class="pill accent">${esc(b.type)}</span>${b.closing?'<span class="pill warn">Closes soon</span>':b.example||b.demo?'<span class="pill demo">'+(b.example?"Example":"Sample")+'</span>':""}</div><b>${esc(b.title)}</b><div class="meta"><span>Ships to ${esc(b.where)}</span><span>${esc(b.when)}</span></div></button>`;
  const dur=Math.max(40,items.length*7);
  return `<section class="ticker" aria-label="${real?"Live briefs":"Example briefs"}"><div class="ticker-head"><span class="live-badge">${real?'<span class="live-dot"></span>Live briefs':"Example briefs"}</span><span class="small muted">${real?`${live.length} open right now · `:""}Tap any brief to join and see the full details</span></div>
  <div class="track-wrap"><div class="track" style="--dur:${dur}s">${items.map(b=>card(b)).join("")}${items.map(b=>card(b,true)).join("")}</div></div></section>`;
}


/* ---- reviews spotlight ---- */
const PLACEHOLDER_REVIEWS=[
 {name:"Placeholder reviewer",store:"Skincare brand",category:"Skincare",rating:5,closed:"Wholesale account",text:"This is placeholder text so you can see how a long review looks in this section. Replace it by publishing a real review from the Testimonials page.\n\nA real review here might describe where the store was before joining, the first opportunity they found, what the application process felt like, and what changed for the business after the deal closed. Longer, specific stories work best because they show visitors exactly what MerchantBridge does for a brand like theirs.",placeholder:true},
 {name:"Placeholder reviewer",store:"Candle studio",category:"Candles",rating:5,closed:"Corporate gifting order",text:"Placeholder review two. Use this space for a merchant's own words about a corporate gifting order, a retail listing or a hotel amenities deal they found through MerchantBridge.\n\nOnly reviews your team approves and publishes from the app will ever show here on the live site. These placeholders disappear automatically as soon as the first real review is published.",placeholder:true},
 {name:"Placeholder reviewer",store:"Jewelry label",category:"Jewelry",rating:5,closed:"Retail listing",text:"Placeholder review three. A good review mentions the product category, the kind of buyer they connected with, how quickly the profile was reviewed and whether the free supplier profile help made a difference.\n\nKeep the full text. The card shows the first few lines and visitors tap Read full review to see everything.",placeholder:true}];
let SPOT={i:0,t:0,last:0,paused:false,n:0,raf:0};
function siteReviews(){const r=vals(S.reviews).sort((a,b)=>(b.featured?1:0)-(a.featured?1:0)||ts(b.at)-ts(a.at));return r.length?r:PLACEHOLDER_REVIEWS}
function reviewsSection(){
  const list=siteReviews().slice(0,6);SPOT.n=list.length;if(SPOT.i>=list.length)SPOT.i=0;
  return `<section class="band dark" id="reviews"><div class="band-in">
  <div class="sec-head split"><div class="sec-head"><span class="eyebrow">In their words</span><h2 class="h-sec">Brands that found their next buyer here.</h2></div><div class="spot-ctrl"><button aria-label="Previous review" onclick="spotGo(-1)">←</button><button aria-label="Next review" onclick="spotGo(1)">→</button></div></div>
  <div class="spot" onmouseenter="SPOT.paused=true" onmouseleave="SPOT.paused=false" onfocusin="SPOT.paused=true" onfocusout="SPOT.paused=false">
   <div class="who" role="tablist" aria-label="Reviewers">${list.map((r,k)=>`<button role="tab" id="who-${k}" class="${k===SPOT.i?"on":""}" aria-selected="${k===SPOT.i}" onclick="spotSet(${k})"><b>${esc(r.name)}</b><span class="sub">${esc(r.store)}${r.placeholder?' · <span class="pill demo">Placeholder</span>':""}</span><span class="prog"><i id="prog-${k}"></i></span></button>`).join("")}</div>
   <div class="stage" aria-live="polite">${list.map((r,k)=>`<article class="slide ${k===SPOT.i?"on":""}" id="slide-${k}" ${k===SPOT.i?"":'aria-hidden="true"'}><span class="qmark" aria-hidden="true">“</span><p class="rtext">${esc(r.text)}</p><button class="readmore" ${k===SPOT.i?"":'tabindex="-1"'} onclick="openReview(${k})">Read full review →</button><div class="rfoot"><div><b>${esc(r.name)}</b><span>${esc(r.store)} · ${esc(r.category||"")}</span></div><div style="text-align:right"><span class="stars" aria-label="${r.rating||5} of 5">${"★".repeat(r.rating||5)}</span>${r.closed?`<br><span>Closed: ${esc(r.closed)}</span>`:""}</div></div></article>`).join("")}</div>
  </div>
  <div class="row" style="justify-content:space-between;gap:16px;border-top:1px solid rgba(255,255,255,.1);padding-top:24px"><p style="color:#CBD5E1;max-width:52ch">Closed a deal or landed a buyer through MerchantBridge? Your story helps other independent brands take the first step.</p><button class="btn primary lg" onclick="tellStory()">Tell your story</button></div>
  </div></section>`;
}

function tellStory(){
  const m=S.me;const signed=!!S.uid&&S.canWrite!==false;const approved=m?.status==="approved";const applied=vals(m?.applications).length>0;
  if(signed&&approved&&applied)return storyForm();
  const step=(ok,t,sub)=>`<div class="li"><span class="ico ${ok?"ok":""}">${ok?I.check:I.clock}</span><div class="grow"><p style="font-weight:600">${t}</p><span class="small faint">${sub}</span></div></div>`;
  const next=!signed?(window.MB?.auth?`<button class="btn primary" onclick="closeModal();MB.auth.prompt('signin')">Sign in</button>`:""):!m?`<button class="btn primary" onclick="closeModal();startApply()">Join MerchantBridge</button>`:!approved?`<button class="btn primary" onclick="closeModal();S.mode='merchant';render(true);scrollTo(0,0)">Check my application</button>`:`<button class="btn primary" onclick="closeModal();S.mode='merchant';S.view='feed';render(true);scrollTo(0,0)">Browse my matches</button>`;
  openModal(`<div class="modal-head"><div><span class="eyebrow">Tell your story</span><h2>Stories come from members who've applied</h2></div>${closeBtn()}</div><p class="muted">So every review on this page is real, you can share yours once you've done these three things:</p><div>${step(signed,"Sign in to your account",signed?"Done":"Sign in to continue")}${step(approved,"Get your profile reviewed and approved",approved?"Done":m?"Your profile is "+statusLabel(m.status).toLowerCase():"Join to submit your profile")}${step(applied,"Apply for at least one brief",applied?"Done":"Tap “I applied” on a brief in your feed")}</div><div class="row between"><button class="btn ghost" onclick="closeModal()">Close</button>${next}</div>`);
}
function storyForm(){const apps=vals(S.me.applications).sort((a,b)=>ts(b.appliedAt)-ts(a.appliedAt));openModal(`<div class="modal-head"><div><span class="eyebrow">Tell your story</span><h2>How has MerchantBridge helped ${esc(S.me.businessName)}?</h2></div>${closeBtn()}</div><p class="small muted">Our team reads every story before it goes on the website. We show your first name, last initial and store name.</p>
 <div class="field"><label for="sy-app">Which brief is this about?</label><select id="sy-app">${apps.map(a=>`<option value="${esc(a.title)}">${esc(a.title)} · ${esc(a.status)}</option>`).join("")}<option value="">My experience overall</option></select></div>
 <div class="field"><span class="flabel">Your rating</span><div class="checks">${[5,4,3,2,1].map(n=>`<label class="chk"><input type="radio" name="sy-rt" value="${n}" ${n===5?"checked":""}> ${n} ★</label>`).join("")}</div></div>
 <div class="field"><label for="sy-text">Your story</label><textarea id="sy-text" style="min-height:200px" placeholder="Where was your store before? What did you find here? What happened next?"></textarea></div>
 <div class="row between"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="submitStory()">Send my story</button></div>`)}
async function submitStory(){const text=document.getElementById("sy-text").value.trim();if(text.split(/\s+/).length<15){toast("Tell us a bit more — at least a few sentences");return}const rating=+document.querySelector('input[name=sy-rt]:checked').value;const id=gid();await updDoc("merchants/"+S.me.id,{testimonials:{[id]:{text,rating,oppTitle:document.getElementById("sy-app").value,at:nowIso(),status:"pending",source:"story"}}});closeModal();toast("Thank you! Our team will review your story")}

function spotSet(k){if(!SPOT.n)return;SPOT.i=(k+SPOT.n)%SPOT.n;SPOT.t=0;for(let j=0;j<SPOT.n;j++){const on=j===SPOT.i;document.getElementById("slide-"+j)?.classList.toggle("on",on);const sl=document.getElementById("slide-"+j);if(sl){on?sl.removeAttribute("aria-hidden"):sl.setAttribute("aria-hidden","true");const rm=sl.querySelector(".readmore");if(rm)on?rm.removeAttribute("tabindex"):rm.setAttribute("tabindex","-1")}const w=document.getElementById("who-"+j);if(w){w.classList.toggle("on",on);w.setAttribute("aria-selected",on)}const p=document.getElementById("prog-"+j);if(p)p.style.width="0%"}}
function spotGo(d){spotSet(SPOT.i+d)}
function spotTick(now){const dt=SPOT.last?now-SPOT.last:0;SPOT.last=now;const reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;if(document.getElementById("slide-0")&&!SPOT.paused&&!reduce&&!document.getElementById("modal").innerHTML){SPOT.t+=dt;const dur=9000;const p=document.getElementById("prog-"+SPOT.i);if(p)p.style.width=Math.min(100,SPOT.t/dur*100)+"%";if(SPOT.t>=dur)spotGo(1)}SPOT.raf=requestAnimationFrame(spotTick)}
requestAnimationFrame(spotTick);
function openReview(k){const r=siteReviews()[k];if(!r)return;openModal(`<div class="modal-head"><div class="stack s6"><span class="stars" aria-label="${r.rating||5} of 5">${"★".repeat(r.rating||5)}</span><h2>${esc(r.name)}</h2><span class="small muted">${esc(r.store)} · ${esc(r.category||"")}${r.closed?" · Closed: "+esc(r.closed):""}</span></div>${closeBtn()}</div><p class="review-full">${esc(r.text)}</p><div class="row between"><button class="btn ghost" onclick="closeModal();spotGo(-1);openReview(SPOT.i)">← Previous</button><button class="btn primary" onclick="closeModal();startApply()">Join MerchantBridge</button><button class="btn ghost" onclick="closeModal();spotGo(1);openReview(SPOT.i)">Next →</button></div>`)}

function sitePage(){
  const live=sortOpps(vals(S.opps).filter(o=>oppState(o)!=="archived")).slice(0,6);
  const tick=I.check;
  return `<div class="site">
  ${S.canEdit&&S.mode==="merchant"?`<div class="band-in" style="padding-block:16px 0">${previewBar()}</div>`:""}
  <section class="band" style="padding-block:clamp(40px,7vw,96px) clamp(56px,8vw,104px)"><div class="band-in"><div class="s-hero">
    <div class="stack" style="gap:24px"><span class="eyebrow">For independent e-commerce brands</span>
      <h1 class="display">We find the opportunities. <em>You close the deals.</em></h1>
      <p class="lede">Tell us what you sell and what you can supply. Our team reviews your profile, then matches you with wholesale, retail, gifting and sourcing opportunities that fit. You apply directly with the source, and every deal stays yours.</p>
      <div class="row" style="gap:12px"><button class="btn primary lg" onclick="startApply()">Join MerchantBridge</button><button class="btn lg" onclick="jump('how')">See how it works</button></div>
      <div class="trust"><span>${tick} Free to join</span><span>${tick} Reviewed within 48 hours</span><span>${tick} No commission on deals</span></div>
    </div>
    <div class="matchviz" aria-label="Example of matched opportunities">
      <span class="viz-label">Example matches for a candle brand</span>
      ${[["Corporate Gifting","Holiday gift boxes for a 400-person tech team","Custom sleeves · Ships US · Due early Dec"],["Hospitality","Boutique hotel group sourcing room fragrance","40 properties · Custom label · Quarterly orders"],["Wholesale","Gift shop chain adding winter candles","3–5 SKUs · Ships US & Canada · 50% wholesale"]].map(([t,h,d])=>`<div class="mcard"><span class="pill accent" style="align-self:flex-start">${t}</span><b>${h}</b><span class="small faint">${d}</span></div>`).join("")}
      <div class="profile-chip"><span class="ico ok" style="width:26px;height:26px">${tick}</span><span><b>Profile reviewed</b><br><span class="k">Usually within 48 hours</span></span></div>
    </div>
  </div></div></section>

  ${liveTicker()}

  <section class="band soft" id="connect"><div class="band-in">
    <div class="sec-head split"><div class="sec-head"><span class="eyebrow">Your store, as it is</span><h2 class="h-sec">Connect the store you already run.</h2></div><p class="lede" style="max-width:44ch">Shopify connects in a few clicks. On another platform or your own site? Add your details by hand in about five minutes.</p></div>
    <div class="platform-row">${[["Shopify","Connect in a click",1],["WooCommerce","Add details by hand"],["BigCommerce","Add details by hand"],["Magento","Add details by hand"],["Wix","Add details by hand"],["Etsy","Add details by hand"],["Your own site","Add details by hand"]].map(([n,d,p])=>`<div class="pf ${p?"primary":""}"><b>${n}</b><span>${d}</span></div>`).join("")}</div>
  </div></section>

  ${reviewsSection()}

  <section class="band" id="types"><div class="band-in">
    <div class="sec-head split"><div class="sec-head"><span class="eyebrow">Where brands grow</span><h2 class="h-sec">Twelve kinds of opportunity, matched to your store.</h2></div><p class="lede" style="max-width:44ch">Your category, capacity, shipping markets and customisation options decide what you see. A candle brand is never shown a software partnership.</p></div>
    <div class="typegrid">${TYPES.map(t=>`<div class="t"><b>${t}</b><p>${TYPE_INFO[t]||""}</p></div>`).join("")}</div>
  </div></section>

  <section class="band soft" id="how"><div class="band-in">
    <div class="sec-head"><span class="eyebrow">How it works</span><h2 class="h-sec">We find them. You get matched. You apply directly.</h2></div>
    <div class="howgrid">${[["We find them","Our team collects wholesale requests, partnership calls, creator campaigns and sourcing needs, and checks each one is still current before it goes live."],["You get matched","Once your profile is approved, you only see opportunities that fit what you make, how much you can produce and where you ship."],["You apply directly","Every listing links to the original source. What happens next is between you and the buyer. We never take a cut."]].map(([h,p],i)=>`<div class="how"><span class="n">Step ${i+1}</span><h3>${h}</h3><p>${p}</p></div>`).join("")}</div>
    <div class="track-note"><span class="ico">${I.bookmark}</span><p><b>Keep track in one place.</b> <span class="muted">Save listings, log every application and update each one as the conversation moves.</span></p></div>
  </div></section>


  <section class="band" id="help"><div class="band-in">
    <div class="help">
      <div class="help-left"><span class="eyebrow">We do the heavy lifting</span><h2 class="h-sec">You apply. We handle the rest.</h2><p class="lede">Most brands miss wholesale deals because they aren't "buyer ready" yet. We fix that with you, step by step, so all you have to do is hit apply.</p>
        <div class="promise">${["We tell you exactly what each buyer expects","We help you prepare every document they ask for","We guide you onto the big wholesale platforms","Stuck at any point? Message us and we'll walk you through it"].map(t=>`<div>${I.check}<span>${t}</span></div>`).join("")}</div>
        <div class="row"><button class="btn primary lg" onclick="startApply()">Join MerchantBridge</button></div>
      </div>
      <div class="docs">
        ${[["Document","Wholesale sheet","Your wholesale prices, case packs and terms laid out the way buyers like to read them."],["Profile","Merchant profile","A one-page profile of your brand, products and capacity that buyers use to judge the fit."],["Presentation","Pitch deck","A short deck that tells your brand story and sells your products to a buyer in minutes."],["Checklist","Readiness checklist","We check your pricing, MOQ, samples, packaging and shipping so nothing catches you off guard."]].map(([t,h,d])=>`<div class="docc"><span class="tag">${t}</span><b>${h}</b><p>${d}</p></div>`).join("")}
        <div class="docc wide"><span class="tag">Platforms</span><b>Getting onto the big wholesale marketplaces</b><p>Want your brand on platforms where retailers shop for new products? We'll guide you through the application, your listing and what gets brands approved.</p><div class="plats">${["Faire","RangeMe","Ankorstore","and more"].map(x=>`<span class="pill">${x}</span>`).join("")}</div></div>
      </div>
    </div>
    <div class="guide">${[["We check your readiness","A quick look at your store, pricing and capacity to see what's missing."],["We prepare with you","Wholesale sheet, merchant profile, pitch deck: whatever the buyer needs."],["We point you to the right briefs","Your feed only shows opportunities you're ready for."],["You hit apply","Apply directly with the buyer. Every deal is yours."]].map(([h,p],i)=>`<div><span class="n">Step ${i+1}</span><b>${h}</b><p>${p}</p></div>`).join("")}</div>
  </div></section>

  <section class="band soft" id="requests"><div class="band-in">
    <div class="sec-head split"><div class="sec-head"><span class="eyebrow">Open requests</span><h2 class="h-sec">Live sourcing requests, added every week.</h2></div><button class="btn primary" onclick="startApply()">Join to see your matches</button></div>
    ${live.length?`<div class="reqgrid">${live.map(o=>`<article class="req"><div class="row between"><span class="pill accent">${esc(o.type)}</span>${o.demo?'<span class="pill demo">Sample</span>':`<span class="small faint">${ago(o.createdAt)}</span>`}</div><h3>${esc(o.title)}</h3><p>${esc(o.description)}</p><div class="lock"><span>Full brief and source link for members</span><button class="btn sm" onclick="startApply()">Apply</button></div></article>`).join("")}</div>`:`<div class="empty"><span class="ico">${I.bolt}</span><h3>New requests land every week</h3><p class="small">Join now and you'll see the ones that fit your store as soon as your profile is approved.</p><button class="btn primary sm" onclick="startApply()">Join MerchantBridge</button></div>`}
  </div></section>

  <section class="band" id="funded"><div class="band-in"><div class="funded">
    <div class="sec-head"><span class="eyebrow">How MerchantBridge is funded</span><h2 class="h-sec">Free to join. Free to stay.</h2></div>
    <div class="body"><p>Access to MerchantBridge is free and always will be. We're run by a digital agency that offers <b>digital marketing services</b> to e-commerce stores.</p><p>Once you're set up, our team may spot something in your store that could be stronger, like product pages, branding or content, and offer a paid service for it. <b>You can say no.</b> It has no effect on your access or your matches.</p><div class="row">${["Supplier profiles","Wholesale sheets","Sample products","MOQ","Line sheets","Price lists","Product spec sheets","Lead times & shipping terms"].map(x=>`<span class="pill">${x}</span>`).join("")}</div></div>
  </div></div></section>

  <section class="band soft" id="faq"><div class="band-in">
    <div class="sec-head"><span class="eyebrow">Questions</span><h2 class="h-sec">Before you apply.</h2></div>
    <div class="faq">${[["Is MerchantBridge really free?","Yes. Joining, getting matched and applying to opportunities costs nothing, and that won't change. We earn from optional services some members choose to buy."],["Do you take a cut of the deals I close?","No. You apply directly with the source and every deal is yours. We don't sit between you and the buyer."],["How do you decide what I see?","We match on your product category, monthly capacity, the markets you ship to and whether you can do custom branding or packaging. A complete profile gets more matches."],["How long does review take?","Usually within 48 hours. If something's missing, we'll tell you exactly what to change so you can resubmit quickly."],["I don't use Shopify. Can I still join?","Yes. WooCommerce, BigCommerce, Magento, Wix, Etsy and standalone sites are all welcome. You just add your details by hand."],["What's a supplier profile, and do I need one?","It's a short document buyers use to judge whether you're a fit: your products, capacity, minimums and terms. It helps a lot, and if you don't have one we'll connect you to someone that will prepare it for you at no cost."],["Which markets do you cover?","Most opportunities are for brands shipping to the US, Canada and Australia, with more in the UK and Europe. Tell us where you ship and we'll match accordingly."]].map(([q,a],i)=>`<details ${i===0?"open":""}><summary>${q}</summary><p>${a}</p></details>`).join("")}</div>
  </div></section>

  <section class="band cta"><div class="band-in"><div class="cta-in"><div><h2 class="h-sec">Your next wholesale account might already be looking for you.</h2><p>Join in about five minutes. We'll review your profile within 48 hours.</p></div><button class="btn lg" onclick="startApply()">Join MerchantBridge</button></div></div></section>

  ${siteFooter()}
  </div>`;
}

/* ============ SITE PAGES: routing ============ */
const ROUTES=["about","contact","privacy","terms","cookies","journal"];
const PAGE_NAMES={about:"What we do",contact:"Contact",privacy:"Privacy Policy",terms:"Terms of Service",cookies:"Cookie Policy",journal:"Journal"};
function routeFromHash(){let h="";try{h=decodeURIComponent((location.hash||"").slice(1))}catch(e){}if(ROUTES.includes(h)||/^post-[a-z0-9-]+$/.test(h)){S.page=h;S.mode="site";return true}S.page=null;return false}
addEventListener("hashchange",()=>{const was=S.page;routeFromHash();if(S.page!==was&&S.ready){closeModal();render(true);scrollTo(0,0)}});
function openPage(p){S.page=p;S.mode="site";S.ui.bell=false;S.justSubmitted=false;if(p==="contact")S.ui.contactSent=null;closeModal();try{if(location.hash.slice(1)!==p)history.pushState(null,"","#"+p)}catch(e){}render(true);scrollTo(0,0)}
function clearPage(){if(!S.page)return;S.page=null;try{history.pushState(null,"",location.pathname+location.search)}catch(e){}}
function goHome(){if(!S.ready)return;clearPage();S.mode="site";S.draft={};S.justSubmitted=false;S.ui.bell=false;render(true);scrollTo(0,0)}
function pageTitle(){if(!showSite()||!S.page)return"MerchantBridge | Opportunities for independent e-commerce brands";if(S.page.startsWith("post-")){const p=vals(S.posts).find(x=>x.slug===S.page.slice(5));return(p?p.title:"Journal")+" | MerchantBridge"}return(PAGE_NAMES[S.page]||"MerchantBridge")+" | MerchantBridge"}

/* ============ SITE PAGES: tiny formatter (escaped first, so safe) ============ */
function hslug(t){return"h-"+String(t).toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")}
function mdInline(t){return esc(t).replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/(^|[^*])\*([^*\n]+)\*/g,"$1<em>$2</em>").replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+|#[a-z0-9-]+)\)/g,(m,a,h)=>h[0]==="#"?`<a href="${h}" onclick="openPage('${h.slice(1)}');return false">${a}</a>`:`<a href="${h}" target="_blank" rel="noopener">${a}</a>`)}
function md(src){
  const lines=String(src||"").replace(/\r/g,"").split("\n");let out="",list=null,para=[];
  const fp=()=>{if(para.length){out+=`<p>${mdInline(para.join(" "))}</p>`;para=[]}};
  const fl=()=>{if(list){out+=`<${list.t}>${list.items.map(i=>`<li>${mdInline(i)}</li>`).join("")}</${list.t}>`;list=null}};
  for(const raw of lines){const t=raw.trim();let m;
    if(!t){fp();fl();continue}
    if((m=t.match(/^(#{2,3})\s+(.*)/))){fp();fl();const n=m[1].length;out+=`<h${n} id="${hslug(m[2])}">${mdInline(m[2])}</h${n}>`;continue}
    if((m=t.match(/^[-*]\s+(.*)/))){fp();if(!list||list.t!=="ul"){fl();list={t:"ul",items:[]}}list.items.push(m[1]);continue}
    if((m=t.match(/^\d+[.)]\s+(.*)/))){fp();if(!list||list.t!=="ol"){fl();list={t:"ol",items:[]}}list.items.push(m[1]);continue}
    if((m=t.match(/^>\s?(.*)/))){fp();fl();out+=`<blockquote>${mdInline(m[1])}</blockquote>`;continue}
    fl();para.push(t)}
  fp();fl();return out}
function tocOf(src){return String(src||"").split("\n").map(l=>l.trim().match(/^##\s+(.*)/)).filter(Boolean).map(m=>[hslug(m[1]),m[1]])}
function readMins(t){return Math.max(1,Math.round(String(t||"").split(/\s+/).filter(Boolean).length/220))}

/* ============ SITE PAGES: shared pieces ============ */
function pageHero(eyebrow,title,lede,extra=""){return `<section class="band page-hero"><div class="band-in"><span class="eyebrow">${eyebrow}</span><h1>${title}</h1>${lede?`<p class="lede">${lede}</p>`:""}${extra}</div></section>`}
function ctaBand(){return `<section class="band cta"><div class="band-in"><div class="cta-in"><div><h2 class="h-sec">Your next wholesale account might already be looking for you.</h2><p>Join in about five minutes. We'll review your profile within 48 hours.</p></div><button class="btn lg" onclick="startApply()">Join MerchantBridge</button></div></div></section>`}
function publishedPosts(){return vals(S.posts).filter(p=>p.published).sort((a,b)=>ts(b.publishedAt)-ts(a.publishedAt))}
function siteFooter(){
  const L=(p,l)=>`<a href="#${p}" onclick="openPage('${p}');return false">${l}</a>`;
  const J=(id,l)=>`<a href="#" onclick="jump('${id}');return false">${l}</a>`;
  const showJ=publishedPosts().length>0||S.canEdit;
  return `<footer class="site-foot"><div class="band-in" style="gap:28px"><div class="foot-grid">
    <div class="stack"><a class="brand" href="#" onclick="goHome();return false">${document.querySelector(".brand .logo")?.outerHTML||"MerchantBridge"}</a><p class="small muted" style="max-width:34ch">Wholesale, retail, gifting and sourcing opportunities for independent e-commerce brands.</p><p class="small muted">30 N Gould St, Suite #65570<br>Sheridan, WY 82801, United States</p><p class="small"><span class="muted">+1 (314) 635-7489</span><br><span class="muted" style="user-select:all">support@demerchantbridge.com</span></p></div>
    <div><h4>Product</h4>${J("how","How it works")}${J("requests","Open requests")}${J("faq","FAQ")}${showJ?L("journal","Journal"):""}</div>
    <div><h4>Company</h4>${L("about","What we do")}${L("contact","Contact")}<a href="#contact" onclick="openPage('contact');setTimeout(()=>setTopic('buyer'),40);return false">For buyers</a></div>
    <div><h4>Legal</h4>${L("privacy","Privacy Policy")}${L("terms","Terms of Service")}${L("cookies","Cookie Policy")}</div>
  </div><p class="small faint">© ${new Date().getFullYear()} MerchantBridge. All rights reserved.</p></div></footer>`;
}
function subPage(){
  const p=S.page;let html;
  if(p==="about")html=aboutPage();
  else if(p==="contact")html=contactPage();
  else if(LEGAL[p])html=legalPage(p);
  else if(p==="journal")html=journalPage();
  else if(p.startsWith("post-"))html=postPage(p.slice(5));
  else html=notFoundPage();
  return `<div class="site">${html}${siteFooter()}</div>`;
}
function notFoundPage(){return pageHero("Not found","We couldn't find that page.","It may have moved, or the link may be wrong.",`<div class="row"><button class="btn primary" onclick="goHome()">Go to the homepage</button></div>`)}

/* ============ About ============ */
function aboutPage(){
  return pageHero("What we do","We find the buyers. You build the brand.","MerchantBridge is a free platform for independent e-commerce brands. We collect wholesale, retail, corporate gifting and sourcing opportunities, match them to the stores that fit, and help those stores get buyer-ready.",`<div class="row" style="gap:12px"><button class="btn primary lg" onclick="startApply()">Join MerchantBridge</button><button class="btn lg" onclick="openPage('contact')">Talk to us</button></div>`)+`
  <section class="band soft"><div class="band-in">
    <div class="sec-head"><span class="eyebrow">Three jobs, done for you</span><h2 class="h-sec">What MerchantBridge does.</h2></div>
    <div class="howgrid">${[["We find opportunities","Every week our team sources live requests from wholesale buyers, retailers, corporate gifting programs, hospitality groups, distributors and sourcing platforms, and checks each one is still current."],["We match them to you","A real person reviews every profile. After that, your feed only shows briefs that fit your category, capacity, shipping markets and customisation options."],["We get you ready","Wholesale sheets, merchant profiles, pitch decks, readiness checklists and help joining platforms like Faire. We guide you step by step."]].map(([h,p],i)=>`<div class="how"><span class="n">0${i+1}</span><h3>${h}</h3><p>${p}</p></div>`).join("")}</div>
  </div></section>
  <section class="band"><div class="band-in">
    <div class="sec-head"><span class="eyebrow">How we're different</span><h2 class="h-sec">Built around the brand, not the middleman.</h2></div>
    <div class="typegrid">${[["Free, for good","No fees to join, get matched or apply. That won't change."],["No cut of your deals","You apply directly with the source. What you earn is yours."],["Reviewed by people","A real person on our team reads every application and replies within 48 hours."],["Made for small brands","Shopify, WooCommerce, Etsy, Wix, your own site: if you sell online, you're welcome."]].map(([h,p])=>`<div class="t"><b>${h}</b><p>${p}</p></div>`).join("")}</div>
  </div></section>
  <section class="band soft"><div class="band-in"><div class="funded">
    <div class="sec-head"><span class="eyebrow">Who it's for</span><h2 class="h-sec">Independent brands ready for bigger buyers.</h2></div>
    <div class="body"><p>We work with product brands that sell online and want to grow through wholesale, retail, corporate gifting and partnerships, whether you've never pitched a buyer or you're adding your tenth stockist.</p>
      <div class="stack s6"><span class="flabel">Categories we match</span><div class="row">${CATEGORIES.filter(c=>c!=="Other").map(c=>`<span class="pill">${c}</span>`).join("")}<span class="pill">and more</span></div></div>
      <div class="stack s6"><span class="flabel">Markets we cover</span><div class="row">${["United States","Canada","Australia","United Kingdom","Europe"].map(c=>`<span class="pill">${c}</span>`).join("")}</div></div></div>
  </div></div></section>
  <section class="band"><div class="band-in"><div class="funded">
    <div class="sec-head"><span class="eyebrow">Who's behind it</span><h2 class="h-sec">Run by people who work with e-commerce stores every day.</h2></div>
    <div class="body"><p>MerchantBridge is run by a digital agency that offers <b>digital marketing services</b> to e-commerce stores. That's how we keep the platform free: some members choose to work with us on paid services, and everyone else keeps full access at no cost.</p><p>MerchantBridge, 30 N Gould St, Suite #65570, Sheridan, WY 82801, United States.</p><div class="row"><button class="btn" onclick="openPage('contact')">Contact the team</button></div></div>
  </div></div></section>`+ctaBand();
}

/* ============ Contact ============ */
const TOPICS={joining:"Joining MerchantBridge",brief:"A brief or opportunity",documents:"Help with documents",buyer:"I'm a buyer with a sourcing request",partnership:"Partnerships",press:"Press",other:"Something else"};
function setTopic(t){const el=document.getElementById("c-topic");if(el){el.value=t;el.closest("form")?.scrollIntoView({behavior:"smooth",block:"start"});setTimeout(()=>document.getElementById("c-name")?.focus(),300)}}
function contactPage(){
  const me=S.me||{};const sent=S.ui.contactSent;
  const form=sent!=null?`<div class="card stack" style="align-items:flex-start;gap:14px"><span class="ico ok">${I.check}</span><h2>Thanks${sent?", "+esc(sent):""}. Your message is with our team.</h2><p class="muted">We'll reply to the email you gave us. If it's urgent, you can also reach us at <span style="user-select:all">support@demerchantbridge.com</span>.</p><button class="btn" onclick="S.ui.contactSent=null;render(true)">Send another message</button></div>`:
  `<form id="cform" class="card stack" style="position:relative;gap:16px" onsubmit="submitContact(event)" novalidate>
    <h2>Send us a message</h2>
    <div class="formgrid">
      <div class="field"><label for="c-name">Your name</label><input id="c-name" type="text" autocomplete="name" value="${esc(me.fullName||S.meName||"")}"></div>
      <div class="field"><label for="c-email">Email</label><input id="c-email" type="email" autocomplete="email" value="${esc(me.email||"")}"></div>
      <div class="field"><label for="c-company">Business name <span class="faint">(optional)</span></label><input id="c-company" type="text" autocomplete="organization" value="${esc(me.businessName||"")}"></div>
      <div class="field"><label for="c-web">Website <span class="faint">(optional)</span></label><input id="c-web" type="text" inputmode="url" placeholder="yourbrand.com" value="${esc(me.storeUrl||"")}"></div>
      <div class="field full"><label for="c-topic">What's it about?</label><select id="c-topic">${Object.entries(TOPICS).map(([k,l])=>`<option value="${k}">${l}</option>`).join("")}</select></div>
      <div class="field full"><label for="c-msg">Message</label><textarea id="c-msg" style="min-height:150px" placeholder="Tell us a bit about what you need."></textarea></div>
    </div>
    <div aria-hidden="true" style="position:absolute;left:-9999px;top:0;width:1px;height:1px;overflow:hidden"><label for="c-hp">Leave this empty</label><input id="c-hp" type="text" tabindex="-1" autocomplete="off"></div>
    <p class="err" id="c-err" hidden></p>
    <div class="row between"><span class="small muted">See our <a href="#privacy" onclick="openPage('privacy');return false">Privacy Policy</a> for how we use your details.</span><button class="btn primary" id="c-send" type="submit">Send message</button></div>
  </form>`;
  return pageHero("Contact","Talk to the MerchantBridge team.","Questions about joining, a brief, or getting your documents ready? Send us a message and a real person on our team will get back to you.")+`
  <section class="band" style="padding-top:0"><div class="band-in"><div class="contact-grid">
    <div class="cinfo">
      <div class="card"><span class="ico">${I.mail}</span><div class="grow stack s6"><span class="small faint">Email</span><span class="val">support@demerchantbridge.com</span><button class="btn sm" style="align-self:flex-start" onclick="copyText('support@demerchantbridge.com')">Copy email</button></div></div>
      <div class="card"><span class="ico">${I.phone}</span><div class="grow stack s6"><span class="small faint">Phone</span><span class="val">+1 (314) 635-7489</span><button class="btn sm" style="align-self:flex-start" onclick="copyText('+13146357489')">Copy number</button></div></div>
      <div class="card"><span class="ico">${I.pin}</span><div class="grow stack s6"><span class="small faint">Mailing address</span><span style="font-weight:600">30 N Gould St, Suite #65570<br>Sheridan, WY 82801<br>United States</span></div></div>
      <div class="card buyer-card stack" style="gap:10px"><span class="eyebrow" style="color:#FF7A3D">For buyers and partners</span><h3 style="font-size:20px">Sourcing products for a program?</h3><p class="small">Running a wholesale, retail, corporate gifting or hospitality program? Tell us what you need and we'll share it with independent brands that fit. It's free.</p><button class="btn primary sm" style="align-self:flex-start" onclick="setTopic('buyer')">Share a sourcing request</button></div>
    </div>
    ${form}
  </div></div></section>`;
}
async function submitContact(e){
  e.preventDefault();
  const g=id=>(document.getElementById(id)?.value||"").trim();
  const d={name:g("c-name"),email:g("c-email"),company:g("c-company"),website:g("c-web"),topic:g("c-topic"),message:g("c-msg")};
  const errEl=document.getElementById("c-err");errEl.hidden=true;
  if(g("c-hp")){S.ui.contactSent=d.name.split(" ")[0];render(true);return}
  if(!d.name||!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.email)||d.message.split(/\s+/).length<3){errEl.textContent="Add your name, a valid email and a short message so we can help.";errEl.hidden=false;return}
  const btn=document.getElementById("c-send");btn.disabled=true;btn.textContent="Sending…";
  try{if(!S.db)throw new Error("offline");await S.db.collection("contact").add({...d,status:"new",at:nowIso(),uid:S.uid||null});S.ui.contactSent=d.name.split(" ")[0];render(true);scrollTo({top:0})}
  catch(x){errEl.innerHTML='We couldn\'t send that from here. Please email us at <b style="user-select:all">support@demerchantbridge.com</b> instead.';errEl.hidden=false;btn.disabled=false;btn.textContent="Send message"}
}

/* ============ Legal ============ */
const LEGAL_CONTACT="Questions? Email support@demerchantbridge.com or write to MerchantBridge, 30 N Gould St, Suite #65570, Sheridan, WY 82801, United States.";
const LEGAL={
privacy:{title:"Privacy Policy",updated:"16 October 2026",intro:"How MerchantBridge collects, uses and protects your information, and the choices you have.",body:`## Who we are
MerchantBridge ("MerchantBridge", "we", "us") runs demerchantbridge.com, a free platform that matches independent e-commerce brands with wholesale, retail, corporate gifting and sourcing opportunities. Our mailing address is 30 N Gould St, Suite #65570, Sheridan, WY 82801, United States, and you can reach us at support@demerchantbridge.com.

## What we collect
**Information you give us** when you apply, build your profile or contact us:
- Your name, business name, email address and store website
- Details about your business: product category, description, target customers, average order value, order volume and revenue ranges, shipping markets, sales channels and whether you offer custom branding or packaging
- Documents you upload, such as a supplier profile, wholesale sheet or pitch deck
- Applications you log, notes you add to them, testimonials or stories you submit, and messages you send our team

**Information from connected stores.** If you connect a Shopify store, we receive the store details you authorise, such as store name, address, product catalogue and order summaries. We only use this to review your profile and improve your matches.

**Information collected automatically.** When you use the site, our hosting and sign-in providers process technical data such as your IP address, browser type and device, and keep a sign-in session in your browser. See our [Cookie Policy](#cookies).

## How we use it
- To review your application and decide whether to approve your profile
- To match you with opportunities that fit your category, capacity, markets and customisation options
- To run your account: your feed, saved opportunities, application tracker and notifications
- To send you service emails, such as review decisions, new matches, weekly digests and replies to your messages
- To offer optional paid services when our team spots something that could help your store. You can say no, and it never affects your access
- To show your testimonial or story on our website, only after you submit it and our team approves it. We show your first name, last initial, store name and category
- To keep the platform secure, prevent abuse and meet legal obligations

## What we don't do
- We don't sell your personal information
- We don't share your profile with buyers. You apply directly with each opportunity's source and decide what to send them
- We don't take a cut of any deal you make

## Who we share it with
We share information only with service providers that help us run MerchantBridge, under agreements that limit how they use it:
- **Hosting, database, sign-in and file storage** (Supabase)
- **Email delivery**, to send the emails described above
- **Shopify**, only if you choose to connect your store
- **Google Fonts**, which delivers the typefaces on our pages and receives your IP address when it does

We may also disclose information if the law requires it, to protect our rights or our users, or as part of a merger or sale of our business, in which case this policy continues to apply.

## How long we keep it
We keep your account information while your account is active. If you ask us to delete your account, we delete or anonymise your personal information within 30 days, except where we must keep it to meet legal, tax or accounting obligations, or to resolve disputes. Approved testimonials are taken off the website whenever you ask.

## Your rights
Depending on where you live, including the EU, UK, California, Canada and Australia, you may have the right to:
- Access the personal information we hold about you and get a copy
- Correct information that's wrong (you can edit most of it yourself on your profile page)
- Ask us to delete your information
- Object to or restrict certain uses, and withdraw consent you've given
- Complain to your local data protection authority

To use any of these rights, email support@demerchantbridge.com from the address on your account. We'll respond within 30 days, and we won't treat you differently for using your rights.

## International transfers
We're based in the United States and our providers may process data in the US and other countries. Where the law requires it, we rely on safeguards such as standard contractual clauses for transfers out of the EU, UK, Canada or Australia.

## Security
We use encrypted connections, access rules that limit each merchant to their own data, and restricted team access. No system is perfectly secure, so please keep your email account safe: it's how you sign in.

## Children
MerchantBridge is for businesses. It's not meant for anyone under 18, and we don't knowingly collect information from children.

## Changes to this policy
If we make important changes, we'll update the date at the top and tell members by email or in the app before the changes take effect.

## Contact us
${LEGAL_CONTACT}`},
terms:{title:"Terms of Service",updated:"16 October 2026",intro:"The agreement between you and MerchantBridge when you use demerchantbridge.com. Please read it before you join.",body:`## Agreeing to these terms
These terms are an agreement between you and MerchantBridge ("MerchantBridge", "we", "us"). By creating an account or using demerchantbridge.com, you agree to them and to our [Privacy Policy](#privacy). If you use MerchantBridge for a business, you agree on its behalf.

## What MerchantBridge is
MerchantBridge curates wholesale, retail, corporate gifting, partnership and sourcing opportunities and shows them to approved merchants whose profile fits. Each opportunity links to its original source and you apply directly with that source. We aren't a party to any deal you make and we don't take a commission.

## Who can join
You must be at least 18, able to form a binding contract, and run or represent a real business. We review every application and may approve it, ask for changes or decline it at our discretion.

## Your account
- Give accurate, current information and keep your profile up to date
- Keep your email account secure. We sign you in with links sent to your email, and you're responsible for activity on your account
- Tell us straight away at support@demerchantbridge.com if you think someone else has used your account

## It's free
Joining, being matched and applying to opportunities is free. We may offer optional paid services, such as help with product pages, branding or content. Any paid service is agreed separately, with its own price and terms, before work starts. Saying no never affects your access or your matches.

## Opportunities and third parties
We check that opportunities appear current before they go live, but we don't control buyers, platforms or other third parties. We don't guarantee that any opportunity is accurate, still open, or will lead to a deal. Do your own checks before you share sensitive information, send samples or agree terms. Your dealings with any third party, including payment, delivery and disputes, are between you and them.

## Help with documents
When we help you prepare, or connect you with someone who prepares, documents such as supplier profiles, wholesale sheets, pitch decks or readiness checklists, you're responsible for checking that everything in them is accurate before you use them.

## Your content
You keep ownership of everything you submit, including your profile, documents, testimonials and messages. You give us a non-exclusive, worldwide, royalty-free licence to host, store, use and display it to run MerchantBridge, for example to review your profile, match you and support you.

If you submit a testimonial or story, you also allow us to publish it on our website and in our marketing, with your first name, last initial, store name and category, until you ask us to remove it. You confirm you have the right to share what you submit and that it's accurate and lawful.

## Acceptable use
Please don't:
- Give false information or pretend to be someone else
- Copy, scrape, resell or republish opportunities or other content from MerchantBridge
- Share your account with people outside your business
- Try to access other merchants' data, break our security or disrupt the service
- Use MerchantBridge for spam or anything unlawful

## Our content
The MerchantBridge name, logo and website, and the way we select and present opportunities, belong to us. You may use them only to use MerchantBridge as these terms allow.

## Closing or suspending accounts
You can close your account at any time by emailing support@demerchantbridge.com. We may suspend or close an account that breaks these terms, puts other users at risk, or that we're required to close by law. Where it's reasonable, we'll tell you why first.

## Disclaimers
MerchantBridge is provided "as is" and "as available". To the fullest extent the law allows, we make no warranties, express or implied, including about merchantability, fitness for a particular purpose, or that the service will be uninterrupted or error-free.

## Limitation of liability
To the fullest extent the law allows, MerchantBridge won't be liable for indirect, incidental, special or consequential losses, or for lost profits, revenue, data or business opportunities. Our total liability for any claim relating to MerchantBridge is limited to the greater of what you paid us in the 12 months before the claim, or US $100. Some places don't allow these limits, so they may not all apply to you.

## Indemnity
You agree to cover MerchantBridge for claims, losses and costs (including reasonable legal fees) that come from your content, your dealings with third parties, or your breach of these terms.

## Governing law
These terms are governed by the laws of the State of Wyoming, United States, without regard to its conflict-of-law rules. Disputes will be handled in the state or federal courts located in Wyoming, unless the law where you live gives you the right to bring a claim locally.

## Changes to these terms
We may update these terms. If a change is important, we'll tell members by email or in the app before it takes effect. Using MerchantBridge after that means you accept the updated terms.

## Contact us
${LEGAL_CONTACT}`},
cookies:{title:"Cookie Policy",updated:"16 October 2026",intro:"The small files and browser storage MerchantBridge uses, and why.",body:`## What cookies are
Cookies are small text files a website saves in your browser. Similar tools, such as local storage, do the same job. In this policy we call all of them "cookies".

## What we use
**Essential cookies only.** We use them to:
- Keep you signed in after you open your sign-in link
- Remember what you were doing before signing in, such as starting an application
- Keep the site secure and working properly

These are strictly necessary for the service, so they don't need your consent.

**No advertising or tracking cookies.** We don't use analytics, advertising or social media tracking cookies. If that changes, we'll update this page first and ask for your consent where the law requires it.

## Third parties
- **Supabase** runs our sign-in and database, and keeps your sign-in session in your browser
- **Google Fonts** delivers the typefaces on our pages. It doesn't set cookies, but Google receives your IP address to send the fonts

## Controlling cookies
You can clear or block cookies and site storage in your browser settings. If you block essential storage, you won't be able to stay signed in.

## More about your privacy
Our [Privacy Policy](#privacy) explains how we use your information and the rights you have.

## Contact us
${LEGAL_CONTACT}`}
};
function legalPage(k){
  const L=LEGAL[k];const heads=tocOf(L.body);
  return pageHero("Legal",L.title,L.intro,`<span class="pill" style="align-self:flex-start">Last updated ${L.updated}</span>`)+`
  <section class="band" style="padding-top:0"><div class="band-in"><div class="legal">
    <nav class="toc" aria-label="On this page"><span>On this page</span>${heads.map(([id,t])=>`<button onclick="document.getElementById('${id}')?.scrollIntoView({behavior:'smooth'})">${esc(t)}</button>`).join("")}</nav>
    <article class="prose">${md(L.body)}</article>
  </div></div></section>`;
}
function legalModal(k){const L=LEGAL[k];openModal(`<div class="modal-head"><div><span class="eyebrow">Last updated ${L.updated}</span><h2>${L.title}</h2></div>${closeBtn()}</div><div class="prose" style="max-height:60vh;overflow:auto;max-width:none">${md(L.body)}</div><div class="row" style="justify-content:flex-end"><button class="btn primary" onclick="closeModal()">Done</button></div>`,true)}

/* ============ Journal ============ */
const JOURNAL_CATS=["Wholesale","Retail","Corporate gifting","Getting buyer-ready","Platform guides","Pricing & MOQ","News"];
function postCard(p,lead){return `<a class="post-card ${lead?"lead":""}" href="#post-${esc(p.slug)}" onclick="openPage('post-${esc(p.slug)}');return false"><span class="pill accent" style="align-self:flex-start">${esc(p.category||"Journal")}</span><h3>${esc(p.title)}</h3>${p.excerpt?`<p>${esc(p.excerpt)}</p>`:""}<span class="meta">${fmtDate(p.publishedAt)} · ${readMins(p.body)} min read</span></a>`}
function journalPage(){
  const all=publishedPosts();const cat=S.ui.jCat||"";const list=cat?all.filter(p=>p.category===cat):all;
  const cats=[...new Set(all.map(p=>p.category).filter(Boolean))];
  return pageHero("Journal","Guides for brands going wholesale.","Practical, plain-English guides on wholesale, retail, corporate gifting and getting buyer-ready.")+`
  <section class="band" style="padding-top:0"><div class="band-in">
    ${cats.length>1?`<div class="chips" role="group" aria-label="Filter by topic"><button aria-pressed="${!cat}" onclick="S.ui.jCat='';render(true)">All</button>${cats.map(c=>`<button aria-pressed="${cat===c}" onclick="S.ui.jCat=${esc(JSON.stringify(c))};render(true)">${esc(c)}</button>`).join("")}</div>`:""}
    ${list.length?`<div class="posts">${list.map((p,i)=>postCard(p,i===0&&!cat&&list.length>2)).join("")}</div>`:`<div class="empty"><span class="ico">${I.doc}</span><h3>Our first guides are on the way</h3><p class="small">We're writing practical guides on wholesale pricing, line sheets, MOQs and getting onto platforms like Faire.</p><button class="btn primary sm" onclick="startApply()">Join MerchantBridge</button></div>`}
  </div></section>`+ctaBand();
}
function postPage(slug){
  const p=vals(S.posts).find(x=>x.slug===slug&&(x.published||S.canEdit));
  if(!p)return S.postsLoaded?notFoundPage():`<div class="loading"><p>Loading article…</p></div>`;
  const more=publishedPosts().filter(x=>x.id!==p.id).slice(0,3);
  return `<section class="band page-hero"><div class="band-in"><div class="post-head">
    <div class="crumbs"><button onclick="openPage('journal')">Journal</button><span>/</span><span>${esc(p.category||"Article")}</span></div>
    ${p.published?"":'<span class="pill warn" style="align-self:flex-start">Draft · only the team can see this</span>'}
    <h1>${esc(p.title)}</h1>${p.excerpt?`<p class="lede">${esc(p.excerpt)}</p>`:""}
    <span class="small muted">By ${esc(p.author||"MerchantBridge team")} · ${fmtDate(p.publishedAt||p.updatedAt)} · ${readMins(p.body)} min read</span>
  </div></div></section>
  <section class="band" style="padding-top:0"><div class="band-in"><article class="post-body prose">${md(p.body)}</article></div></section>
  ${more.length?`<section class="band soft"><div class="band-in"><div class="sec-head split"><h2 class="h-sec" style="font-size:clamp(26px,3vw,34px)">Keep reading</h2><button class="btn" onclick="openPage('journal')">All articles</button></div><div class="posts">${more.map(x=>postCard(x)).join("")}</div></div></section>`:""}`+ctaBand();
}

/* ============ TEAM: Journal editor ============ */
function slugify(t){return String(t||"").toLowerCase().replace(/&/g," and ").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,70).replace(/-$/,"")}
function tJournal(){
  const list=vals(S.posts).sort((a,b)=>ts(b.updatedAt||b.createdAt)-ts(a.updatedAt||a.createdAt));
  return `<div class="page-head"><div><h1>Journal</h1><p class="muted">Write guides and news for the website. Published posts show on the Journal page and in the footer.</p></div><button class="btn primary" onclick="postForm()">${I.plus} Write a post</button></div>
  ${list.length?`<div class="tablewrap"><table><thead><tr><th>Title</th><th>Topic</th><th>Status</th><th>Updated</th><th></th></tr></thead><tbody>${list.map(p=>`<tr><td style="min-width:240px"><b>${esc(p.title)}</b><div class="sub">#post-${esc(p.slug)} · ${readMins(p.body)} min read</div></td><td>${esc(p.category||"—")}</td><td>${p.published?'<span class="pill ok">Published</span>':'<span class="pill">Draft</span>'}</td><td class="num">${fmtDate(p.updatedAt||p.createdAt)}</td><td><div class="row" style="flex-wrap:nowrap"><button class="btn sm" onclick="postForm('${p.id}')">Edit</button><button class="btn sm" onclick="openPage('post-${esc(p.slug)}')">View</button><button class="btn sm ${p.published?"":"primary"}" onclick="togglePost('${p.id}')">${p.published?"Unpublish":"Publish"}</button><button class="btn ghost sm danger" onclick="confirmDelete('posts/${p.id}','this post')">Delete</button></div></td></tr>`).join("")}</tbody></table></div>`:`<div class="empty"><span class="ico">${I.doc}</span><h3>No posts yet</h3><p class="small">Guides on wholesale pricing, line sheets, MOQs or joining Faire are a great start.</p><button class="btn primary sm" onclick="postForm()">Write the first post</button></div>`}`;
}
function postForm(id){
  const p=id?S.posts[id]:{category:JOURNAL_CATS[0],author:S.meName||"MerchantBridge team",published:false};
  openModal(`<div class="modal-head"><div><span class="eyebrow">${id?"Edit post":"New post"}</span><h2>${id?esc(p.title):"Write a post"}</h2></div>${closeBtn()}</div>
  <div class="formgrid">
    <div class="field full"><label for="pf-title">Title</label><input id="pf-title" type="text" value="${esc(p.title||"")}" placeholder="e.g. How to build a wholesale sheet buyers actually read"></div>
    <div class="field"><label for="pf-cat">Topic</label><select id="pf-cat">${JOURNAL_CATS.map(c=>`<option ${p.category===c?"selected":""}>${c}</option>`).join("")}</select></div>
    <div class="field"><label for="pf-author">Author</label><input id="pf-author" type="text" value="${esc(p.author||"")}"></div>
    <div class="field full"><label for="pf-ex">Short summary</label><textarea id="pf-ex" style="min-height:70px" maxlength="240" placeholder="One or two sentences shown on the Journal page.">${esc(p.excerpt||"")}</textarea></div>
    <div class="field full"><label for="pf-body">Article</label><textarea id="pf-body" style="min-height:360px;font-size:15px;line-height:1.6">${esc(p.body||"")}</textarea><span class="hint">Formatting: <b>## Heading</b> · <b>### Smaller heading</b> · <b>- bullet</b> · <b>1. numbered</b> · <b>**bold**</b> · <b>*italic*</b> · <b>[link text](https://…)</b> · <b>&gt; quote</b>. Leave a blank line between paragraphs.</span></div>
    <div class="field full"><label class="toggle"><input type="checkbox" id="pf-pub" ${p.published?"checked":""}> Published (visible on the website)</label></div>
  </div>
  <div class="row between"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="savePost(${id?`'${id}'`:"null"})">${id?"Save changes":"Save post"}</button></div>`,true);
}
async function savePost(id){
  const g=x=>document.getElementById(x).value.trim();
  const d={title:g("pf-title"),category:g("pf-cat"),author:g("pf-author"),excerpt:g("pf-ex"),body:document.getElementById("pf-body").value.trim(),published:document.getElementById("pf-pub").checked,updatedAt:nowIso()};
  if(!d.title||!d.body){toast("Add a title and the article text");return}
  const old=id?S.posts[id]:null;const nid=id||gid();
  let slug=old?.slug||slugify(d.title)||"post";
  if(vals(S.posts).some(x=>x.id!==nid&&x.slug===slug))slug=slug+"-"+nid.slice(-4);
  d.slug=slug;if(d.published&&!old?.publishedAt)d.publishedAt=nowIso();
  if(old)await updDoc("posts/"+nid,d);else await setDoc("posts/"+nid,{...d,createdAt:nowIso(),addedBy:S.uid});
  audit(`${old?"Edited":"Wrote"} journal post "${d.title}"${d.published?" (published)":""}`);closeModal();toast(d.published?"Published to the Journal":"Saved as draft");
}
async function togglePost(id){const p=S.posts[id];const pub=!p.published;await updDoc("posts/"+id,{published:pub,updatedAt:nowIso(),...(pub&&!p.publishedAt?{publishedAt:nowIso()}:{})});audit(`${pub?"Published":"Unpublished"} journal post "${p.title}"`);toast(pub?"Published":"Moved to drafts")}
function confirmDelete(path,label){openModal(`<div class="modal-head"><h2>Delete ${esc(label)}?</h2>${closeBtn()}</div><p class="muted">This can't be undone.</p><div class="row between"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn danger" onclick="delDoc('${path}').then(()=>{audit('Deleted ${esc(label)}');closeModal();toast('Deleted')})">Delete</button></div>`)}

/* ============ TEAM: Contact inbox ============ */
function safeUrl(u){u=String(u||"").trim();if(!/^https?:\/\//i.test(u))u="https://"+u;return /^https?:\/\/[^\s"'<>]+$/i.test(u)?u:"#"}
function tInbox(){
  const tab=S.ui.inboxTab||"new";const all=vals(S.contact).sort((a,b)=>ts(b.at)-ts(a.at));const st=c=>c.status||"new";
  const list=tab==="all"?all:all.filter(c=>st(c)===tab);
  return `<div class="page-head"><div><h1>Contact inbox</h1><p class="muted">Messages from the Contact page. Reply from your email, then mark them handled.</p></div></div>
  <div class="tabs" role="tablist">${[["new","New"],["handled","Handled"],["all","All"]].map(([k,l])=>`<button role="tab" aria-selected="${tab===k}" onclick="S.ui.inboxTab='${k}';render(true)">${l} <span class="faint num">${k==="all"?all.length:all.filter(c=>st(c)===k).length}</span></button>`).join("")}</div>
  ${list.length?`<div class="stack">${list.map(c=>`<article class="card stack"><div class="row between"><div class="row"><span class="pill ${c.topic==="buyer"?"info":"accent"}">${esc(TOPICS[c.topic]||"General")}</span>${st(c)==="new"?'<span class="pill warn">New</span>':'<span class="pill ok">Handled</span>'}</div><span class="small faint">${ago(c.at)}</span></div>
  <div><h3>${esc(c.name)}${c.company?` <span class="faint small">· ${esc(c.company)}</span>`:""}</h3><span class="small muted" style="user-select:all">${esc(c.email)}</span>${c.website?` · <a class="small" href="${esc(safeUrl(c.website))}" target="_blank" rel="noopener">${esc(c.website)}</a>`:""}</div>
  <p style="white-space:pre-wrap">${esc(c.message)}</p>
  <div class="row"><button class="btn sm" onclick="copyText(${esc(JSON.stringify(c.email||""))})">Copy email</button>${st(c)==="new"?`<button class="btn sm primary" onclick="updDoc('contact/${c.id}',{status:'handled',handledBy:S.uid,handledAt:nowIso()}).then(()=>toast('Marked handled'))">Mark handled</button>`:`<button class="btn sm" onclick="updDoc('contact/${c.id}',{status:'new'}).then(()=>toast('Moved back to New'))">Mark as new</button>`}<button class="btn ghost sm danger" onclick="confirmDelete('contact/${c.id}','this message')">Delete</button></div></article>`).join("")}</div>`:`<div class="empty"><span class="ico">${I.mail}</span><h3>${tab==="new"?"No new messages":"Nothing here yet"}</h3><p class="small">Messages people send from the Contact page land here.</p></div>`}`;
}

/* ============ modal ============ */
function openModal(html,wide){document.getElementById("modal").innerHTML=`<div class="overlay" onclick="if(event.target===this)closeModal()"><div class="modal ${wide?"wide":""}" role="dialog" aria-modal="true">${html}</div></div>`;setTimeout(()=>document.querySelector("#modal input,#modal textarea,#modal select")?.focus(),30)}
function closeModal(){document.getElementById("modal").innerHTML="";if(pendingRender){pendingRender=false;render()}}
const closeBtn=()=>`<button class="iconbtn" aria-label="Close" onclick="closeModal()">${I.x}</button>`;
document.addEventListener("keydown",e=>{if(e.key==="Escape"){if(document.getElementById("modal").innerHTML)closeModal();else if(S.ui.bell){S.ui.bell=false;renderTop()}}});

/* ============ TEAM SIDE ============ */
function allM(){return vals(S.merchants)}
function teamShell(){
  const role=myRole();const pages=ROLE_PAGES[role]||[];if(!pages.includes(S.teamView))S.teamView=pages[0];
  const pend=allM().filter(m=>m.status==="pending").length;
  const labels={overview:"Overview",queue:"Review queue",merchants:"Merchants",opps:"Opportunities",sourcing:"Sourcing tracker",upsell:"Upsell pipeline",library:"Testimonials",journal:"Journal",inbox:"Contact inbox",outbox:"Email outbox",settings:"Settings"};
  const counts={queue:pend||"",merchants:allM().length||"",opps:vals(S.opps).filter(o=>oppState(o)!=="archived").length||"",outbox:allEmails().filter(e=>!e.sent).length||"",inbox:vals(S.contact).filter(c=>(c.status||"new")==="new").length||""};
  const views={overview:tOverview,queue:tQueue,merchants:tMerchants,opps:tOpps,sourcing:tSourcing,upsell:tUpsell,library:tLibrary,outbox:tOutbox,settings:tSettings,journal:tJournal,inbox:tInbox};
  return `<div class="shell"><nav class="nav" aria-label="Team"><div class="label">${ROLES[role]} workspace</div>${pages.map(k=>`<button aria-current="${S.teamView===k?"page":"false"}" onclick="go(null,'${k}')">${labels[k]}${counts[k]?`<span class="count num">${counts[k]}</span>`:""}</button>`).join("")}</nav><main>${views[S.teamView]()}</main></div>`;
}
function thisWeekOpps(){const ws=weekStart().getTime();return vals(S.opps).filter(o=>ts(o.createdAt)>=ws)}
function allApps(){return allM().flatMap(m=>vals(m.applications).map(a=>({...a,merchant:m})))}
function allEmails(){return allM().flatMap(m=>vals(m.emails).map(e=>({...e,merchant:m}))).sort((a,b)=>ts(b.at)-ts(a.at))}
function allTestimonials(){return allM().flatMap(m=>vals(m.testimonials).map(t=>({...t,merchant:m}))).sort((a,b)=>ts(b.at)-ts(a.at))}
function upsellOf(mid){return S.notes[mid]?.upsell||null}
function tOverview(){
  const ms=allM();const ws=weekStart().getTime(),mst=monthStart().getTime();const apps=allApps();const st=settings();
  const live=vals(S.opps).filter(o=>oppState(o)!=="archived");
  const stats=[["Merchants",ms.length],["New this week",ms.filter(m=>ts(m.createdAt)>=ws).length],["Pending review",ms.filter(m=>m.status==="pending").length],["Live opportunities",live.length],["Applications this week",apps.filter(a=>ts(a.appliedAt)>=ws).length],["Deals closed this month",apps.filter(a=>a.status==="Deal closed"&&ts(a.updatedAt)>=mst).length]];
  const actions=[];
  ms.filter(m=>m.status==="pending").sort((a,b)=>ts(a.submittedAt)-ts(b.submittedAt)).forEach(m=>actions.push({pri:ts(m.submittedAt),ic:m.resubmission?"info":"warn",text:`${m.resubmission?"Resubmission":"New profile"}: ${m.businessName}`,sub:`Waiting ${waitText(m.submittedAt)}`,act:`openMerchant('${m.id}')`,btn:"Review"}));
  live.filter(o=>oppState(o)==="expiring").forEach(o=>actions.push({pri:oppEnd(o),ic:"bad",text:`Expiring: ${o.title}`,sub:`Closes ${fmtDate(new Date(oppEnd(o)).toISOString())}`,act:`oppForm('${o.id}')`,btn:"Edit"}));
  ms.filter(m=>m.status==="approved"&&Date.now()-ts(m.lastSeen)>14*DAY).forEach(m=>actions.push({pri:ts(m.lastSeen)+1e13,ic:"",text:`Going cold: ${m.businessName}`,sub:`Last seen ${ago(m.lastSeen)}`,act:`msgModal(['${m.id}'])`,btn:"Message"}));
  ms.filter(m=>m.keyChange&&!m.keyChange.seen).forEach(m=>actions.push({pri:ts(m.keyChange.at)+2e13,ic:"info",text:`Profile updated: ${m.businessName}`,sub:`Changed ${m.keyChange.fields.join(", ")} — check matching`,act:`openMerchant('${m.id}')`,btn:"Check"}));
  const wk=thisWeekOpps().length,target=st.weeklyTarget||50,pct=Math.min(100,Math.round(wk/target*100));
  const dayOfWeek=((new Date().getDay()+6)%7)+1;const expected=Math.round(target*dayOfWeek/7);const behind=wk<expected;
  const pipe=ms.filter(m=>upsellOf(m.id)?.flag&&upsellOf(m.id)?.stage!=="Completed");
  return `<div class="page-head"><div><span class="eyebrow">${new Date().toLocaleDateString(undefined,{weekday:"long",day:"numeric",month:"long"})}</span><h1>Team overview</h1></div><div class="row"><button class="btn primary" onclick="oppForm()">${I.plus} Add opportunity</button></div></div>
  ${ms.length||vals(S.opps).length?"":`<div class="notice accent row between"><span><b>Nothing here yet.</b> Merchants appear as soon as they apply. Want to try every screen first? Load clearly-labelled sample data, then clear it in one click.</span><button class="btn sm" onclick="loadSample()">Load sample data</button></div>`}
  <section class="grid g6">${stats.map(([k,v])=>`<div class="card tight stat"><span class="v num">${v}</span><span class="k">${k}</span></div>`).join("")}</section>
  <div class="grid g2" style="grid-template-columns:minmax(0,1.2fr) minmax(0,.8fr)">
   <section class="card"><div class="card-head"><h3>Needs attention</h3><span class="small faint num">${actions.length} item${actions.length===1?"":"s"}</span></div>${actions.length?actions.sort((a,b)=>a.pri-b.pri).slice(0,10).map(a=>`<div class="li"><span class="ico ${a.ic}">${I.clock}</span><div class="grow"><p style="font-weight:600">${esc(a.text)}</p><span class="small faint">${esc(a.sub)}</span></div><button class="btn sm" onclick="${a.act}">${a.btn}</button></div>`).join(""):'<p class="muted small">All clear. Nothing is waiting on the team.</p>'}</section>
   <div class="stack" style="gap:16px">
    <section class="card"><div class="card-head"><h3>Weekly sourcing target</h3><span class="pill ${behind?"warn":"ok"}">${behind?"Behind pace":"On pace"}</span></div><div class="row between" style="margin-bottom:8px"><span class="stat"><span class="v num">${wk}<span class="faint" style="font-size:18px"> / ${target}</span></span></span><span class="small muted num">Pace for today: ${expected}</span></div><div class="bar ${behind?"warn":"ok"}"><i style="width:${pct}%"></i></div><p class="small muted" style="margin-top:8px">Resets every Monday.</p></section>
    <section class="card"><div class="card-head"><h3>Upsell pipeline</h3><button class="btn ghost sm" onclick="go(null,'upsell')">Open</button></div>${pipe.length?pipe.slice(0,5).map(m=>{const u=upsellOf(m.id);return `<div class="li"><div class="grow"><p style="font-weight:600">${esc(m.businessName)}</p><span class="small faint">${esc(u.service||"Service not chosen")}${u.value?" · $"+esc(u.value):""}</span></div><span class="pill info">${esc(u.stage||"Not contacted")}</span></div>`}).join(""):'<p class="muted small">Flag a merchant for upsell from their profile to start the pipeline.</p>'}</section>
   </div></div>
  <section class="card"><div class="card-head"><h3>Recent activity</h3></div>${activityFeed().slice(0,14).map(a=>`<div class="li"><span class="ico ${a.ic}">${a.icon}</span><div class="grow"><p class="small">${a.text}</p><span class="small faint">${ago(a.at)}</span></div></div>`).join("")||'<p class="muted small">Signups, applications and closed deals will stream in here.</p>'}</section>`;
}
function activityFeed(){const out=[];allM().forEach(m=>{const n=`<b>${esc(m.businessName||"A merchant")}</b>`;out.push({at:m.createdAt,text:`${n} applied to join`,ic:"",icon:I.user});if(m.resubmission&&m.submittedAt!==m.createdAt)out.push({at:m.submittedAt,text:`${n} resubmitted their profile`,ic:"info",icon:I.doc});vals(m.applications).forEach(a=>{out.push({at:a.appliedAt,text:`${n} applied for "${esc(a.title)}"`,ic:"info",icon:I.check});if(a.status==="Deal closed")out.push({at:a.updatedAt,text:`${n} closed a deal on "${esc(a.title)}"`,ic:"ok",icon:I.star})});vals(m.testimonials).forEach(t=>out.push({at:t.at,text:`${n} shared a testimonial`,ic:"ok",icon:I.msg}))});vals(S.opps).forEach(o=>out.push({at:o.createdAt,text:`New opportunity added: "${esc(o.title)}"`,ic:"",icon:I.bolt}));return out.filter(a=>a.at).sort((a,b)=>ts(b.at)-ts(a.at))}

/* review queue */
function tQueue(){
  const q=allM().filter(m=>m.status==="pending").sort((a,b)=>ts(a.submittedAt)-ts(b.submittedAt));
  return `<div class="page-head"><div><h1>Profile review queue</h1><p class="muted">Oldest first, so nobody waits more than 48 hours.</p></div></div>
  ${q.length?q.map(m=>`<article class="card stack"><div class="row between"><div class="row"><h3>${esc(m.businessName)}</h3><span class="faint small">${esc(m.fullName)}</span>${m.resubmission?'<span class="pill info">Resubmission</span>':'<span class="pill">First review</span>'}${m.demo?'<span class="pill demo">Sample</span>':""}</div><span class="pill ${(Date.now()-ts(m.submittedAt))>48*36e5?"bad":"warn"}">${I.clock} Waiting ${waitText(m.submittedAt)}</span></div>
  <div class="grid g3 small"><div><span class="faint">Category</span><br><b>${esc(m.category)}</b></div><div><span class="faint">Store</span><br><b style="overflow-wrap:anywhere">${esc(m.platform||"")} · ${esc(m.storeUrl||"—")}</b></div><div><span class="faint">Revenue / orders</span><br><b>${esc(m.revenue||"—")} · ${esc(m.orderVolume||"—")}</b></div><div><span class="faint">Ships to</span><br><b>${esc((m.markets||[]).join(", ")||"—")}</b></div><div><span class="faint">Custom branding</span><br><b>${m.customBranding===true?"Yes":m.customBranding===false?"No":"—"}</b></div><div><span class="faint">Supplier doc</span><br><b>${docStatus(m.supplierDoc?.status)}</b></div></div>
  ${m.description?`<p class="small muted">${esc(m.description)}</p>`:""}
  <div class="row"><button class="btn primary" onclick="approve(['${m.id}'])">${I.check} Approve</button><button class="btn" onclick="feedbackModal('${m.id}','resubmit')">Request changes</button><button class="btn danger" onclick="feedbackModal('${m.id}','rejected')">Reject</button><button class="btn ghost" onclick="openMerchant('${m.id}')">Full profile</button></div></article>`).join(""):`<div class="empty"><span class="ico ok">${I.check}</span><h3>Queue is empty</h3><p class="small">New applications land here the moment they're submitted.</p></div>`}`;
}
async function approve(ids){for(const id of ids){const m=S.merchants[id];if(!m||m.status==="approved")continue;await updDoc("merchants/"+id,{status:"approved",feedback:"",reviewedAt:nowIso(),reviewedBy:S.uid});await notifyMerchant(id,"Your profile is approved. Your opportunity feed is live!","ok");if(settings().notify.statusEmail)await queueEmail(id,"approved");audit(`Approved ${m.businessName}`)}toast(ids.length>1?`Approved ${ids.length} merchants`:"Approved — welcome email queued");S.ui.selected={};render()}
function feedbackModal(id,kind){const m=S.merchants[id];const rej=kind==="rejected";openModal(`<div class="modal-head"><div><span class="eyebrow">${rej?"Reject profile":"Request changes"}</span><h2>${esc(m.businessName)}</h2></div>${closeBtn()}</div><p class="muted small">${rej?"Explain the reason kindly and clearly. It goes into the email the merchant receives.":"Tell them exactly what to fix and why. Specific, warm feedback gets better resubmissions."}</p><textarea id="fb-text" placeholder="${rej?"e.g. We currently only work with stores that ship physical products…":"e.g. Add your shipping markets and a bit more about who buys from you…"}"></textarea><div class="row between"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn ${rej?"danger":"primary"}" onclick="sendFeedback('${id}','${kind}')">${rej?"Reject and send email":"Send feedback"}</button></div>`)}
async function sendFeedback(id,kind){const fb=document.getElementById("fb-text").value.trim();if(!fb){toast("Write the feedback first");return}const m=S.merchants[id];await updDoc("merchants/"+id,{status:kind,feedback:fb,reviewedAt:nowIso(),reviewedBy:S.uid});await notifyMerchant(id,kind==="rejected"?"An update on your application is ready.":"We've reviewed your profile and suggested a few changes.",kind==="rejected"?"bad":"warn");if(settings().notify.statusEmail)await queueEmail(id,kind==="rejected"?"rejected":"resubmit",{feedback:fb});audit(`${kind==="rejected"?"Rejected":"Requested changes from"} ${m.businessName}`);closeModal();toast("Sent — email queued in the outbox")}

/* merchants table */
function tMerchants(){
  const role=myRole();let list=allM();
  if(role==="specialist")list=list.filter(m=>upsellOf(m.id)?.assignee===S.uid);
  const q=S.ui.mSearch.toLowerCase();if(q)list=list.filter(m=>[m.businessName,m.fullName,m.category,m.storeUrl].join(" ").toLowerCase().includes(q));
  if(S.ui.mStatus)list=list.filter(m=>m.status===S.ui.mStatus);
  const metr=m=>({matched:vals(S.opps).filter(o=>matches(m,o)).length,apps:vals(m.applications).length,deals:vals(m.applications).filter(a=>a.status==="Deal closed").length});
  const key=S.ui.mSort,dir=S.ui.mDir==="asc"?1:-1;
  list=list.map(m=>({...m,_m:metr(m)})).sort((a,b)=>{const g=x=>key==="matched"||key==="apps"||key==="deals"?x._m[key]:key==="spec"?SPEC_STAGES.indexOf(upsellOf(x.id)?.stage||"Not contacted"):key==="createdAt"||key==="lastSeen"?ts(x[key]):String(x[key]||"").toLowerCase();const A=g(a),B=g(b);return A>B?dir:A<B?-dir:0});
  const sel=Object.keys(S.ui.selected).filter(k=>S.ui.selected[k]);
  const th=(k,l)=>`<th class="sortable" onclick="S.ui.mDir=(S.ui.mSort==='${k}'&&S.ui.mDir==='desc')?'asc':'desc';S.ui.mSort='${k}';render(true)">${l}${key===k?(dir>0?" ↑":" ↓"):""}</th>`;
  return `<div class="page-head"><div><h1>Merchants</h1><p class="muted">${role==="specialist"?"Merchants assigned to you.":"Every store on the platform. Click a row for the full profile."}</p></div></div>
  <div class="row"><input type="search" id="m-search" placeholder="Search name, store or category" style="max-width:320px" value="${esc(S.ui.mSearch)}" oninput="S.ui.mSearch=this.value;clearTimeout(window._ms);window._ms=setTimeout(()=>{render(true);const e=document.getElementById('m-search');e.focus();e.setSelectionRange(e.value.length,e.value.length)},250)"><select id="m-status" style="width:auto" onchange="S.ui.mStatus=this.value;render(true)"><option value="">All statuses</option>${["pending","approved","resubmit","rejected"].map(s=>`<option value="${s}" ${S.ui.mStatus===s?"selected":""}>${statusLabel(s)}</option>`).join("")}</select>
  ${sel.length&&role!=="specialist"?`<span class="small muted num">${sel.length} selected</span><button class="btn sm primary" onclick="approve(${esc(JSON.stringify(sel))})">Approve</button><button class="btn sm" onclick="upsellModal(${esc(JSON.stringify(sel))})">${I.flag} Flag for upsell</button><button class="btn sm" onclick="msgModal(${esc(JSON.stringify(sel))})">${I.msg} Message</button><button class="btn ghost sm" onclick="S.ui.selected={};render(true)">Clear</button>`:""}</div>
  ${list.length?`<div class="tablewrap"><table><thead><tr><th><input type="checkbox" aria-label="Select all" onchange="${esc(`(${JSON.stringify(list.map(m=>m.id))}).forEach(i=>S.ui.selected[i]=this.checked);render(true)`)}"></th>${th("businessName","Merchant")}${th("category","Category")}${th("createdAt","Signed up")}${th("status","Status")}${th("lastSeen","Last seen")}${th("matched","Matched")}${th("apps","Applied")}${th("deals","Deals")}${th("spec","Specialist")}</tr></thead><tbody>${list.map(m=>`<tr class="click" onclick="if(event.target.type!=='checkbox')openMerchant('${m.id}')"><td><input type="checkbox" aria-label="Select ${esc(m.businessName)}" ${S.ui.selected[m.id]?"checked":""} onchange="S.ui.selected['${m.id}']=this.checked;render(true)"></td><td><b>${esc(m.businessName)}</b>${m.demo?' <span class="pill demo">Sample</span>':""}<div class="sub">${esc(m.fullName)}</div></td><td>${esc(m.category)}</td><td class="num">${fmtDate(m.createdAt)}</td><td>${statusPillM(m.status)}</td><td class="num">${ago(m.lastSeen)}</td><td class="num">${m._m.matched}</td><td class="num">${m._m.apps}</td><td class="num">${m._m.deals}</td><td><span class="pill">${esc(upsellOf(m.id)?.stage||"Not contacted")}</span></td></tr>`).join("")}</tbody></table></div>`:`<div class="empty"><h3>No merchants ${q||S.ui.mStatus?"match these filters":"yet"}</h3><p class="small">${q||S.ui.mStatus?"Try a different search.":"They'll appear here as soon as someone applies."}</p></div>`}`;
}
function statusLabel(s){return{pending:"Pending",approved:"Approved",resubmit:"Resubmit requested",rejected:"Rejected"}[s]||s}
function statusPillM(s){return `<span class="pill ${s==="approved"?"ok":s==="rejected"?"bad":s==="resubmit"?"info":"warn"}">${statusLabel(s)}</span>`}

/* merchant detail */
function openMerchant(id){S.ui.detail=id;S.ui.detailTab="profile";const m=S.merchants[id];if(m?.keyChange&&!m.keyChange.seen)updDoc("merchants/"+id,{keyChange:{seen:true}}).catch(()=>{});renderDetail()}
function renderDetail(){
  const m=S.merchants[S.ui.detail];if(!m)return closeModal();const n=S.notes[m.id]||{};const u=n.upsell||{};const tab=S.ui.detailTab;const role=myRole();
  const tabs=[["profile","Profile"],["apps","Applications"],["notes","Internal notes"],["msgs","Messages"],["notifs","Notification history"]];
  let body="";
  if(tab==="profile")body=`${profileKV(m)}<div class="card tight" style="margin-top:14px"><div class="row between"><span class="small"><b>Supplier document:</b> ${docStatus(m.supplierDoc?.status)}${m.supplierDoc?.url?` · <a href="${esc(m.supplierDoc.url)}" target="_blank" rel="noopener">Open</a>`:""}</span><select id="sd-st" style="width:auto" onchange="updDoc('merchants/${m.id}',{supplierDoc:{status:this.value}}).then(()=>toast('Document status updated'))">${["none","preparing","uploaded","approved"].map(s=>`<option value="${s}" ${(m.supplierDoc?.status||"none")===s?"selected":""}>${docStatus(s)}</option>`).join("")}</select></div></div>
   <div class="card tight" style="margin-top:12px"><div class="row between"><span class="small"><b>Manually match an opportunity</b> <span class="faint">— overrides automatic matching</span></span><div class="row"><select id="push-opp" style="width:auto;max-width:260px"><option value="">Choose a live opportunity…</option>${vals(S.opps).filter(o=>oppState(o)!=="archived"&&!matches(m,o)).map(o=>`<option value="${o.id}">${esc(o.title)}</option>`).join("")}</select><button class="btn sm" onclick="pushOpp('${m.id}')">Push to merchant</button></div></div>${Object.keys(m.pushed||{}).filter(k=>m.pushed[k]).length?`<p class="small faint" style="margin-top:6px">Pushed: ${Object.keys(m.pushed).filter(k=>m.pushed[k]).map(k=>esc(S.opps[k]?.title||"removed opportunity")).join(", ")}</p>`:""}</div>`;
  if(tab==="apps"){const a=vals(m.applications).sort((x,y)=>ts(y.appliedAt)-ts(x.appliedAt));body=a.length?a.map(x=>`<div class="li"><div class="grow"><p style="font-weight:600">${esc(x.title)}</p><span class="small faint">${esc(x.type)} · applied ${fmtDate(x.appliedAt)}${x.notes?" · "+esc(x.notes):""}</span></div>${statusPill(x.status)}</div>`).join(""):'<p class="muted small">No applications logged yet.</p>'}
  if(tab==="notes"){const ns=vals(n.notes).sort((a,b)=>ts(b.at)-ts(a.at));body=`<p class="small muted">Only the team can see these. Never shown to the merchant.</p><div class="row" style="margin:10px 0"><input type="text" id="note-in" placeholder="Add a private note"><button class="btn sm primary" onclick="addNote('${m.id}')">Add note</button></div>${ns.map(x=>`<div class="li"><span class="ico">${I.doc}</span><div class="grow"><p class="small" style="white-space:pre-wrap">${esc(x.text)}</p><span class="small faint">${esc(nameOf(x.by))} · ${ago(x.at)}</span></div></div>`).join("")||'<p class="muted small">No notes yet.</p>'}`}
  if(tab==="msgs"){const ms=vals(m.messages).sort((a,b)=>ts(a.at)-ts(b.at));body=`${ms.map(x=>`<div class="li"><span class="ico ${x.from==="team"?"":"info"}">${x.from==="team"?I.msg:I.user}</span><div class="grow"><p class="small"><b>${x.from==="team"?esc(x.by?nameOf(x.by):"Team"):esc(m.fullName)}</b> · <span class="faint">${ago(x.at)}</span></p><p class="small" style="white-space:pre-wrap">${esc(x.text)}</p></div></div>`).join("")||'<p class="muted small">No messages yet.</p>'}<div class="stack" style="margin-top:12px"><textarea id="dm-text" placeholder="Write a message to ${esc(firstName(m))}"></textarea><div><button class="btn primary sm" onclick="sendDM(['${m.id}'],document.getElementById('dm-text').value).then(renderDetail).catch(()=>{})">Send message</button></div></div>`}
  if(tab==="notifs"){const ns=vals(m.notifications).sort((a,b)=>ts(b.at)-ts(a.at));const es=vals(m.emails).sort((a,b)=>ts(b.at)-ts(a.at));body=`<h3 style="margin-bottom:6px">In-app</h3>${ns.map(notifRow).join("")||'<p class="muted small">None yet.</p>'}<h3 style="margin:14px 0 6px">Emails</h3>${es.map(e=>`<div class="li"><span class="ico">${I.mail}</span><div class="grow"><p class="small"><b>${esc(e.subject)}</b></p><span class="small faint">${ago(e.at)} · ${e.sent?"Marked sent":"In outbox"}</span></div></div>`).join("")||'<p class="muted small">None yet.</p>'}`}
  openModal(`<div class="modal-head"><div class="stack s6"><div class="row">${statusPillM(m.status)}<span class="pill accent">${esc(m.category)}</span>${m.demo?'<span class="pill demo">Sample</span>':""}</div><h2>${esc(m.businessName)}</h2><span class="small muted">${esc(m.fullName)} · ${esc(m.email||"no email")} · signed up ${fmtDate(m.createdAt)} · last seen ${ago(m.lastSeen)}</span></div>${closeBtn()}</div>
  ${role!=="specialist"?`<div class="row">${m.status!=="approved"?`<button class="btn primary sm" onclick="approve(['${m.id}']).then(renderDetail)">${I.check} Approve</button>`:""}<button class="btn sm" onclick="feedbackModal('${m.id}','resubmit')">Request changes</button><button class="btn sm danger" onclick="feedbackModal('${m.id}','rejected')">Reject</button><button class="btn sm" onclick="upsellModal(['${m.id}'])">${I.flag} ${u.flag?"Edit upsell":"Flag for upsell"}</button><button class="btn sm" onclick="S.previewId='${m.id}';closeModal();go('merchant','dashboard')">See their view</button></div>`:`<div class="row"><button class="btn sm" onclick="upsellModal(['${m.id}'])">${I.flag} Update upsell</button></div>`}
  ${u.flag?`<div class="notice info small"><b>Upsell:</b> ${esc(u.service||"service not chosen")} · ${esc(u.stage||"Not contacted")}${u.value?" · potential $"+esc(u.value):""}${u.assignee?" · "+esc(nameOf(u.assignee)):""}</div>`:""}
  <div class="tabs" role="tablist">${tabs.map(([k,l])=>`<button role="tab" aria-selected="${tab===k}" onclick="S.ui.detailTab='${k}';renderDetail()">${l}</button>`).join("")}</div><div>${body}</div>`,true);
}
async function pushOpp(mid){const oid=document.getElementById("push-opp").value;if(!oid)return;await updDoc("merchants/"+mid,{pushed:{[oid]:true}});await notifyMerchant(mid,`New opportunity picked for you: "${S.opps[oid].title}"`,"match");audit(`Manually matched "${S.opps[oid].title}" to ${S.merchants[mid].businessName}`);toast("Pushed to merchant");renderDetail()}
async function addNote(mid){const t=document.getElementById("note-in").value.trim();if(!t)return;const id=gid();await upsert("notes/"+mid,{notes:{[id]:{text:t,by:S.uid,at:nowIso()}}});toast("Note added");setTimeout(renderDetail,150)}
function msgModal(ids){openModal(`<div class="modal-head"><h2>Message ${ids.length>1?ids.length+" merchants":esc(S.merchants[ids[0]]?.businessName)}</h2>${closeBtn()}</div><p class="small muted">Shows in their inbox and notification bell.</p><textarea id="bm-text"></textarea><div class="row between"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="sendDM(${esc(JSON.stringify(ids))},document.getElementById('bm-text').value).then(closeModal).catch(()=>{})">Send</button></div>`)}
async function sendDM(ids,text){text=(text||"").trim();if(!text){toast("Write a message first");throw new Error("empty")}for(const id of ids){const k=gid();await updDoc("merchants/"+id,{messages:{[k]:{from:"team",by:S.uid,text,at:nowIso()}}});await notifyMerchant(id,"New message from the MerchantBridge team","msg")}audit(`Messaged ${ids.length} merchant${ids.length>1?"s":""}`);toast("Message sent")}
function upsellModal(ids){const u=ids.length===1?(upsellOf(ids[0])||{}):{};const team=teamList();openModal(`<div class="modal-head"><h2>${ids.length>1?"Flag "+ids.length+" merchants for upsell":"Upsell · "+esc(S.merchants[ids[0]]?.businessName)}</h2>${closeBtn()}</div>
 <div class="formgrid"><div class="field"><label for="u-svc">Service that fits best</label><select id="u-svc">${SERVICES.map(s=>`<option ${u.service===s?"selected":""}>${s}</option>`).join("")}</select></div><div class="field"><label for="u-stage">Stage</label><select id="u-stage">${SPEC_STAGES.map(s=>`<option ${u.stage===s?"selected":""}>${s}</option>`).join("")}</select></div><div class="field"><label for="u-val">Potential value ($)</label><input id="u-val" type="number" min="0" value="${esc(u.value||"")}"></div><div class="field"><label for="u-as">Specialist</label><select id="u-as"><option value="">Unassigned</option>${team.map(t=>`<option value="${t.id}" ${u.assignee===t.id?"selected":""}>${esc(nameOf(t.id))} · ${ROLES[t.role]}</option>`).join("")}</select></div><div class="field full"><label for="u-why">What the team noticed</label><input id="u-why" type="text" placeholder="e.g. Product photos are inconsistent" value="${esc(u.why||"")}"></div></div>
 <div class="row between">${u.flag?`<button class="btn ghost danger" onclick="saveUpsell(${esc(JSON.stringify(ids))},false)">Remove from pipeline</button>`:"<span></span>"}<button class="btn primary" onclick="saveUpsell(${esc(JSON.stringify(ids))},true)">Save</button></div>`)}
async function saveUpsell(ids,flag){const data={flag,service:document.getElementById("u-svc").value,stage:document.getElementById("u-stage").value,value:document.getElementById("u-val").value,assignee:document.getElementById("u-as").value,why:document.getElementById("u-why").value,updatedAt:nowIso()};for(const id of ids){await upsert("notes/"+id,{upsell:data})}audit(`${flag?"Updated upsell for":"Removed from upsell"} ${ids.length} merchant${ids.length>1?"s":""}`);S.ui.selected={};if(S.ui.detail&&ids.length===1)setTimeout(renderDetail,150);else closeModal();toast("Upsell pipeline updated");render()}

/* opportunities */
function tOpps(){
  const f=S.ui.oppFilter;const ms=allM();
  let list=vals(S.opps).map(o=>({...o,_st:oppState(o)}));
  if(f==="live")list=list.filter(o=>o._st!=="archived");if(f==="archived")list=list.filter(o=>o._st==="archived");
  list=sortOpps(list);
  const appCount=o=>allApps().filter(a=>a.oppId===o.id).length;
  return `<div class="page-head"><div><h1>Opportunities</h1><p class="muted">Add what the team finds. Matching, featured pinning and auto-archiving happen automatically.</p></div><button class="btn primary" onclick="oppForm()">${I.plus} Add opportunity</button></div>
  <div class="tabs" role="tablist">${[["live","Live"],["archived","Archived"],["all","All"]].map(([k,l])=>`<button role="tab" aria-selected="${f===k}" onclick="S.ui.oppFilter='${k}';render(true)">${l}</button>`).join("")}</div>
  ${list.length?`<div class="tablewrap"><table><thead><tr><th>Opportunity</th><th>Type</th><th>Added</th><th>Source</th><th>Expires</th><th>Status</th><th>Matched</th><th>Applied</th><th></th></tr></thead><tbody>${list.map(o=>`<tr><td style="min-width:220px"><b>${esc(o.title)}</b>${o.priority==="featured"?' <span class="pill accent">Featured</span>':""}${o.demo?' <span class="pill demo">Sample</span>':""}<div class="sub">by ${esc(nameOf(o.addedBy))}</div></td><td><span class="pill">${esc(o.type)}</span></td><td class="num">${fmtDate(o.createdAt)}</td><td>${esc(o.sourceCategory||"—")}${o.sourceUrl?`<div class="sub"><a href="${esc(o.sourceUrl)}" target="_blank" rel="noopener">Open source</a></div>`:""}</td><td class="num">${o.expiry?fmtDate(o.expiry+"T12:00:00"):"30 days"}</td><td><span class="pill ${o._st==="live"?"ok":o._st==="expiring"?"warn":""}">${o._st==="live"?"Live":o._st==="expiring"?"Expiring soon":"Archived"}</span></td><td class="num">${ms.filter(m=>matches(m,o,true)).length}</td><td class="num">${appCount(o)}</td><td><div class="row" style="flex-wrap:nowrap"><button class="btn sm" onclick="oppForm('${o.id}')">Edit</button>${o._st!=="archived"?`<button class="btn sm" title="Notify every matched merchant now" onclick="boost('${o.id}')">${I.bolt} Boost</button><button class="btn ghost sm" onclick="archiveOpp('${o.id}')">Archive</button>`:`<button class="btn ghost sm" onclick="restoreOpp('${o.id}')">Restore</button>`}</div></td></tr>`).join("")}</tbody></table></div>`:`<div class="empty"><span class="ico">${I.bolt}</span><h3>${f==="archived"?"Nothing archived yet":"No live opportunities"}</h3><p class="small">Add the first one and it goes straight to every matched merchant's feed.</p><button class="btn primary sm" onclick="oppForm()">Add opportunity</button></div>`}`;
}
function oppForm(id){
  const o=id?S.opps[id]:{type:TYPES[0],requirements:["","","","",""],categories:[],markets:[],requiresCustom:false,minVolume:"",priority:"standard",expiry:plusDays(30),sourceCategory:SOURCES[0]};
  const req=[...(o.requirements||[]),"","","","",""].slice(0,5);
  openModal(`<div class="modal-head"><div><span class="eyebrow">${id?"Edit":"New"} opportunity</span><h2>${id?esc(o.title):"Add an opportunity"}</h2></div>${closeBtn()}</div>
  <form id="oppf" class="formgrid" onsubmit="event.preventDefault();saveOpp(${id?`'${id}'`:"null"})">
   <div class="field full"><label for="o-title">Title <span class="faint">(one line, don't name the source)</span></label><input id="o-title" type="text" required value="${esc(o.title||"")}" placeholder="e.g. Hotel group sourcing natural soaps for 40 properties"></div>
   <div class="field"><label for="o-type">Type</label><select id="o-type">${TYPES.map(t=>`<option ${o.type===t?"selected":""}>${t}</option>`).join("")}</select></div>
   <div class="field"><label for="o-pri">Priority</label><select id="o-pri"><option value="standard" ${o.priority!=="featured"?"selected":""}>Standard</option><option value="featured" ${o.priority==="featured"?"selected":""}>Featured — pinned to top</option></select></div>
   <div class="field full"><label for="o-desc">Short description <span class="faint">(2–3 sentences)</span></label><textarea id="o-desc" required>${esc(o.description||"")}</textarea></div>
   <div class="field full"><span class="flabel">Key requirements <span class="faint">(up to 5)</span></span><div class="stack s6">${req.map((r,i)=>`<input type="text" id="o-req${i}" value="${esc(r)}" placeholder="${["Category fit","Capacity needed","Customisation","Location","Deadline"][i]}">`).join("")}</div></div>
   <div class="field"><label for="o-url">Source URL</label><input id="o-url" type="url" required value="${esc(o.sourceUrl||"")}" placeholder="https://"></div>
   <div class="field"><label for="o-src">Where it was found</label><select id="o-src">${SOURCES.map(s=>`<option ${o.sourceCategory===s?"selected":""}>${s}</option>`).join("")}</select></div>
   <div class="field"><label for="o-exp">Expiry date</label><input id="o-exp" type="date" value="${esc(o.expiry||"")}"><span class="hint">Auto-archives on this date or after 30 days, whichever comes first.</span></div>
   <div class="field"><label for="o-vol">Minimum capacity</label><select id="o-vol"><option value="">Any size</option>${VOLUME.map(v=>`<option ${o.minVolume===v?"selected":""}>${v}</option>`).join("")}</select></div>
   <div class="field full"><span class="flabel">Match categories <span class="faint">(none = all)</span></span><div class="checks">${CATEGORIES.map(c=>`<label class="chk"><input type="checkbox" name="o-cat" value="${c}" ${(o.categories||[]).includes(c)?"checked":""}> ${c}</label>`).join("")}</div></div>
   <div class="field full"><span class="flabel">Required shipping markets <span class="faint">(none = anywhere)</span></span><div class="checks">${MARKETS.map(c=>`<label class="chk"><input type="checkbox" name="o-mk" value="${c}" ${(o.markets||[]).includes(c)?"checked":""}> ${c}</label>`).join("")}</div></div>
   <div class="field full"><label class="toggle"><input type="checkbox" id="o-custom" ${o.requiresCustom?"checked":""}> Needs custom branding or packaging</label></div>
   <div class="full row between"><span class="small muted" id="o-preview"></span><div class="row"><button type="button" class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" type="submit">${id?"Save changes":"Publish to feed"}</button></div></div>
  </form>`,true);
  const upd=()=>{const t=readOpp();const n=allM().filter(m=>matches(m,{...t,id:"_",createdAt:nowIso(),status:"live"},true)).length;document.getElementById("o-preview").textContent=`Matches ${n} merchant${n===1?"":"s"} right now`};document.getElementById("oppf").addEventListener("change",upd);upd();
}
function readOpp(){const g=id=>document.getElementById(id).value.trim();return{title:g("o-title"),type:g("o-type"),priority:g("o-pri"),description:g("o-desc"),requirements:[0,1,2,3,4].map(i=>g("o-req"+i)).filter(Boolean),sourceUrl:g("o-url"),sourceCategory:g("o-src"),expiry:g("o-exp"),minVolume:g("o-vol"),categories:[...document.querySelectorAll('input[name=o-cat]:checked')].map(x=>x.value),markets:[...document.querySelectorAll('input[name=o-mk]:checked')].map(x=>x.value),requiresCustom:document.getElementById("o-custom").checked}}
async function saveOpp(id){const data=readOpp();if(!data.title||!data.description||!data.sourceUrl){toast("Add a title, description and source URL");return}
  if(id){await updDoc("opportunities/"+id,{...data,updatedAt:nowIso()});audit(`Edited opportunity "${data.title}"`);closeModal();toast("Changes are live");return}
  const nid=gid();const o={...data,status:"live",createdAt:nowIso(),addedBy:S.uid};await setDoc("opportunities/"+nid,o);audit(`Added opportunity "${data.title}"`);closeModal();toast("Published to matched feeds");
  if(settings().notify.newMatch){const targets=allM().filter(m=>matches(m,{...o,id:nid}));for(const m of targets)await notifyMerchant(m.id,`New match: "${data.title}"`,"match").catch(()=>{})}}
async function boost(id){const o=S.opps[id];const targets=allM().filter(m=>matches(m,o));if(!targets.length){toast("No merchants match this one yet");return}for(const m of targets){await notifyMerchant(m.id,`Time-sensitive: "${o.title}" — act fast`,"match");if(settings().notify.boostEmail)await queueEmail(m.id,"boost",{opportunity:o.title})}await updDoc("opportunities/"+id,{boostedAt:nowIso()});audit(`Boosted "${o.title}" to ${targets.length} merchants`);toast(`Boosted to ${targets.length} merchant${targets.length>1?"s":""}`)}
async function archiveOpp(id){const o=S.opps[id];await updDoc("opportunities/"+id,{status:"archived",archivedAt:nowIso()});for(const m of allM().filter(m=>m.saved?.[id]))await notifyMerchant(m.id,`"${o.title}" has closed and moved to your archive.`,"warn").catch(()=>{});audit(`Archived "${o.title}"`);toast("Archived")}
async function restoreOpp(id){await updDoc("opportunities/"+id,{status:"live",expiry:plusDays(14),restoredAt:nowIso()});toast("Restored for 14 days")}

/* sourcing */
function tSourcing(){
  const st=settings();const target=st.weeklyTarget||50;const wk=thisWeekOpps();
  const byType=TYPES.map(t=>[t,wk.filter(o=>o.type===t).length]).filter(x=>x[1]).sort((a,b)=>b[1]-a[1]);
  const bySrc=SOURCES.map(s=>[s,wk.filter(o=>o.sourceCategory===s).length]).filter(x=>x[1]).sort((a,b)=>b[1]-a[1]);
  const weeks=[];for(let i=7;i>=0;i--){const s=weekStart(new Date(Date.now()-i*7*DAY)).getTime();const e=s+7*DAY;weeks.push({label:i===0?"This wk":new Date(s).toLocaleDateString(undefined,{day:"numeric",month:"short"}),n:vals(S.opps).filter(o=>ts(o.createdAt)>=s&&ts(o.createdAt)<e).length,cur:i===0})}
  const max=Math.max(target,...weeks.map(w=>w.n),1);
  const lb={};wk.forEach(o=>lb[o.addedBy]=(lb[o.addedBy]||0)+1);const lbl=Object.entries(lb).sort((a,b)=>b[1]-a[1]);
  const hb=(rows,mx)=>rows.length?rows.map(([k,v])=>`<div class="hbar"><span>${esc(k)}</span><div class="bar"><i style="width:${Math.round(v/mx*100)}%"></i></div><span class="num" style="text-align:right">${v}</span></div>`).join(""):'<p class="muted small">Nothing added this week yet.</p>';
  return `<div class="page-head"><div><h1>Sourcing tracker</h1><p class="muted">Target: ${target} new opportunities a week. Resets Monday at midnight.</p></div><button class="btn primary" onclick="oppForm()">${I.plus} Add opportunity</button></div>
  <section class="card"><div class="row between" style="margin-bottom:10px"><span class="stat"><span class="v num">${wk.length} <span class="faint" style="font-size:18px">/ ${target} this week</span></span></span><span class="pill ${wk.length>=target?"ok":"warn"}">${wk.length>=target?"Target hit":(target-wk.length)+" to go"}</span></div><div class="bar ${wk.length>=target?"ok":""}"><i style="width:${Math.min(100,wk.length/target*100)}%"></i></div></section>
  <div class="grid g2"><section class="card stack"><h3>By opportunity type</h3>${hb(byType,Math.max(1,...byType.map(x=>x[1])))}</section><section class="card stack"><h3>By source</h3>${hb(bySrc,Math.max(1,...bySrc.map(x=>x[1])))}</section></div>
  <div class="grid g2"><section class="card"><h3>Previous weeks</h3><div class="weeks" role="img" aria-label="Opportunities added per week">${weeks.map(w=>`<div class="w ${w.cur?"cur":""}"><span class="num" style="color:var(--ink);font-weight:600">${w.n}</span><i style="height:${Math.max(2,w.n/max*100)}%"></i><span>${w.label}</span></div>`).join("")}</div></section>
  ${st.leaderboard?`<section class="card"><h3 style="margin-bottom:8px">This week's leaderboard</h3>${lbl.length?lbl.map(([id,n],i)=>`<div class="li"><span class="ico ${i===0?"":"info"}">${i===0?I.star:i+1}</span><div class="grow"><b>${esc(nameOf(id))}</b></div><span class="num" style="font-weight:700">${n}</span></div>`).join(""):'<p class="muted small">First one to add an opportunity this week takes the top spot.</p>'}</section>`:""}</div>`;
}

/* upsell */
function tUpsell(){
  const role=myRole();let ms=allM().filter(m=>upsellOf(m.id)?.flag);if(role==="specialist")ms=ms.filter(m=>upsellOf(m.id).assignee===S.uid);
  const total=ms.filter(m=>upsellOf(m.id).stage!=="Completed").reduce((s,m)=>s+(+upsellOf(m.id).value||0),0);
  return `<div class="page-head"><div><h1>Upsell pipeline</h1><p class="muted">Merchants the team has flagged for a paid service. Open pipeline value: <b class="num">$${total.toLocaleString()}</b></p></div></div>
  ${ms.length?`<div class="kanban">${SPEC_STAGES.map(s=>{const col=ms.filter(m=>(upsellOf(m.id).stage||"Not contacted")===s);return `<div class="col"><h3>${s}<span class="faint num">${col.length}</span></h3>${col.map(m=>{const u=upsellOf(m.id);return `<div class="card tight stack s6" style="cursor:pointer" onclick="openMerchant('${m.id}')"><b>${esc(m.businessName)}</b><span class="small muted">${esc(u.service||"")}${u.value?" · $"+esc(u.value):""}</span>${u.why?`<span class="small faint">${esc(u.why)}</span>`:""}<span class="small faint">${u.assignee?esc(nameOf(u.assignee)):"Unassigned"}</span><select id="us-${m.id}" onclick="event.stopPropagation()" onchange="upsert('notes/${m.id}',{upsell:{stage:this.value,updatedAt:nowIso()}}).then(()=>toast('Moved to '+this.value))">${SPEC_STAGES.map(x=>`<option ${x===s?"selected":""}>${x}</option>`).join("")}</select></div>`}).join("")}</div>`}).join("")}</div>`:`<div class="empty"><span class="ico">${I.flag}</span><h3>Pipeline is empty</h3><p class="small">Open a merchant and choose "Flag for upsell" when you spot something the team could improve.</p></div>`}`;
}

/* testimonials */
function tLibrary(){
  const tab=S.ui.libTab;const all=allTestimonials();const list=all.filter(t=>tab==="all"?true:tab==="approved"?t.status==="approved"||t.status==="featured":t.status===tab);
  return `<div class="page-head"><div><h1>Testimonials & case studies</h1><p class="muted">Collected when merchants close deals. Approve before anything goes on the website or into outreach.</p></div><div class="row"><button class="btn primary" onclick="reviewForm()">${I.plus} Add a review</button>${S.downloads?`<button class="btn" onclick="exportTestimonials()">${I.doc} Export approved</button>`:""}</div></div>
  <div class="tabs" role="tablist">${[["pending","Pending review"],["approved","Approved"],["featured","Featured"],["archived","Archived"],["all","All"]].map(([k,l])=>`<button role="tab" aria-selected="${tab===k}" onclick="S.ui.libTab='${k}';render(true)">${l} <span class="faint num">${k==="all"?all.length:k==="approved"?all.filter(t=>t.status==="approved"||t.status==="featured").length:all.filter(t=>t.status===k).length}</span></button>`).join("")}<button role="tab" aria-selected="${tab==="website"}" onclick="S.ui.libTab='website';render(true)">On website <span class="faint num">${vals(S.reviews).length}</span></button></div>
  ${tab==="website"?websiteReviews():""}
  ${tab==="website"?"":list.length?`<div class="opp-grid">${list.map(t=>`<article class="opp"><div class="row between"><span class="pill accent">${esc(t.merchant.category)}</span><span class="pill ${t.status==="featured"?"accent":t.status==="approved"?"ok":t.status==="archived"?"":"warn"}">${{pending:"Pending review",approved:"Approved for use",featured:"Featured",archived:"Archived"}[t.status]}</span></div><p class="quote">${esc(t.text)}</p><span class="stars" aria-label="${t.rating} of 5">${"★".repeat(t.rating||0)}${"☆".repeat(5-(t.rating||0))}</span><span class="small muted"><b>${esc(shortName(t.merchant))}</b> · ${esc(t.oppTitle||"")} · ${fmtDate(t.at)}</span>${t.caseStudy?.result?`<span class="pill info" style="align-self:flex-start">Case study: ${esc(t.caseStudy.result)}</span>`:""}
  <div class="acts">${t.status!=="approved"&&t.status!=="featured"?`<button class="btn sm primary" onclick="setT('${t.merchant.id}','${t.id}','approved')">Approve</button>`:""}${t.status!=="featured"?`<button class="btn sm" onclick="setT('${t.merchant.id}','${t.id}','featured')">${I.star} Feature</button>`:""}${(t.status==="approved"||t.status==="featured")?(S.reviews["t-"+t.id]?`<button class="btn sm" onclick="unpublishReview('t-${t.id}')">Remove from website</button>`:`<button class="btn sm primary" onclick="publishReview('${t.merchant.id}','${t.id}')">Publish to website</button>`):""}<button class="btn sm" onclick="expansion('${t.merchant.id}')">Request story</button><button class="btn sm" onclick="caseModal('${t.merchant.id}','${t.id}')">Case study</button>${t.status!=="archived"?`<button class="btn ghost sm" onclick="setT('${t.merchant.id}','${t.id}','archived')">Archive</button>`:""}</div></article>`).join("")}</div>`:`<div class="empty"><span class="ico">${I.star}</span><h3>Nothing here yet</h3><p class="small">When a merchant marks a deal as closed, they're asked for a testimonial. It lands here for review.</p></div>`}`;
}

function websiteReviews(){const r=vals(S.reviews).sort((a,b)=>ts(b.at)-ts(a.at));return r.length?`<div class="opp-grid">${r.map(x=>`<article class="opp"><div class="row between"><span class="pill accent">${esc(x.category||"")}</span>${x.featured?'<span class="pill accent">Shown first</span>':""}</div><p class="quote" style="display:-webkit-box;-webkit-line-clamp:6;-webkit-box-orient:vertical;overflow:hidden">${esc(x.text)}</p><span class="small muted"><b>${esc(x.name)}</b> · ${esc(x.store)}${x.closed?" · "+esc(x.closed):""}</span><div class="acts"><button class="btn sm" onclick="reviewForm('${x.id}')">Edit</button><button class="btn sm" onclick="updDoc('reviews/${x.id}',{featured:${!x.featured}}).then(()=>toast('Updated'))">${x.featured?"Unpin":"Show first"}</button><button class="btn ghost sm danger" onclick="unpublishReview('${x.id}')">Remove</button></div></article>`).join("")}</div>`:`<div class="empty"><h3>No reviews on the website yet</h3><p class="small">Publish an approved testimonial, or add a review a merchant sent you by email or message.</p><button class="btn primary sm" onclick="reviewForm()">Add a review</button></div>`}
async function publishReview(mid,tid){const m=S.merchants[mid];const t=m.testimonials[tid];await setDoc("reviews/t-"+tid,{name:shortName(m),store:m.businessName,category:m.category||"",rating:t.rating||5,text:t.text,closed:t.oppTitle||"",featured:t.status==="featured",at:nowIso(),source:"testimonial"});audit(`Published ${m.businessName}'s review to the website`);toast("Live on the website")}
async function unpublishReview(id){await delDoc("reviews/"+id);audit("Removed a review from the website");toast("Removed from the website")}
function reviewForm(id){const r=id?{id,...S.reviews[id]}:{rating:5};openModal(`<div class="modal-head"><div><span class="eyebrow">Website review</span><h2>${id?"Edit review":"Add a review"}</h2><p class="small muted">Only add reviews merchants actually gave you. Use first name and last initial.</p></div>${closeBtn()}</div>
 <div class="formgrid"><div class="field"><label for="rv-name">Name (e.g. Ada O.)</label><input id="rv-name" type="text" value="${esc(r.name||"")}"></div><div class="field"><label for="rv-store">Store name</label><input id="rv-store" type="text" value="${esc(r.store||"")}"></div><div class="field"><label for="rv-cat">Category</label><select id="rv-cat">${CATEGORIES.map(c=>`<option ${r.category===c?"selected":""}>${c}</option>`).join("")}</select></div><div class="field"><label for="rv-rate">Rating</label><select id="rv-rate">${[5,4,3,2,1].map(n=>`<option value="${n}" ${+r.rating===n?"selected":""}>${n} stars</option>`).join("")}</select></div><div class="field full"><label for="rv-closed">What they closed (optional)</label><input id="rv-closed" type="text" placeholder="e.g. Wholesale account" value="${esc(r.closed||"")}"></div><div class="field full"><label for="rv-text">Full review</label><textarea id="rv-text" style="min-height:200px">${esc(r.text||"")}</textarea><span class="hint">Write it in full. The website shows the first few lines with a Read full review link.</span></div><div class="field full"><label class="toggle"><input type="checkbox" id="rv-feat" ${r.featured?"checked":""}> Show this one first</label></div></div>
 <div class="row between"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="saveReview(${id?`'${id}'`:"null"})">${id?"Save changes":"Publish to website"}</button></div>`,true)}
async function saveReview(id){const g=x=>document.getElementById(x).value.trim();const d={name:g("rv-name"),store:g("rv-store"),category:g("rv-cat"),rating:+g("rv-rate"),closed:g("rv-closed"),text:g("rv-text"),featured:document.getElementById("rv-feat").checked};if(!d.name||!d.text){toast("Add a name and the review text");return}if(id)await updDoc("reviews/"+id,d);else await setDoc("reviews/r-"+gid(),{...d,at:nowIso(),source:"manual"});audit(`${id?"Edited":"Added"} website review from ${d.name}`);closeModal();toast(id?"Review updated":"Live on the website")}

async function setT(mid,tid,status){await updDoc("merchants/"+mid,{testimonials:{[tid]:{status}}});audit(`Testimonial from ${S.merchants[mid].businessName} → ${status}`);toast("Updated")}
function expansion(mid){const m=S.merchants[mid];const t=settings().templates.expansion;const vars={name:firstName(m),store:m.businessName};openModal(`<div class="modal-head"><h2>Ask ${esc(firstName(m))} for a fuller story</h2>${closeBtn()}</div><div class="field"><label for="ex-sub">Subject</label><input id="ex-sub" type="text" value="${esc(fill(t.subject,vars))}"></div><div class="field"><label for="ex-body">Message</label><textarea id="ex-body" style="min-height:200px">${esc(fill(t.body,vars))}</textarea></div><div class="row between"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="sendExpansion('${mid}')">Queue email</button></div>`)}
async function sendExpansion(mid){const id=gid();await updDoc("merchants/"+mid,{emails:{[id]:{template:"expansion",to:S.merchants[mid].email||"",subject:document.getElementById("ex-sub").value,body:document.getElementById("ex-body").value,at:nowIso(),sent:false}}});closeModal();toast("Queued in the email outbox")}
function caseModal(mid,tid){const t=S.merchants[mid].testimonials[tid];const c=t.caseStudy||{};openModal(`<div class="modal-head"><div><span class="eyebrow">Case study</span><h2>${esc(S.merchants[mid].businessName)}</h2></div>${closeBtn()}</div><div class="formgrid">${[["before","Situation before MerchantBridge"],["found","Opportunities they found"],["services","Services they used from the team"],["result","The specific result"],["visuals","Before / after visuals (links)"]].map(([k,l])=>`<div class="field full"><label for="cs-${k}">${l}</label>${k==="result"||k==="visuals"?`<input id="cs-${k}" type="text" value="${esc(c[k]||"")}">`:`<textarea id="cs-${k}" style="min-height:70px">${esc(c[k]||"")}</textarea>`}</div>`).join("")}</div><div class="row between"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="saveCase('${mid}','${tid}')">Save case study</button></div>`,true)}
async function saveCase(mid,tid){const c={};["before","found","services","result","visuals"].forEach(k=>c[k]=document.getElementById("cs-"+k).value);await updDoc("merchants/"+mid,{testimonials:{[tid]:{caseStudy:c}}});closeModal();toast("Case study saved")}
async function exportTestimonials(){const list=allTestimonials().filter(t=>t.status==="approved"||t.status==="featured");if(!list.length){toast("Approve a testimonial first");return}const txt="MerchantBridge — Approved testimonials\nExported "+new Date().toLocaleDateString()+"\n\n"+list.map(t=>`${t.status==="featured"?"★ FEATURED\n":""}"${t.text}"\n— ${shortName(t.merchant)}, ${t.merchant.category}${t.oppTitle?" · "+t.oppTitle:""} · ${"★".repeat(t.rating||0)}${t.caseStudy?.result?"\nResult: "+t.caseStudy.result:""}${t.caseStudy?.before?"\nBefore: "+t.caseStudy.before:""}${t.caseStudy?.services?"\nServices: "+t.caseStudy.services:""}`).join("\n\n---\n\n");try{await S.downloads.save({filename:"merchantbridge-testimonials.txt",data:txt})}catch(e){if(e?.code!=="declined")toast("Couldn't export — try again")}}

/* outbox */
function tOutbox(){
  const es=allEmails();const pending=es.filter(e=>!e.sent);
  return `<div class="page-head"><div><h1>Email outbox</h1><p class="muted">Every email the platform triggers is written here from your templates. Copy and send, then mark it sent. Once an email service is connected, these go out automatically.</p></div><button class="btn primary" onclick="buildDigest()">${I.mail} Build this week's digest</button></div>
  ${es.length?`<div class="stack">${es.slice(0,80).map(e=>`<details class="card tight" ${e.sent?"":""}><summary class="row between" style="cursor:pointer;list-style:none"><span class="row"><span class="ico ${e.sent?"ok":""}">${e.sent?I.check:I.mail}</span><span><b>${esc(e.subject)}</b><br><span class="small faint">To ${esc(e.merchant.businessName)}${e.to?" &lt;"+esc(e.to)+"&gt;":""} · ${settings().templates[e.template]?.label||e.template} · ${ago(e.at)}</span></span></span><span class="pill ${e.sent?"ok":"warn"}">${e.sent?"Sent":"To send"}</span></summary><pre style="white-space:pre-wrap;font-family:var(--f-body);font-size:14px;background:var(--soft);border-radius:var(--r-sm);padding:14px;margin:12px 0">${esc(e.body)}</pre><div class="row"><button class="btn sm" onclick="copyText(${esc(JSON.stringify("Subject: "+e.subject+"\n\n"+e.body))})">Copy email</button>${e.to?`<button class="btn sm" onclick="copyText(${esc(JSON.stringify(e.to))})">Copy address</button>`:""}${e.sent?"":`<button class="btn sm primary" onclick="updDoc('merchants/${e.merchant.id}',{emails:{'${e.id}':{sent:true}}}).then(()=>toast('Marked sent'))">Mark sent</button>`}</div></details>`).join("")}</div>`:`<div class="empty"><span class="ico">${I.mail}</span><h3>No emails yet</h3><p class="small">Approvals, change requests, boosts, closed deals and digests all create emails here.</p></div>`}<p class="small faint">${pending.length} waiting to be sent.</p>`;
}
async function copyText(t){try{await navigator.clipboard.writeText(t);toast("Copied")}catch(e){openModal(`<div class="modal-head"><h2>Copy this</h2>${closeBtn()}</div><textarea id="cp" style="min-height:240px">${esc(t)}</textarea>`);setTimeout(()=>document.getElementById("cp")?.select(),40)}}
async function buildDigest(){const ws=weekStart().getTime();const fresh=vals(S.opps).filter(o=>ts(o.createdAt)>=ws&&oppState(o)!=="archived");let n=0;for(const m of allM().filter(m=>m.status==="approved")){const list=fresh.filter(o=>matches(m,o));if(!list.length)continue;await queueEmail(m.id,"digest",{count:list.length,list:list.map(o=>"• "+o.title+" ("+o.type+")").join("\n")});n++}audit(`Built weekly digest for ${n} merchants`);toast(n?`Digest queued for ${n} merchant${n>1?"s":""}`:"No new matches this week to send")}

/* settings */
function teamList(){const ids=new Set(Object.keys(S.team));if(S.uid&&S.isOwner)ids.add(S.uid);return [...ids].map(id=>({id,...(S.team[id]||{}),role:id===S.uid&&S.isOwner?"admin":(S.team[id]?.role||"manager")})).filter(t=>t.active!==false)}
function tSettings(){
  const st=settings();const team=teamList();
  const rules=[["approvedOnly","Only show opportunities to approved merchants"],["category","Only match merchants in the opportunity's categories"],["market","Only match merchants who ship to the required markets"],["custom","Only match merchants who can customise when it's required"],["capacity","Only match merchants who meet the minimum capacity"]];
  return `<div class="page-head"><div><h1>Settings</h1><p class="muted">Team access, matching rules, emails and the weekly digest. Every change is logged.</p></div></div>
  <section class="card"><div class="card-head"><h3>Team members</h3><button class="btn sm primary" onclick="addMemberModal()">${I.plus} Add teammate</button></div>
  <p class="small muted" style="margin-bottom:10px">Teammates also need <b>Editor</b> access to this page from the Share menu. Merchants need <b>Contributor</b> access. Roles below decide what each teammate sees.</p>
  <div class="tablewrap"><table><thead><tr><th>Name</th><th>Access level</th><th>Added</th><th></th></tr></thead><tbody>${team.map(t=>`<tr><td><b>${esc(nameOf(t.id))}</b>${t.id===S.uid?' <span class="faint small">(you)</span>':""}</td><td>${t.id===S.uid&&S.isOwner?'<span class="pill accent">Admin · owner</span>':`<select id="role-${t.id}" style="width:auto" onchange="setRole('${t.id}',this.value)">${Object.entries(ROLES).map(([k,l])=>`<option value="${k}" ${t.role===k?"selected":""}>${l}</option>`).join("")}</select>`}</td><td class="num">${fmtDate(t.addedAt)}</td><td>${t.id!==S.uid?`<button class="btn ghost sm danger" onclick="deactivate('${t.id}')">Deactivate</button>`:""}</td></tr>`).join("")}</tbody></table></div>
  <p class="small faint" style="margin-top:10px">Admin: everything. Manager: everything except team and settings. Specialist: upsell pipeline, assigned merchants, testimonials.</p></section>
  <section class="card stack"><h3>Opportunity matching rules</h3>${rules.map(([k,l])=>`<label class="toggle"><input type="checkbox" id="r-${k}" ${st.rules[k]?"checked":""} onchange="saveSettings({rules:{${k}:this.checked}},'Matching rule: ${l} → '+(this.checked?'on':'off'))"> ${l}</label>`).join("")}</section>
  <div class="grid g2"><section class="card stack"><h3>Weekly digest & target</h3><div class="formgrid"><div class="field"><label for="s-day">Digest day</label><select id="s-day" onchange="saveSettings({digestDay:this.value},'Digest day → '+this.value)">${["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"].map(d=>`<option ${st.digestDay===d?"selected":""}>${d}</option>`).join("")}</select></div><div class="field"><label for="s-time">Time</label><input id="s-time" type="time" value="${esc(st.digestTime)}" onchange="saveSettings({digestTime:this.value},'Digest time → '+this.value)"></div><div class="field"><label for="s-target">Weekly sourcing target</label><input id="s-target" type="number" min="1" value="${st.weeklyTarget}" onchange="saveSettings({weeklyTarget:Math.max(1,+this.value||50)},'Weekly target → '+this.value)"></div><div class="field" style="justify-content:flex-end"><label class="toggle"><input type="checkbox" id="s-lb" ${st.leaderboard?"checked":""} onchange="saveSettings({leaderboard:this.checked},'Leaderboard '+(this.checked?'on':'off'))"> Show leaderboard</label></div></div></section>
  <section class="card stack"><h3>Notifications</h3>${[["newMatch","Notify matched merchants when an opportunity is added"],["statusEmail","Email merchants when their review status changes"],["boostEmail","Email merchants when an opportunity is boosted"]].map(([k,l])=>`<label class="toggle"><input type="checkbox" id="n-${k}" ${st.notify[k]?"checked":""} onchange="saveSettings({notify:{${k}:this.checked}},'${l} → '+(this.checked?'on':'off'))"> ${l}</label>`).join("")}</section></div>
  <section class="card"><div class="card-head"><h3>Email templates</h3><span class="small faint">Placeholders: {{name}} {{store}} {{feedback}} {{opportunity}} {{count}} {{list}}</span></div>${Object.entries(st.templates).map(([k,t])=>`<div class="li"><span class="ico">${I.mail}</span><div class="grow"><p style="font-weight:600">${esc(t.label)}</p><span class="small faint">Sent when: ${esc(t.trigger)}</span></div><button class="btn sm" onclick="tplModal('${k}')">Edit</button></div>`).join("")}</section>
  <section class="card"><div class="card-head"><h3>Sample data</h3></div><p class="small muted">Try every screen with clearly-labelled sample merchants and opportunities. Clearing removes only sample records.</p><div class="row" style="margin-top:10px"><button class="btn sm" onclick="loadSample()">Load sample data</button><button class="btn sm danger" onclick="clearSample()">Clear sample data</button></div></section>
  <section class="card"><div class="card-head"><h3>Audit log</h3></div>${S.audit.slice(0,30).map(a=>`<div class="li"><div class="grow"><p class="small">${esc(a.text)}</p><span class="small faint">${esc(nameOf(a.by))} · ${ago(a.at)}</span></div></div>`).join("")||'<p class="muted small">Changes will be logged here.</p>'}</section>`;
}
async function saveSettings(patch,log){await upsert("settings/config",patch);audit(log);toast("Saved")}
function tplModal(k){const t=settings().templates[k];openModal(`<div class="modal-head"><div><span class="eyebrow">Email template</span><h2>${esc(t.label)}</h2><p class="small muted">Sent when: ${esc(t.trigger)}</p></div>${closeBtn()}</div><div class="field"><label for="tp-sub">Subject</label><input id="tp-sub" type="text" value="${esc(t.subject)}"></div><div class="field"><label for="tp-body">Body</label><textarea id="tp-body" style="min-height:260px">${esc(t.body)}</textarea></div><div class="row between"><button class="btn ghost" onclick="saveTpl('${k}',true)">Reset to default</button><button class="btn primary" onclick="saveTpl('${k}')">Save template</button></div>`,true)}
async function saveTpl(k,reset){const v=reset?{subject:DEFAULT_TEMPLATES[k].subject,body:DEFAULT_TEMPLATES[k].body}:{subject:document.getElementById("tp-sub").value,body:document.getElementById("tp-body").value};await upsert("settings/config",{templates:{[k]:v}});audit(`Edited email template "${DEFAULT_TEMPLATES[k].label}"`);closeModal();toast("Template saved")}
function addMemberModal(){openModal(`<div class="modal-head"><h2>Add a teammate</h2>${closeBtn()}</div><p class="small muted">Search people in your organization. Give them Editor access from the Share menu too.</p><input type="search" id="tm-q" placeholder="Search by name" oninput="clearTimeout(window._tq);window._tq=setTimeout(searchPeople,250)" onfocus="searchPeople()"><div class="field"><label for="tm-role">Role</label><select id="tm-role">${Object.entries(ROLES).map(([k,l])=>`<option value="${k}" ${k==="manager"?"selected":""}>${l}</option>`).join("")}</select></div><div id="tm-res" class="stack s6"></div>`)}
async function searchPeople(){const box=document.getElementById("tm-res");if(!box||!S.user?.search)return;const hits=await S.user.search(document.getElementById("tm-q").value||"");box.innerHTML="";if(!hits.length){box.innerHTML='<p class="small muted">No one found. Check the spelling or share the page with them first.</p>';return}hits.slice(0,8).forEach(h=>{const row=document.createElement("div");row.className="li";const g=document.createElement("div");g.className="grow";const b=document.createElement("b");b.textContent=h.name||"Unnamed";g.appendChild(b);const btn=document.createElement("button");btn.className="btn sm primary";btn.textContent=S.team[h.id]?.active!==false&&S.team[h.id]?"Already on team":"Add";btn.disabled=!!(S.team[h.id]&&S.team[h.id].active!==false);btn.onclick=async()=>{const role=document.getElementById("tm-role").value;S.profiles[h.id]={name:h.name};await setDoc("team/"+h.id,{role,active:true,addedAt:nowIso()});audit(`Added ${h.name} as ${ROLES[role]}`);closeModal();toast("Teammate added")};row.append(g,btn);box.appendChild(row)})}
async function setRole(id,role){await upsert("team/"+id,{role,active:true});audit(`Changed ${nameOf(id)}'s role to ${ROLES[role]}`);toast("Role updated")}
async function deactivate(id){openModal(`<div class="modal-head"><h2>Deactivate ${esc(nameOf(id))}?</h2>${closeBtn()}</div><p class="muted">They'll lose their team role here. To fully remove access, also remove them from the Share menu.</p><div class="row between"><button class="btn ghost" onclick="closeModal()">Cancel</button><button class="btn danger" onclick="upsert('team/${id}',{active:false}).then(()=>{audit('Deactivated '+nameOf('${id}'));closeModal();toast('Deactivated')})">Deactivate</button></div>`)}

/* sample data (clearly labelled, removable) */
async function loadSample(){
  const t=Date.now();const iso=d=>new Date(t-d*DAY).toISOString();
  const opps=[["Corporate Gifting","Hotel group sourcing natural soaps for guest welcome kits","A boutique hotel group is replacing amenity soaps across 40 properties and wants an independent brand with a story.",["Skincare or bath products","2,000+ units per quarter","Custom label with hotel logo","Ships to US"],["Skincare"],["US"],true,"200–1,000 orders","featured",2],
   ["Wholesale","Gift shop chain adding hand-poured candles for winter","A regional gift chain is adding 3–5 candle SKUs for the winter season and prefers small-batch makers.",["Candles","Wholesale pricing at 50% of retail","Ships to US or Canada"],["Candles","Home goods"],["US","Canada"],false,"50–200 orders","standard",1],
   ["Employee Rewards","Rewards platform looking for premium pet products","An employee rewards platform wants pet treats and accessories for its catalogue.",["Pet products","Drop-ship capable","US shipping"],["Pet products"],["US"],false,"","standard",4],
   ["Retail Listing","Australian concept store taking applications for new jewelry brands","A Sydney concept store reviews new jewelry brands monthly for in-store and online listing.",["Jewelry","Ships to Australia","Line sheet required"],["Jewelry"],["Australia"],false,"","standard",6]];
  for(const [type,title,description,requirements,categories,markets,requiresCustom,minVolume,priority,age] of opps){await setDoc("opportunities/demo-"+gid(),{type,title,description,requirements,categories,markets,requiresCustom,minVolume,priority,sourceUrl:"https://www.demerchantbridge.com/sourcing",sourceCategory:SOURCES[age%SOURCES.length],expiry:plusDays(age===6?1:20),status:"live",createdAt:iso(age%7>3?age:age/2),addedBy:S.uid,demo:true})}
  const ms=[["Sample · Ada Okafor","Sample · Lumen Candle Co.","Candles","approved",["US","Canada"],true,"200–1,000 orders","$10k–$50k",9,20],["Sample · Priya Shah","Sample · Velvet Skin Lab","Skincare","pending",["US","UK"],true,"200–1,000 orders","$10k–$50k",1,1],["Sample · Tom Reyes","Sample · Barkside Treats","Pet products","pending",["US"],false,"50–200 orders","$5k–$10k",3,3],["Sample · Jess Wu","Sample · Kin Jewelry","Jewelry","approved",["Australia","Worldwide"],true,"50–200 orders","$5k–$10k",15,16]];
  for(const [fullName,businessName,category,status,markets,customBranding,orderVolume,revenue,sub,seen] of ms){const id="demo-"+gid();const apps={};const tests={};if(status==="approved"){const a1=gid();apps[a1]={oppId:"",title:category==="Candles"?"Gift shop chain adding hand-poured candles for winter":"Australian concept store taking applications",type:category==="Candles"?"Wholesale":"Retail Listing",status:category==="Candles"?"Deal closed":"Applied",notes:"",appliedAt:iso(6),updatedAt:iso(category==="Candles"?2:18)};if(category==="Candles")tests[gid()]={text:"Within two weeks of joining we landed our first wholesale account. The match was spot on for what we make.",rating:5,oppTitle:"Gift shop chain candles",at:iso(2),status:"pending"}}
   await setDoc("merchants/"+id,{fullName,businessName,email:"",category,description:`Sample record for testing. ${businessName.replace("Sample · ","")} makes small-batch ${category.toLowerCase()}.`,targetMarket:"Gift buyers 25–45",aov:"$42",orderVolume,revenue,customBranding,markets,channels:["Shopify","Own website"],platform:"Shopify",storeUrl:"sample-store.myshopify.com",status,resubmission:false,createdAt:iso(sub),submittedAt:iso(sub),lastSeen:iso(seen),supplierDoc:{status:category==="Jewelry"?"none":"uploaded"},saved:{},pushed:{},applications:apps,notifications:{},messages:{},testimonials:tests,emails:{},demo:true});
   if(category==="Jewelry")await setDoc("notes/"+id,{upsell:{flag:true,service:"Supplier profile",stage:"In conversation",value:"350",assignee:S.uid,why:"No supplier profile yet",updatedAt:nowIso()},notes:{}});}
  audit("Loaded sample data");toast("Sample data loaded");
}
async function clearSample(){const ids=[...Object.keys(S.opps).filter(k=>S.opps[k].demo).map(k=>"opportunities/"+k),...Object.keys(S.merchants).filter(k=>S.merchants[k].demo).flatMap(k=>["merchants/"+k,"notes/"+k])];for(const p of ids)await delDoc(p);audit("Cleared sample data");toast(ids.length?"Sample data cleared":"No sample data to clear")}

boot();
