# MerchantBridge: website + merchant app + team dashboard

One static site, no build step. It contains:

- **Public website**: landing page (hero, live briefs strip, reviews spotlight, how it works, how we help, open requests, FAQ) plus **What we do**, **Contact** (working form), **Privacy Policy**, **Terms of Service**, **Cookie Policy** and a **Journal** (blog). Pages live at `/#about`, `/#contact`, `/#privacy`, `/#terms`, `/#cookies`, `/#journal` and `/#post-<slug>`.
- **Merchant app**: email sign-in, 3-step application, holding/feedback screens, dashboard, matched opportunity feed, saved/archive, application tracker, testimonial prompt on "Deal closed", profile with supplier document upload, inbox and notification bell.
- **Team dashboard** (same site, shown to team members): overview, review queue, merchants table, opportunities, sourcing tracker, upsell pipeline, testimonials + website reviews, Journal editor, Contact inbox, email outbox, settings (roles, matching rules, email templates, audit log).

Data, logins and file uploads run on **Supabase** (free tier is fine to start).

---

## 1. Try it first (2 minutes, no setup)

Open the folder with any static server and visit it:

```bash
cd merchantbridge
npx serve .            # or: python3 -m http.server 8080
```

With `config.js` left empty the site runs in **demo mode**. You're signed in as a demo admin and data is saved in your browser only. Click **Load sample data** on the team overview to fill every screen.

## 2. Set up Supabase (about 10 minutes)

1. Create a project at https://supabase.com.
2. **SQL Editor → New query**: paste all of `supabase/schema.sql` and run it. It creates the tables, access rules, realtime, the `uploads` storage bucket and a guard that stops merchants approving themselves.
3. **Project Settings → API**: copy the **Project URL** and the **anon public** key into `config.js`.
4. **Authentication → URL Configuration**:
   - Site URL: `https://www.demerchantbridge.com` (or whatever domain you deploy to)
   - Redirect URLs: add the same domain, plus `http://localhost:8080` for local testing.
5. **Authentication → Emails → SMTP settings**: connect a real email sender (Resend, Postmark, SendGrid, etc.). Supabase's built-in sender is heavily rate-limited and isn't meant for production. You can also edit the "Magic Link" email template here so it matches the brand.
6. Open the site, click **Sign in**, and sign in with your own email (a profile row is created on first sign-in).
7. Make yourself the owner. In the SQL Editor:
   ```sql
   update public.profiles set access = 'owner' where email = 'you@example.com';
   ```
   Reload the site and you'll see the **Website / Merchant / Team** switch.
8. Add teammates from **Team → Settings → Team members** (they must sign in once first so they appear in search). Being added as an active teammate gives them team access. Deactivating removes it.

## 3. Deploy

It's plain HTML/CSS/JS, so any static host works: Vercel, Netlify, Cloudflare Pages, or upload the folder to existing hosting.

- **Vercel / Netlify**: drag the `merchantbridge` folder in, or connect a repo. No build command, output directory = the folder root.
- Point the domain, then make sure the Supabase Site URL / Redirect URLs match it (step 2.4).
- `vercel.json` (Vercel) and `_redirects` (Netlify / Cloudflare Pages) send the old site's URLs (`/about`, `/contact`, `/privacy`, `/terms`, `/cookies`, `/blog`, `/faq`, `/auth/join`…) to the new pages, so existing links and search results keep working. On other hosts, add the same redirects.

## 4. Files

```
index.html            page shell, fonts, script order
config.js             Supabase URL + anon key (empty = demo mode)
vercel.json           old-URL redirects for Vercel
_redirects            old-URL redirects for Netlify / Cloudflare Pages
assets/styles.css     all styles (brand colours are the tokens at the top)
assets/app.js         the whole app: website, merchant side, team side
assets/backend.js     data/login/upload layer on Supabase (+ demo mode)
assets/logo.png       logo (replace with the original high-res file)
supabase/schema.sql   database, access rules, storage, realtime
```

How the data is stored: one table, `public.documents (collection, id, data jsonb)`. Collections:

| collection | doc id | who can read | who can write |
|---|---|---|---|
| `merchants` | merchant's user id | that merchant + team | that merchant (protected fields guarded) + team |
| `opportunities` | random | everyone | team |
| `reviews` | random | everyone | team |
| `settings` | `config` | everyone | team |
| `posts` | random | everyone | team |
| `contact` | random | team | anyone can send (insert only, max 20 KB) |
| `team` | user id | team | team |
| `notes` | merchant id | team | team |
| `audit` | random | team | team |

Access is enforced in the database with row level security (see `schema.sql`), not in the browser. A merchant can't change their own `status`, `feedback`, `reviewedAt`, `reviewedBy`, `pushed` or `demo` fields, except moving from "changes requested" or "rejected" back to "pending" when they resubmit.

## 5. Not wired yet (next steps)

1. **Sending emails.** Every email the platform triggers (approved, changes requested, rejected, boost, deal closed, weekly digest, case-study request) is written from the editable templates into **Team → Email outbox**, where the team can copy it or mark it sent. To send automatically, add a Supabase Edge Function (or a Database Webhook to Make/Zapier) that watches `documents` where `collection = 'merchants'`, picks entries in `data.emails` with `sent = false`, sends them with your email provider, then sets `sent = true`.
2. **Weekly digest automation.** The "Build this week's digest" button in the Email outbox creates the digest emails. To run it automatically, schedule an Edge Function with Supabase Cron on the day/time set in Settings.
3. **Shopify OAuth.** Shopify merchants currently enter their store address and the team verifies it during review. To pull catalogue/order data automatically, add a Shopify app (Partner dashboard) with an OAuth callback that writes store data into the merchant's document.
4. **Specialist role limits** (what a Specialist can see) are applied in the interface. All team roles have the same database rights. If that matters, extend `is_staff()` checks in `schema.sql` per collection.
5. **Large datasets.** Lists load a whole collection and filter in the browser, which is fine for hundreds to a few thousand records. Move heavy lists (audit log, merchants) to paged queries if it grows beyond that.
6. **Legal pages.** Privacy, Terms and Cookies are solid starting drafts written for a US (Wyoming) company serving the US, Canada, Australia, UK and EU. Have a lawyer review them before launch, especially governing law, the 30-day deletion promise and the liability cap. Edit them in `assets/app.js` (search for `const LEGAL=`).
7. **Spam on the contact form.** It has a hidden honeypot field and a size limit. If spam becomes a problem, add Cloudflare Turnstile or hCaptcha.
8. **Logo.** `assets/logo.png` was taken from a screenshot. Swap in the original high-res file (same name).

## 6. Quick test checklist after deploy

- [ ] Signed out: landing page loads, live briefs strip moves, "Join MerchantBridge" asks for an email.
- [ ] Magic link arrives, opens the site signed in, and the application form starts automatically.
- [ ] Submit an application → it appears in **Team → Review queue**.
- [ ] Approve it → the merchant sees their dashboard and matched feed; an approval email appears in the outbox.
- [ ] Merchant uploads a supplier document → it opens from Team → merchant profile.
- [ ] Merchant marks an application "Deal closed" → testimonial prompt → approve + "Publish to website" → shows in the reviews section.
- [ ] A second merchant account can't see the first merchant's data.
- [ ] Every footer link opens a page; `/privacy`, `/terms`, `/about`, `/contact` and `/blog` redirect to the new pages.
- [ ] Signed out: send a Contact message → it appears in **Team → Contact inbox**.
- [ ] Team → Journal: write and publish a post → it shows on `/#journal` and the Journal footer link appears.
